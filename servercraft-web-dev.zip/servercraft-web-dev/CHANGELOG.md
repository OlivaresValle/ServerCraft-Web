# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [1.13.2](https://github.com/j-dominguezp/servercraft-web/compare/v1.13.1...v1.13.2) (2021-12-13)


### Bug Fixes

* **global:** se corrige validacion de autorizacion para evitar redirecciones erroneas ([9816fa5](https://github.com/j-dominguezp/servercraft-web/commit/9816fa5085b492d5980fd7ecb4fe0702acc6d0a3))
* **incidenes:** se añade nombre del incidente a la alerta de eliminacion ([016e176](https://github.com/j-dominguezp/servercraft-web/commit/016e1766121410d5939451be1b97e13566021418))

### [1.13.1](https://github.com/j-dominguezp/servercraft-web/compare/v1.13.0...v1.13.1) (2021-12-11)


### Bug Fixes

* **documentos servicio:** se corrige edicion de documentos de servicios ([328d928](https://github.com/j-dominguezp/servercraft-web/commit/328d928d9d88be83a057f193b71518a2b5d41392))

## [1.13.0](https://github.com/j-dominguezp/servercraft-web/compare/v1.12.9...v1.13.0) (2021-12-11)


### Features

* **modulo usuarios:** se añade equipo de trabajo ([e6f9a4c](https://github.com/j-dominguezp/servercraft-web/commit/e6f9a4cff0dc59a6f43e145414e684c690e959cb))

### [1.12.9](https://github.com/j-dominguezp/servercraft-web/compare/v1.12.8...v1.12.9) (2021-12-11)


### Bug Fixes

* **auth:** se corrigen rutas de importacion de useUsuario ([87f15a3](https://github.com/j-dominguezp/servercraft-web/commit/87f15a356076f9f8d2b246d64e81ac007ca69aa3))

### [1.12.8](https://github.com/j-dominguezp/servercraft-web/compare/v1.12.7...v1.12.8) (2021-12-11)


### Bug Fixes

* **auth:** se cambian todos los parametros de autorizacion de server side a client side ([f4aa35e](https://github.com/j-dominguezp/servercraft-web/commit/f4aa35e6cd82923ed9fd0cbbb99105a2e4681810))

### [1.12.7](https://github.com/j-dominguezp/servercraft-web/compare/v1.12.6...v1.12.7) (2021-12-11)


### Bug Fixes

* **estadisticas:** se realiza redireccion y autorizacion por client side ([85b871d](https://github.com/j-dominguezp/servercraft-web/commit/85b871dd25bae9526552ac95e206e16495bdfc37))

### [1.12.6](https://github.com/j-dominguezp/servercraft-web/compare/v1.12.5...v1.12.6) (2021-12-11)


### Bug Fixes

* **global:** se corrige funcionalidad de comboboxes en toda la aplicacion ([5095b15](https://github.com/j-dominguezp/servercraft-web/commit/5095b15a0cce55d2415a0a38bff8dd7b9ec37968))

### [1.12.5](https://github.com/j-dominguezp/servercraft-web/compare/v1.12.4...v1.12.5) (2021-12-11)


### Bug Fixes

* **incidentes:** se corrige edicion de incidentes e identificacion de incidente en listado ([9130c76](https://github.com/j-dominguezp/servercraft-web/commit/9130c765806d68009b1e64a7d51ddaa2212d2d89))
* **sistema:** se cambia el nombre del encargado, ademas de margen a la paginacion ([459fe67](https://github.com/j-dominguezp/servercraft-web/commit/459fe672aafc5d32cd4fa9408060ccbb7acdd9f9))
* **sistema:** se corrige validacion de lenguajes de programacion ([0bfe9d7](https://github.com/j-dominguezp/servercraft-web/commit/0bfe9d7999b33d13f943312b9961b34d98a41b7c))

### [1.12.4](https://github.com/j-dominguezp/servercraft-web/compare/v1.12.3...v1.12.4) (2021-12-10)


### Bug Fixes

* **global:** se corrige virtualizacion de datos para select ([cf214e4](https://github.com/j-dominguezp/servercraft-web/commit/cf214e4765830c65d04507052891f30574071106))


### Others

* **npm packages:** se actualizan las dependencias ([e0fb3c1](https://github.com/j-dominguezp/servercraft-web/commit/e0fb3c1eb93b59e986eaab1966e41866b11a4a40))

### [1.12.3](https://github.com/j-dominguezp/servercraft-web/compare/v1.12.2...v1.12.3) (2021-12-10)


### Bug Fixes

* **global:** se corrige error al abrir combobox demasiado grandes ([e1f32ce](https://github.com/j-dominguezp/servercraft-web/commit/e1f32ceac4486acab6043ecb72bd9b19674efba6))

### [1.12.2](https://github.com/j-dominguezp/servercraft-web/compare/v1.12.1...v1.12.2) (2021-12-10)


### Bug Fixes

* **global:** se corrigen combobox de datos para carga ilimitada de informacion ([c01d6e4](https://github.com/j-dominguezp/servercraft-web/commit/c01d6e4743d1c8dd48b22c81fad9ab5449bebb94))
* **proveedores:** se agrega toString en las acciones faltantes ([6d0f36a](https://github.com/j-dominguezp/servercraft-web/commit/6d0f36a98975d1029854c520271c2eadaee408f7))
* **usuarios:** se corrige actualizacion de usuario http ([e2462b6](https://github.com/j-dominguezp/servercraft-web/commit/e2462b6d482dab40952b18abd2783439e8c8274c))

### [1.12.1](https://github.com/j-dominguezp/servercraft-web/compare/v1.12.0...v1.12.1) (2021-12-10)


### Bug Fixes

* **incidentes:** se corrige formulario de  creacion de incidentes para vincular instancias ([e32a721](https://github.com/j-dominguezp/servercraft-web/commit/e32a721cff60e64410dba4db062b1ad120db4d78))

## [1.12.0](https://github.com/j-dominguezp/servercraft-web/compare/v1.11.1...v1.12.0) (2021-12-10)


### Features

* **detalle sistema:** se agrega icono y se cambia a link el documento del sistema para mejor UX ([26333d7](https://github.com/j-dominguezp/servercraft-web/commit/26333d7a7f90962d1beccf36d0483158a5eadcd6))
* **navbar publico:** se agrega query params para ocultar navbar en mobile ([bba5681](https://github.com/j-dominguezp/servercraft-web/commit/bba5681cbafa78b3cd74b5357308baf80ccdd82e))


### Bug Fixes

* **clientes y proveedores:** se corrige ortografia en la vista de proveedores ([76e05d7](https://github.com/j-dominguezp/servercraft-web/commit/76e05d7bc51b1dfd989727a2287dd500eaf02887))
* **estadistica:** se cambia la estructura de los graficos, ademas de cambiar la vista ([0cac1b1](https://github.com/j-dominguezp/servercraft-web/commit/0cac1b17d0f61c344f46a6a8e11668041d16bc67))
* **estadistica:** se modifica la estrucutra de los graficos de estadisticas ([03ea1e6](https://github.com/j-dominguezp/servercraft-web/commit/03ea1e6ba0eb0f92419a80cc92efbe8f413090f7))
* **lenguajes y motoresbd:** se corrigieron las validaciones, ademas de agregar nuevos formatos ([db80a54](https://github.com/j-dominguezp/servercraft-web/commit/db80a54ed0f5ac89eced634c5fc9979d11b2f86a))
* **lenguajes:** correcciones ortograficas ([37ba9ff](https://github.com/j-dominguezp/servercraft-web/commit/37ba9ff4ae9c7b1d30edc3b942367bc36cde5ef4))
* **lenguajes:** se corrige ortografía, diseño y validaciones ([af39863](https://github.com/j-dominguezp/servercraft-web/commit/af398630199f4d40fb787137887a97c3760b0f0e))
* **menu usuario:** se quita item configuracion y se agrega funcionalidad al boton de perfil ([5980712](https://github.com/j-dominguezp/servercraft-web/commit/5980712978af67758999594c4ec5221f8c39a85e))
* **menu:** se mejora la animacion del menu principal ([4cbffc7](https://github.com/j-dominguezp/servercraft-web/commit/4cbffc7613440838c9639ddc72ed70ff80f9d17a))
* **modals incidentes:** se corrige tamaño de modals a uno estandarizado ([dd96118](https://github.com/j-dominguezp/servercraft-web/commit/dd96118593b65355da337f9b89fbca175b9755e4))
* **modulo incidentes:** se corrige ortografía y diseño en el modulo de incidentes ([94bcc98](https://github.com/j-dominguezp/servercraft-web/commit/94bcc98503e4c7be5597893c2d961a3b6c5e2142))
* **motores bd:** se corrige ortografía, diseño y validaciones ([233a56c](https://github.com/j-dominguezp/servercraft-web/commit/233a56c90852b23b1a189250816fead19af38f7c))
* **paises:** se corrige formato de texto de titulo ([e69f673](https://github.com/j-dominguezp/servercraft-web/commit/e69f6735f291d57bda316df73ca093132a649ee3))
* **paises:** se corrige ortografia, diseño y validaciones ([36a67dc](https://github.com/j-dominguezp/servercraft-web/commit/36a67dc0666bd75c4172e006cbc4bc9d341f0002))
* **proveedores:** se modifica las validaciones de los telefonos de los proveedores ([54518ae](https://github.com/j-dominguezp/servercraft-web/commit/54518aee199cef4b71ff6410797261e382aba2c8))
* **proveedor:** se cambia la estructura del modelo de proveedores ([5ef5574](https://github.com/j-dominguezp/servercraft-web/commit/5ef557410f0531c9fa5292104efd2264ac8c3e58))
* **racks:** se corrige diseño, ortografia, validaciones e inputs ([d0d4787](https://github.com/j-dominguezp/servercraft-web/commit/d0d478777f19664c1abce30fccd07658720560c8))
* **racks:** se corrige texto de advertencia y confirmacion de eliminacion ([6f0c491](https://github.com/j-dominguezp/servercraft-web/commit/6f0c4917ed9d7ef1c137987f04f4a068dc665e9d))
* **recuperar contraseña:** ajustes visuales para vista desde android ([572f789](https://github.com/j-dominguezp/servercraft-web/commit/572f789caf21a648f0546476f408d94f65a7699d))
* **regiones:** se corrige ortografía, validaciones y diseño ([cc25d27](https://github.com/j-dominguezp/servercraft-web/commit/cc25d27a4e648cda49164c36354dafcb43094470))
* **salas:** se corrigen validaciones, ortografía, diseño ([a7d546a](https://github.com/j-dominguezp/servercraft-web/commit/a7d546aaccdb5d9457864d0142ecbb3f54064090))
* **servicio web:** mensaje para la falta d euna URL valida ([7cb5529](https://github.com/j-dominguezp/servercraft-web/commit/7cb55295edad5f316ba7458c6fb75e2289225213))
* **servicio web:** se añade URL al atributo url ([5b96d31](https://github.com/j-dominguezp/servercraft-web/commit/5b96d31ecd33c067dd56a27b7693d92e1ac627ef))
* **servicio web:** se cambia la distribucion de las columnas ([4984d8d](https://github.com/j-dominguezp/servercraft-web/commit/4984d8ddf1404f35d97d942762852f96864ec43f))
* **servicio web:** se cambiaron el texto de elminacion ([c8bf929](https://github.com/j-dominguezp/servercraft-web/commit/c8bf929a848000f5fae29fac769e97389bfb1b73))
* **servicios web:** correcciones ortograficas de la vista servicios web ([ffd639e](https://github.com/j-dominguezp/servercraft-web/commit/ffd639ee0ca25bc9480b3be5bbae73bbcff4de92))
* **servicios web:** se corrigieron las validaciones, ademas de agregar nuevos formatos ([53b7f1e](https://github.com/j-dominguezp/servercraft-web/commit/53b7f1e39102023a4a1600cfe59004a8c5a8d866))
* **servidor:** correccion ortografica del servidor ([653e91c](https://github.com/j-dominguezp/servercraft-web/commit/653e91cd595aeda4593868109e8327bbd2980b33))
* **servidores:** se corrige breadcrumb para poseer el nombre dle modulo en el menu principal ([deeb23d](https://github.com/j-dominguezp/servercraft-web/commit/deeb23df33e5986e0b63b623231b48ff9d72f60f))
* **servidores:** se corrige texto de confirmacion de eliminacion ([39eb814](https://github.com/j-dominguezp/servercraft-web/commit/39eb81449ce8a7a3dd520a3b92c070b3b6b760af))
* **servidores:** se corrigen validaciones, diseño y ortografía ([62d0604](https://github.com/j-dominguezp/servercraft-web/commit/62d0604ccdc26aab2cff357dc91da33ac4662366))
* **servidor:** se corrige formato de texto de detalle ([556026b](https://github.com/j-dominguezp/servercraft-web/commit/556026b3b22f5bd26dabadd133c9e4d1e1addf81))
* **servidor:** se corrige validacion de memoria y almacenamiento ([9638f3c](https://github.com/j-dominguezp/servercraft-web/commit/9638f3cce4e985ac990620a7b910b2bd0f52efe1))
* **sidebar template:** se mueve el container a un div interior para corregir la posicion del scroll ([b153d20](https://github.com/j-dominguezp/servercraft-web/commit/b153d20d424c15a21e1293693af8af326f9543e7))
* **sistema:** se cambia el nombre de la tabla ([2af38da](https://github.com/j-dominguezp/servercraft-web/commit/2af38da5c0e5bb643e0104dcbf1eafa693d96e62))
* **sistema:** se cambia estructura de la ortografica ([2f19d11](https://github.com/j-dominguezp/servercraft-web/commit/2f19d11bae47cc4512366563db082bc290f597d7))
* **sistemas:** sE corrige ortografia, diseño y validaciones ([fbfb0f9](https://github.com/j-dominguezp/servercraft-web/commit/fbfb0f9c8196dd73de9493dbf0f537fd91b221c9))
* **sistemas:** se corrige titulo de detalle ([fd3b082](https://github.com/j-dominguezp/servercraft-web/commit/fd3b082dae4457dc9bbc0b2c32513bcf9b56b0f1))
* **ubicacion:** se cambia la ruta de la vista ([219d4bc](https://github.com/j-dominguezp/servercraft-web/commit/219d4bc0d20b52f197be4e5e4315c90e6754b374))
* **usuario y equipo:** se añade el conmfirmar contraseña y se cambia el mensaje de eliminacion ([b52ad1a](https://github.com/j-dominguezp/servercraft-web/commit/b52ad1aba69924f70dda1c33b4eee2b167af214e))
* **usuario y equipos:** se cambia la validacion del numero de telefono ([3a84540](https://github.com/j-dominguezp/servercraft-web/commit/3a845404ca04d22379feb8f6fec781f1e62e2e46))
* **usuarios y equipos:** se añaden correccion ortograficas al modulo de usuarios y equipos ([2c0d7a7](https://github.com/j-dominguezp/servercraft-web/commit/2c0d7a7c5f5b1fbc2a7e3b0b70fa072dc74d3c6c))
* **usuarios y equipos:** se cambia el nombre del modal de creacion ([6706cf2](https://github.com/j-dominguezp/servercraft-web/commit/6706cf2a33dcf338f4c5d16e63cdf183ee6e7634))
* **usuarios y equipos:** se modifica el mensaje de eliminacion ([d5d3d85](https://github.com/j-dominguezp/servercraft-web/commit/d5d3d859e5e302dc98a1540f1e845e32c462daaa))
* **usuario:** se  transforma numero de telefono a string ([3d1dde7](https://github.com/j-dominguezp/servercraft-web/commit/3d1dde711fd6d991da7ab3913eb99460623161b9))

### [1.11.1](https://github.com/j-dominguezp/servercraft-web/compare/v1.11.0...v1.11.1) (2021-12-09)


### Bug Fixes

* **incidentes:** se cambia el idEstadoIncidente para que sea obligatorio solo al editar ([8685069](https://github.com/j-dominguezp/servercraft-web/commit/8685069ce4e1f3e21e5dfe2456cd890b5d1e9ddb))
* **incidentes:** se corrigieron las validaciones, ademas de agregar nuevos formatos ([385ac75](https://github.com/j-dominguezp/servercraft-web/commit/385ac75a6c36db2f31ca3ae6bc8dc347c7850b85))
* **incidentes:** se modifica las variables que solo se pueden modificar al editar un incidente ([35b0c92](https://github.com/j-dominguezp/servercraft-web/commit/35b0c929c959e655f8950c6bbe949ca22cddcd49))

## [1.11.0](https://github.com/j-dominguezp/servercraft-web/compare/v1.10.0...v1.11.0) (2021-12-09)


### Features

* **cambiar contraseña:** cambiar contraseña ([d132b83](https://github.com/j-dominguezp/servercraft-web/commit/d132b831791cdcde6130aaead7f122b5b83dee37))
* **estadisticas:** arreglos a estadistica de usuarios por rol ([77b9a21](https://github.com/j-dominguezp/servercraft-web/commit/77b9a2167818e68430af9a4f1ebce65c73ae9afe))
* **estadistica:** se agrego los archivos de estadisticas a la carpeta HTTP ([5b36fd0](https://github.com/j-dominguezp/servercraft-web/commit/5b36fd0398efc9225828e164eb4a8222a12e46d8))
* **estadistica:** se añade el grafico de tipos de problemas de incidentes ([60f3954](https://github.com/j-dominguezp/servercraft-web/commit/60f395457d999da9de918ebc365fc9a466f4c797))
* **estadistica:** se modifico las variables data segun la api ([c8602db](https://github.com/j-dominguezp/servercraft-web/commit/c8602dbe5b079c95fcc255f57f8ee633675bf030))
* **estadisticasnuevoscliente:** cambios a estadisticas de nuevos clientes ([a2bb98d](https://github.com/j-dominguezp/servercraft-web/commit/a2bb98d8246ec76ceb85675cd467a400d4a78d15))
* **estadisticasnuevosclientes:** se agrega grafico de nuevos clientes con datos en duro ([00e0956](https://github.com/j-dominguezp/servercraft-web/commit/00e09562a2998a30c8c16b9ecc619bc36efb0994))
* **estadisticasnuevosclientes:** se aplican datos sacados desde la API ([0e0737a](https://github.com/j-dominguezp/servercraft-web/commit/0e0737a3d1622803864cbe601fc935c830c2f728))
* **estadisticas:** se agrega grafico de barra de Estadistica Usuarios por Rol ([b8a4575](https://github.com/j-dominguezp/servercraft-web/commit/b8a45752ebd2ee35d68f0fb82ea6005035cfb47c))
* **estadisticas:** se añade grafico de barras para Incidentes activos mensuales ([e1b74b9](https://github.com/j-dominguezp/servercraft-web/commit/e1b74b93eeebcbbdb391842f136c0d38977bbb1b))
* **estadisticas:** se cambio kpi completamente por "Sistemas nuevos mensuales" ([eeaf86e](https://github.com/j-dominguezp/servercraft-web/commit/eeaf86e016fdad088026c7ecd9fc5f5369e50dbb))
* **estadisticas:** se crea base para trabajo de estadisticas ([5dbedb9](https://github.com/j-dominguezp/servercraft-web/commit/5dbedb9684def8e03ffd38fb542dd2ae82dced4c))
* **estadisticas:** se valida redireccion para otros roles que no sean administrador ([21f550b](https://github.com/j-dominguezp/servercraft-web/commit/21f550b78d6a490ca226cbdcf88b0b0ab14fa2f2))
* **sistemas:** se añade capacidad de actualizacion de instancias ([c2cdb61](https://github.com/j-dominguezp/servercraft-web/commit/c2cdb61ad434258eb5dbf75f3abb4c30d94e442b))
* **sistemas:** se añade modal de seleccion de base de datos en creacion de sistema ([1721e50](https://github.com/j-dominguezp/servercraft-web/commit/1721e50a3a569239d6c27288b8a4ed9ba3322f91))
* **sistemas:** se añade modal de seleccion de lenguajes asociados al sistema en crecion ([a6897a2](https://github.com/j-dominguezp/servercraft-web/commit/a6897a26107db0ee4c347d10a086a44e777060c4))
* **sistemas:** se añade modal para creacion de documentos asociados a un sistema ([70510e4](https://github.com/j-dominguezp/servercraft-web/commit/70510e4fa5bfe9848200960466868d6d504532dc))
* **sistemas:** se añade modal para seleccion de servicios asociados a un sistema en su creacion ([030b9f7](https://github.com/j-dominguezp/servercraft-web/commit/030b9f7ffd2a897934eb3ed61e7d65802db4a009))
* **sistemas:** se añade modal para seleccion de servidor en creacion de sistema ([d6d1470](https://github.com/j-dominguezp/servercraft-web/commit/d6d14708163137b66440e462d625dcc3b8fe66f6))
* **sistemas:** se añade selector inicial de proveedor de sistema y servidores ([0779938](https://github.com/j-dominguezp/servercraft-web/commit/07799385c91db4e7b711b28d516d1be592b5dfcf))
* **sistemas:** se añaden mas elementos a la creacion de sistemas en http ([c387e30](https://github.com/j-dominguezp/servercraft-web/commit/c387e30bc66b71a231d18677f4b48670348a7fd8))
* **sistemas:** se añase nueva informacion obtenida de formulario en envio de data a la API ([d9eb37a](https://github.com/j-dominguezp/servercraft-web/commit/d9eb37ad6a6654c8190c604be96d4682713ec9f1))
* **sistemas:** se implementan nuevas modalidades en creacion de sistema (instancias, lenguajes, etc ([2e258b5](https://github.com/j-dominguezp/servercraft-web/commit/2e258b53bf6aea705fee184926e10878e78e5062))


### Bug Fixes

* **clientes y proveedores:** se corrigieron las validaciones, ademas de agregar nuevos formatos ([a2184af](https://github.com/j-dominguezp/servercraft-web/commit/a2184af5e391aa2a5b5896ffef08a3bc1ffb9c30))
* **estadisticas:** cambios de codigo a ContenidoEstadisticas ([0900abf](https://github.com/j-dominguezp/servercraft-web/commit/0900abf8a3a8928af4041bf8ed66bdff4326bade))
* **estadistica:** se añade la conexion del label y data con la base de datos ([4fb6867](https://github.com/j-dominguezp/servercraft-web/commit/4fb6867adc63071b93b5e8fbf0a6a0a284ad1408))
* **estadistica:** se añade maximo en el eje Y ([f6614f2](https://github.com/j-dominguezp/servercraft-web/commit/f6614f208e88988e32cf5c38ce412513b4df4be7))
* **estadistica:** se añade maximo para el eje Y ([7464e72](https://github.com/j-dominguezp/servercraft-web/commit/7464e727391e6e5574c8c8e21e6685197c2e2105))
* **estadisticas:** se eliminó codigo sin utilizar ([70566b1](https://github.com/j-dominguezp/servercraft-web/commit/70566b1c7ca51a0d22e338eac19f23fadec56bf0))
* **estadisticas:** se hicieron cambios en el codigo de sistemas nuevos ([565cbbb](https://github.com/j-dominguezp/servercraft-web/commit/565cbbb694a0fa46dfe87a482744ee2fbf98059f))
* **incidentes mensuales:** correccion de estructura ([3002d2b](https://github.com/j-dominguezp/servercraft-web/commit/3002d2bb6b630aa8d58c9bbf15da8b66059ca3c1))
* **middleware:** se añade ruta de cambio contraseña a whitelist ([63e1fa3](https://github.com/j-dominguezp/servercraft-web/commit/63e1fa36ac778523a6a7c1c1b4f486ec25870d0b))
* **sala, rack, servidor:** se corrigieron las validaciones, ademas de agregar nuevas para formatos ([532cf24](https://github.com/j-dominguezp/servercraft-web/commit/532cf24708672e17fbbfe7165be561c3a791c6a5))
* **sistemas:** en edicion se sistemas se listan documentos pre asignados ([057e27b](https://github.com/j-dominguezp/servercraft-web/commit/057e27ba841ffb4b7b14b24fc0b0bb705c67e224))
* **sistemasnuevos:** arreglo de tamaño de grafico y cantidad maxima de sistemas nuevos ([e209920](https://github.com/j-dominguezp/servercraft-web/commit/e20992000b7e45f908c704c19f36026f0aff6621))
* **sistemas:** se corrige color de estado de sistema, tambien se mejora diseño de filtros ([4179d78](https://github.com/j-dominguezp/servercraft-web/commit/4179d78fc3e87b5a7f36146bc3631b9b951b50ba))
* **sistemas:** se eliminan servicios seleccionados del listado de servicios ([f6dd4e5](https://github.com/j-dominguezp/servercraft-web/commit/f6dd4e5d30ad6f8fc82fdec7143ddf047c010fef))
* **sistemas:** se filtra los equipos disponible para los clientes que poseen equipos ([f905c34](https://github.com/j-dominguezp/servercraft-web/commit/f905c34495c2697ee0c8d3c81f730cb1d80ba4bf))
* **ubicacion:** se corrigieron las validaciones, ademas de agregar nuevos formatos ([607a206](https://github.com/j-dominguezp/servercraft-web/commit/607a206590ead8b9839787fe608b6283cb25f966))
* **usuarios y equipos:** se corrigieron las validaciones, ademas de agregar nuevos formatos ([9765cfb](https://github.com/j-dominguezp/servercraft-web/commit/9765cfbe856c438831f294df955f3d42943bfd56))


### Others

* **global:** se eliminan console logs sin uso ([252382f](https://github.com/j-dominguezp/servercraft-web/commit/252382f8b4a2cfdb3caa585b898f5578a31db8b3))
* **npm:** se actualizan dependencias ([d136356](https://github.com/j-dominguezp/servercraft-web/commit/d136356140ecb223a0664602c3ae6dd1a34cf37e))
* **sistemas:** se remueve console.log ([5751b14](https://github.com/j-dominguezp/servercraft-web/commit/5751b144b5837ea83e27f80723e9e3a5f5c87bf8))

## [1.10.0](https://github.com/j-dominguezp/servercraft-web/compare/v1.9.2...v1.10.0) (2021-11-22)


### Features

* **actividad:** se añade redireccion del lado del servidor para usuarios no autorizados ([c89bbfa](https://github.com/j-dominguezp/servercraft-web/commit/c89bbfaf4dadd9de9a81478e3452aa32f2b8ecc4))
* **clientes y proveedores:** se añade la reedireccion a proveedores y equipos para el informante ([9d26093](https://github.com/j-dominguezp/servercraft-web/commit/9d2609387da422abdae3975087d476ccda5bf2f1))
* **lenguajes:** se realizo redireccion de funcion lenguajes a roles necesarios ([8248e41](https://github.com/j-dominguezp/servercraft-web/commit/8248e413dc651253120d18c0133667408021b17f))
* **motores-bd:** se realizo la redirección de motores-bd para usuarios consultor e informante ([c2b4f13](https://github.com/j-dominguezp/servercraft-web/commit/c2b4f13b4ebcb03a6925e028e1885c89e00245f2))
* **paises:** se añade redireccion del lado del servidor para usuarios no autorizados ([1f32a80](https://github.com/j-dominguezp/servercraft-web/commit/1f32a807003bb2b6b55fe8440ebd74907fcf9b67))
* **racks:** se añade redireccion del lado del servidor para usuarios no autorizados ([c606fde](https://github.com/j-dominguezp/servercraft-web/commit/c606fdecd1593a57dbae045a1ece18e9972fe226))
* **regiones:** se añade redireccion del lado del servidor para usuarios no autorizados ([0838e6a](https://github.com/j-dominguezp/servercraft-web/commit/0838e6a3a8854cdfa5fef385232269e4e534e7c0))
* **salas:** se añade redireccion del lado del servidor para usuarios no autorizados ([627d49d](https://github.com/j-dominguezp/servercraft-web/commit/627d49d62ecb4fc7a979dcb24f6b5599ac38365d))
* **servicios web:** se añade la reedireccion de servicios web y documentos para el informante ([d335578](https://github.com/j-dominguezp/servercraft-web/commit/d335578081184da6573e201c51bcdeeb476a15d4))
* **usuarios/equipo-trabajo/unidad-negocio:** se hicieron redirecciones para todos los usuarios ([da40e1a](https://github.com/j-dominguezp/servercraft-web/commit/da40e1ae27a1f0eb5b950a4a4826b293a784e439))

### [1.9.2](https://github.com/j-dominguezp/servercraft-web/compare/v1.9.1...v1.9.2) (2021-11-20)


### Bug Fixes

* **recuperar contraseña:** se eliminan imports no utilizados ([45c61b6](https://github.com/j-dominguezp/servercraft-web/commit/45c61b6177aa635c3f2a1a895a20e5e7d7f7f21a))

### [1.9.1](https://github.com/j-dominguezp/servercraft-web/compare/v1.9.0...v1.9.1) (2021-11-20)


### Bug Fixes

* **recuperar contraseña:** se corrige validacion de formulario ([c6df213](https://github.com/j-dominguezp/servercraft-web/commit/c6df213a6a249307428ad6fe7a596223967e6240))


### Others

* **nueva contraseña:** se crea pagina inicial para formulario de creacion de nueva contraseña ([6a86e62](https://github.com/j-dominguezp/servercraft-web/commit/6a86e62ea3a809517ecfbb2149d74cdc5015b480))

## [1.9.0](https://github.com/j-dominguezp/servercraft-web/compare/v1.8.0...v1.9.0) (2021-11-19)


### Features

* **documento servicio web:** vista personalizada por el rol del usuario ([ea46ca9](https://github.com/j-dominguezp/servercraft-web/commit/ea46ca92dd40e4c0e4bdc6c7a462ca48ea4b76be))
* **equipo encargado:** vista personalizada por el rol del usuario ([e604316](https://github.com/j-dominguezp/servercraft-web/commit/e604316b750e68ca0999050132af45984b367591))
* **euipostrabajos:** vista equipos de trabajos por tipos de usuarios ([e79227f](https://github.com/j-dominguezp/servercraft-web/commit/e79227f4f06e6f7112a47e4f8628e090678aac8c))
* **http:** se añade funcion http para envio de correos de recuperacion ([1a5099d](https://github.com/j-dominguezp/servercraft-web/commit/1a5099d69c1fa0a9981e54388f6aea609ba5dfdd))
* **incidentes:** vista personalizada por el rol del usuario ([d044e42](https://github.com/j-dominguezp/servercraft-web/commit/d044e42c86ad31a8752adca8f2b716c49caaac4e))
* **lenguajes:** vista de lenguajes de programacion por roles de usuario ([1fcdc7a](https://github.com/j-dominguezp/servercraft-web/commit/1fcdc7a6e03ee1d59df1b17002ffddae70f7d82e))
* **motoresbd:** vista bases de datos por roles de usuario ([87ec017](https://github.com/j-dominguezp/servercraft-web/commit/87ec017e6a798965a9aecfc4c7cf8930140cbe67))
* **proveedor:** vista personalizada por el rol del usuario ([651d64d](https://github.com/j-dominguezp/servercraft-web/commit/651d64d0383689801a5c9cd9984b4a752ac106b3))
* **recuperar contraseña:** se añade pagina y formulario de recuperar contraseña ([fcb6152](https://github.com/j-dominguezp/servercraft-web/commit/fcb61521dacc20200674b6155e600f81e8969fae))
* **servicio web:** vista personalizada por el rol del usuario ([45f062f](https://github.com/j-dominguezp/servercraft-web/commit/45f062f3e68eba2ba269dd89433d35e7a6e2fea4))
* **servidores:** se añade redireccion por rol del lado del servidor ([0ad5131](https://github.com/j-dominguezp/servercraft-web/commit/0ad5131e24110e73decb12100bea6dcb6b6c1209))
* **sistema:** vista personalizada por el rol del usuario ([e5f5ed5](https://github.com/j-dominguezp/servercraft-web/commit/e5f5ed52804fc3b67b177ae747fe1e4f51dfdfb6))
* **tipo problema:** vista personalizada por el rol del usuario ([f21f254](https://github.com/j-dominguezp/servercraft-web/commit/f21f254284ef312671b498d184c128af154de278))
* **tipo solucion:** vista personalizada por el rol del usuario ([1ca16a7](https://github.com/j-dominguezp/servercraft-web/commit/1ca16a732b91a74d8401022c1bce241032879de4))
* **unidaddenegocios:** se realizo la vista de unidad de negocios por rol ([b18b181](https://github.com/j-dominguezp/servercraft-web/commit/b18b18196fa65e0d6e45be8d6bb9d9480b20f653))
* **usuarios:** vista de usuarios diferenciada por tipos de usuarios ([697e87f](https://github.com/j-dominguezp/servercraft-web/commit/697e87f9951ee0a2ddfddc61fcf930d82733f0a9))


### Bug Fixes

* **login:** se corrige link a recuperar contraseña ([e8921ee](https://github.com/j-dominguezp/servercraft-web/commit/e8921eeacdc2bf72fbdc266c393004e83e227cbd))
* **login:** se corrige titulo de pagina ([c6f0632](https://github.com/j-dominguezp/servercraft-web/commit/c6f063218977bb51deba1fb9c8407eb95a13abaf))
* **middleware:** se añade ruta de recuperacion de contraseña a whitelist ([8296faa](https://github.com/j-dominguezp/servercraft-web/commit/8296faaacb12faf65b1d22a643962dc032797fba))

## [1.8.0](https://github.com/j-dominguezp/servercraft-web/compare/v1.7.0...v1.8.0) (2021-11-18)


### Features

* **boton ud:** se añaden condicionales para mostrar las acciones de manera selectiva ([62e15fc](https://github.com/j-dominguezp/servercraft-web/commit/62e15fccf6d77c5b399f4a5cdd6a2dc5f4ba250f))
* **racks:** se añade autorizacion de usuarios por rol a modulo de racks ([031cdc4](https://github.com/j-dominguezp/servercraft-web/commit/031cdc4fa6087785d7ed891d09d12f50e1ef50d0))
* **salas:** se añade autorizacion por rol de usuario a modulo de salas ([9b4f1b1](https://github.com/j-dominguezp/servercraft-web/commit/9b4f1b182543f4b0896f0001f55535f3f768122a))
* **servidores:** se añade autorizacion por rol de usuario ([8034a3e](https://github.com/j-dominguezp/servercraft-web/commit/8034a3e1a90bbc88c83b00754a36949bf0b028d5))

## [1.7.0](https://github.com/j-dominguezp/servercraft-web/compare/v1.6.0...v1.7.0) (2021-11-18)


### Features

* **actividad auditoria:** se agrego la paginación a la vista Actividad Auditoria ([33cf3ac](https://github.com/j-dominguezp/servercraft-web/commit/33cf3ac632025eca3fab38fe95ae65ba3afd3ef7))
* **actividad auditoria:** se agrego nombre a la pagina de Actividad Auditoria ([b3ca730](https://github.com/j-dominguezp/servercraft-web/commit/b3ca730fdb5b9d3f83371a47d1d7dcd62e1bb9c8))
* **documentos servicios:** se agrego la paginación a la vista Documentos Servicios Web ([0696cc3](https://github.com/j-dominguezp/servercraft-web/commit/0696cc31e90e94755a517dd23285267ae079cfe6))
* **documentos servicios:** se agrego nombre de la pagina a la vista Servicios Web ([0f78dcf](https://github.com/j-dominguezp/servercraft-web/commit/0f78dcf60302d94574be387e7352ea0514ea86f9))
* **equipo encargado:** se agrego la paginación a la vista Equipo Encargado ([02c3d76](https://github.com/j-dominguezp/servercraft-web/commit/02c3d76f74cd139574445c3bbfbce46d187bf321))
* **equipo-trabajo:** se agrega nombre a pestaña de equipo de trabajo ([74d55a9](https://github.com/j-dominguezp/servercraft-web/commit/74d55a946372cc181730ea83f63eec92a0612a8b))
* **listadoequipostrabajos:** se agrega paginacion de Equipos de Trabajo ([e41bb14](https://github.com/j-dominguezp/servercraft-web/commit/e41bb148cf67e9882d38693099de4d0afb055456))
* **listadoincidentes:** paginacion incidentes ([8bedf82](https://github.com/j-dominguezp/servercraft-web/commit/8bedf8292183aeb7f78070184a7247e2ebab4150))
* **listadolenguajes:** paginacion Lenguajes de Programacion ([f5e7fe2](https://github.com/j-dominguezp/servercraft-web/commit/f5e7fe290871e8f310e9f08b80e3c473a1902289))
* **listadomotoresbd:** paginacion Motores BD ([48cef89](https://github.com/j-dominguezp/servercraft-web/commit/48cef895c649d8cd231b5807696660991fdafdc2))
* **listadotipoproblemas:** paginacion de Tipo Problemas ([5d59961](https://github.com/j-dominguezp/servercraft-web/commit/5d599612beb4c1b7a110238f2e1c92ed40fca4e6))
* **listadounidadnegocios:** se agrega solo paginacion, dado que nombre pestaña estaba listo ([0b948e4](https://github.com/j-dominguezp/servercraft-web/commit/0b948e45c6ec0f3a9210dea268eeef1b2f859d15))
* **listadousuarios:** se agrega solo paginacion porque nombre pestaña ya estaba listo ([86ad47e](https://github.com/j-dominguezp/servercraft-web/commit/86ad47ee290ee87fe580c38c3fdeed0f2860f656))
* **menu principal informante:** se añadio la Vista en el Menu Pricipal para el Informante ([5682905](https://github.com/j-dominguezp/servercraft-web/commit/56829057e16a09401e9e794fbc10b9e0be980398))
* **menuprincipalresponsable:** se agrega menu principal para el responsable ([7392968](https://github.com/j-dominguezp/servercraft-web/commit/7392968ca3a5c0481f93e105d3b199746c589d4c))
* **paises:** se añade paginacion a listado de paises ([3ed18b6](https://github.com/j-dominguezp/servercraft-web/commit/3ed18b6228f5277156223c4c33d69f96ff1d4c5d))
* **paises:** se vincula paginacion con API ([60c264b](https://github.com/j-dominguezp/servercraft-web/commit/60c264be6ab258466a722e36d8a3063057a245c5))
* **proveedores:** se agrego la paginación a la vista de proveedores ([9ccd163](https://github.com/j-dominguezp/servercraft-web/commit/9ccd163e76a59cd66efd00438bd44391a5eb3e02))
* **racks:** se añade paginacion en listado de racks ([4ed8662](https://github.com/j-dominguezp/servercraft-web/commit/4ed86628fbd7a82a2e4f5d3df50f8ff9ba65198b))
* **racks:** se añade titulo de pestaña a pagina de racks ([2aa7bd6](https://github.com/j-dominguezp/servercraft-web/commit/2aa7bd6e1cb69915eb55e479996d5bea1745be53))
* **racks:** se vincula paginacion con API ([e1b0f6d](https://github.com/j-dominguezp/servercraft-web/commit/e1b0f6d64b9ebf65cc7f0b0436a03a5ae9d1fd4c))
* **regiones:** se añade paginacion a listado de regiones ([c202379](https://github.com/j-dominguezp/servercraft-web/commit/c2023795b25fb8c88e6400724955403afa3bc713))
* **regiones:** se vincula paginacion con API ([1428a22](https://github.com/j-dominguezp/servercraft-web/commit/1428a22a62c46b27ee26338ef166ccb5183408e1))
* **salas:** se añade paginacion para listado de salas ([8941582](https://github.com/j-dominguezp/servercraft-web/commit/8941582265bc1abafd9b2d9032a21867c339b3ed))
* **salas:** se añade titulo de pestaña en pagina de salas ([6dd1564](https://github.com/j-dominguezp/servercraft-web/commit/6dd1564ffdc05ae55231fe3b894047d10ffe60fc))
* **salas:** se vincula paginacion con API ([93c084d](https://github.com/j-dominguezp/servercraft-web/commit/93c084dd9901cfc93237c37c0da0472c3934a546))
* **servicios web:** se agrego head a la pagina de Servicios Web ([46f81c9](https://github.com/j-dominguezp/servercraft-web/commit/46f81c97cb0df173abe185684f0cb098faadfba5))
* **servicios web:** se agrego la paginación a la vista Servicios Web ([7cc2536](https://github.com/j-dominguezp/servercraft-web/commit/7cc2536acd18f9d5ea347dce01b158e1086876ef))
* **sistemas:** se agrego la paginación a la vista de sistemas ([383b322](https://github.com/j-dominguezp/servercraft-web/commit/383b3228cf31fd134c32597f840182aa2289ffb9))
* **tipo solucion:** se agrego la paginación a la vista Tipo Solucion ([a39575c](https://github.com/j-dominguezp/servercraft-web/commit/a39575c40556885ede0cc49d78aa1ffd7017a031))
* **tipo solucion:** se agrego nombre a la pagina de la vista Tipo Solucion ([01c44f9](https://github.com/j-dominguezp/servercraft-web/commit/01c44f96951c4af14244b9caf1f7caa33a42a837))
* **tipo-problemas:** nombre de pagina cambiado a Tipo Problemas - Servercraft ([e697558](https://github.com/j-dominguezp/servercraft-web/commit/e697558def1e1c31c88d2f16dbbce50aa2ae188a))


### Bug Fixes

* **actividad auditoria:** se modifica el nombre de la pagina Actividad Auditoria ([55f91ae](https://github.com/j-dominguezp/servercraft-web/commit/55f91ae0cdfb7e85b460d9524eded567dcbae4b2))
* **equipo encargado:** se corrige el nombre de la pagina ([070b836](https://github.com/j-dominguezp/servercraft-web/commit/070b83659d20568240fd365c8e7f1a4bdb49b6a7))
* **equipo encargado:** se corrige la cantidad de filas cargadas ([fc6b9b6](https://github.com/j-dominguezp/servercraft-web/commit/fc6b9b617379a3dc7ddb6b785239a7ea79e8ead8))
* **lenguajes:** se arregla nombre de pestaña de leguaje a lenguajes ([5993e6c](https://github.com/j-dominguezp/servercraft-web/commit/5993e6c0ce8d65a7f65f6c1bc8fae409d1db2089))
* **menu informante:** corrección tamaño de los menus ([64d2bc2](https://github.com/j-dominguezp/servercraft-web/commit/64d2bc2e65b9799a8fcb5cf461ce546e4f2d6a07))
* **menu principal informante:** se agrego la variable Key en el DIV para el menu ([6794417](https://github.com/j-dominguezp/servercraft-web/commit/6794417c55e257af2397067ed53949eb07b7d75d))
* **menuprincipalresponsable:** se modifico orientacion de botones del menu ([04b5b77](https://github.com/j-dominguezp/servercraft-web/commit/04b5b77a5cabdba4e4ab1c17b3a1ab41f75e467a))
* **motores-bd:** se cambia nombre de pestaña de motores de bases de datos a bases de datos ([c820a96](https://github.com/j-dominguezp/servercraft-web/commit/c820a969f90c86d8269e3b97c69ad2987e64ae53))

## [1.6.0](https://github.com/j-dominguezp/servercraft-web/compare/v1.5.0...v1.6.0) (2021-11-16)


### Features

* **menus y roles:** se añade condicion para visualizar menu segun rol y se añade menu de consultor ([33af23e](https://github.com/j-dominguezp/servercraft-web/commit/33af23e2af54f77d34d421d0b335fd08a79b8302))


### Bug Fixes

* **http:** se corrige uso de useUsuarioByToken en otros archivos ([ceff62c](https://github.com/j-dominguezp/servercraft-web/commit/ceff62c788734f34a78704657c0087a342d138a6))
* **http:** se elimina useUsuarioByToken en favor de usar directamente useUsuario ([5675c70](https://github.com/j-dominguezp/servercraft-web/commit/5675c70c69f86aca0b300615b166229251411d7a))
* **menu administrador:** se refactoriza menu y se actualiza diseño de menu lateral ([1050983](https://github.com/j-dominguezp/servercraft-web/commit/10509830ea4306b6eedd9d3815f6eaf70f2d134f))
* **menu consultor:** se re ordena codigo para facilitar comprension ([cc1541d](https://github.com/j-dominguezp/servercraft-web/commit/cc1541dbf07f9458f5530ec86c55e97a428eb0df))

## [1.5.0](https://github.com/j-dominguezp/servercraft-web/compare/v1.4.0...v1.5.0) (2021-11-13)


### Features

* **actividad auditoria:** filtro preliminar de Actividad Auditoria ([6303026](https://github.com/j-dominguezp/servercraft-web/commit/63030261a9cefdae4574d7f2fb5bbdfc2e14c3de))


### Bug Fixes

* **actividad auditoria:** finalización del filtro de actividada auditoria ([7cb4eb1](https://github.com/j-dominguezp/servercraft-web/commit/7cb4eb1a230c615ef6ebb08562837b895e71b398))
* **actividad registro:** corrección del Placeholder del Searchbox ([c256901](https://github.com/j-dominguezp/servercraft-web/commit/c256901386ce17f0997cfd7c856f6c9728c398b6))

## [1.4.0](https://github.com/j-dominguezp/servercraft-web/compare/v1.3.0...v1.4.0) (2021-11-12)


### Features

* **listadoincidentes:** se agrega filtro de query funcionando pero falta estado ([ade8238](https://github.com/j-dominguezp/servercraft-web/commit/ade8238ba5a04b572402a505e09e77058003e7c4))
* **listadotipoproblemas:** se agrego filtrado de tipoproblemas por query ([5ca747e](https://github.com/j-dominguezp/servercraft-web/commit/5ca747eedc53bc2830ed1aed2bc152a3df3d41e1))
* **servidores:** se añade paginacion ([b6c65fb](https://github.com/j-dominguezp/servercraft-web/commit/b6c65fb46e2cebf72ece34e7d14e2494abb53cc1))
* **servidores:** se añade titulo de pestaña ([ffad44c](https://github.com/j-dominguezp/servercraft-web/commit/ffad44c5225622262195db6b5968266dca35b935))
* **tipo solucion:** se añade el filtro para la vista tipo solucion de incidentes ([b0d555b](https://github.com/j-dominguezp/servercraft-web/commit/b0d555be5792ee8b2b55c0e89d3eb6f8ad0983a3))


### Bug Fixes

* **listadoincidentes:** cambios a estado vacio de estado incidente ([c7e1c98](https://github.com/j-dominguezp/servercraft-web/commit/c7e1c98a01183d34a2d987637238dea0187e2b93))
* **listadoincidentes:** se realiza el cambios a filtrado de incidentes para que funcone todo ([8b41606](https://github.com/j-dominguezp/servercraft-web/commit/8b41606b0ddceed2dec40e03d60aa9fd42c0e337))
* **listadoincidentes:** se vuelve a agregar carpeta que daba problemas ([c9280ca](https://github.com/j-dominguezp/servercraft-web/commit/c9280ca64c77142326e0d7771aedec18db4e2f6f))
* **listaodincidentes:** se borra carpeta con problemas ([1869565](https://github.com/j-dominguezp/servercraft-web/commit/18695657ad19b42b8fa80bf533526ad4f08b364f))


### Others

* **dependencias:** se añade dependencia para paginacion ([8349097](https://github.com/j-dominguezp/servercraft-web/commit/8349097f58a1c35fa1eebb72d1960c64c1fb27ed))

## [1.3.0](https://github.com/j-dominguezp/servercraft-web/compare/v1.2.0...v1.3.0) (2021-11-11)


### Features

* **registro de actividad:** se añade pagina y estructura para visualizar el registro de actividad ([9f582af](https://github.com/j-dominguezp/servercraft-web/commit/9f582af31e62889fab01b193aaa9c81a7059313f))
* **registro de actividad:** se añade y vincula componente para visualizar la actividad del sistema ([4346a4a](https://github.com/j-dominguezp/servercraft-web/commit/4346a4a5e8d561300f40c6d296835d8d5c29da17))


### Bug Fixes

* **menu principal:** se añade link a pagina de registro de actividad ([cb513ba](https://github.com/j-dominguezp/servercraft-web/commit/cb513ba79aa08f9714199024521a5dcc3a7babe9))

## [1.2.0](https://github.com/j-dominguezp/servercraft-web/compare/v1.1.1...v1.2.0) (2021-11-11)


### Features

* **documentos servicios:** se añade el filtro en la vista documentos de los servicios ([5b3ed50](https://github.com/j-dominguezp/servercraft-web/commit/5b3ed501ed3d126e93d77669b0f43f0046015b87))
* **equipo encargado:** estrucutra filtros equipo encargado ([e0d81a3](https://github.com/j-dominguezp/servercraft-web/commit/e0d81a364a6a3a336440fa3b7aafaefd5b0f9d50))
* **listadoequipostrabajo:** se realiza los filtros en la seccion Equipo de Trabajo ([9e93b6a](https://github.com/j-dominguezp/servercraft-web/commit/9e93b6a6b2b7f1b13a3a3e14583ce65dba024791))
* **listadolenguajes:** se agrega el filtro a lenguajes de programacion ([04bc46f](https://github.com/j-dominguezp/servercraft-web/commit/04bc46f6befb1cc93f71785a5987ee8d336e2fef))
* **listadomotoresbd:** se agrega filtro a motoresBD ([d0ca501](https://github.com/j-dominguezp/servercraft-web/commit/d0ca50108c8ddb1c4de39ab783e7bd72947118b9))
* **listadounidadnegocios:** se realizo el filtrado en ListadoUnidadNegocios ([0ccd08f](https://github.com/j-dominguezp/servercraft-web/commit/0ccd08f61e76c46c63fb2d114fbe11f6ec25f0c6))
* **listadousuarios:** se realizaron filtros para el listadoUsuarios ([a2d1c46](https://github.com/j-dominguezp/servercraft-web/commit/a2d1c4651b7f2b27a71f75765f8b1cacb235b282))
* **listaequipostrabajos:** se realiza el filtro que faltaba pero no hace la filtracion como otros ([730bae2](https://github.com/j-dominguezp/servercraft-web/commit/730bae200d562b647603bc2526d966422fad1791))
* **paises:** se añade filtro de texto para busqueda de paises ([d9f4818](https://github.com/j-dominguezp/servercraft-web/commit/d9f48188672262c67af3117087ab8342c525812d))
* **proveedores:** estructura filtro general Proveedores ([9196c07](https://github.com/j-dominguezp/servercraft-web/commit/9196c07fb931a8451f5d6cb8c15f867236981624))
* **racks:** se añade filtro por sala, region y pais ([6cd46c0](https://github.com/j-dominguezp/servercraft-web/commit/6cd46c0659279471be4f4e502f1f4b6937547b92))
* **regiones:** se añade filtro de texto y de pais para listado de regiones ([c22b093](https://github.com/j-dominguezp/servercraft-web/commit/c22b093d75b4047d69b17ddf6743b45fda621f8e))
* **salas:** se añaden filtros por texto, region y pais ([457b3c3](https://github.com/j-dominguezp/servercraft-web/commit/457b3c33509299295ad60acada7ad1a4a93afb21))
* **servicio web:** se añade el filtro en la vista del servicio web ([12bbf7c](https://github.com/j-dominguezp/servercraft-web/commit/12bbf7ca3160a05c5b9707aeeece66ba9c47dfb0))
* **sistema:** filtros para la vista de sistemas, a excepcion de nivel de seguridad y sensibilidad ([9578fc1](https://github.com/j-dominguezp/servercraft-web/commit/9578fc1e1fe9c64067f8a27e301b51f7e96f3f39))


### Bug Fixes

* **documento servicio:** corrección del tamaño barra de busqueda ([33b999b](https://github.com/j-dominguezp/servercraft-web/commit/33b999b80a8be74c15ec8ea77556efd5b2080571))
* **documento servicio:** corrección según los comentarios en los pull request ([f02092a](https://github.com/j-dominguezp/servercraft-web/commit/f02092a4c5a2708fb12f55a5bfc92670d1f31af3))
* **equipo encargado:** corrección del tamaño de la barra de busqueda del filtro ([d215145](https://github.com/j-dominguezp/servercraft-web/commit/d21514558a5085fccf952b571045d4d48c9194a0))
* **equipo encargado:** corrección del tamaño del searchbox y el combobox ([526f4ce](https://github.com/j-dominguezp/servercraft-web/commit/526f4ce66aabe18484f7daae16f1696c18139ce1))
* **equipo encargado:** corrección en el http, cambio de proveedor_sistema a proveedor ([6985d11](https://github.com/j-dominguezp/servercraft-web/commit/6985d1196d3a91e80af5f37351bf09066d6f6302))
* **equipotrabajo:** arreglo de comentario a pull request ([3ed584f](https://github.com/j-dominguezp/servercraft-web/commit/3ed584fb298346608778743deea42a7ac7fd5d52))
* **equipotrabajo:** cambios a la llamada de unidad de negocio ([36e0b68](https://github.com/j-dominguezp/servercraft-web/commit/36e0b68a961b919b57b74a6d6b8b4c3d0226a63e))
* **listadoequipostrabajos:** arreglos a EquiposTrabajos para lograr el filtro ([2d4aee8](https://github.com/j-dominguezp/servercraft-web/commit/2d4aee81f475c9cebf37ab3b195a7b325b811042))
* **listadoequipostrabajos:** se arregla problemas con el filtrado, ahora funcionan perfectamente ([147eb55](https://github.com/j-dominguezp/servercraft-web/commit/147eb55a18cbc084b1572604f64d13637e5b651f))
* **listadoequipostrabajos:** se cambio distancia de boton limpiar con titulo ([e0266f5](https://github.com/j-dominguezp/servercraft-web/commit/e0266f523610d3bd5553be0320450d940b930ce7))
* **listadoequipostrabajos:** se quitó boton ocultar filtros ([75bba69](https://github.com/j-dominguezp/servercraft-web/commit/75bba69e106fd1abe7b40b59d214a2dff35de0a5))
* **listadolenguajes:** se elimino codigo que no se utiliza ([2842e62](https://github.com/j-dominguezp/servercraft-web/commit/2842e6297d5e97e65569bf7b816d1ba5f17fea90))
* **listadolenguajes:** se quitó el boton para ocultar filtro ([f87078c](https://github.com/j-dominguezp/servercraft-web/commit/f87078c92ad9120b49715b2dd7c2993d093a7e12))
* **listadomotoresbd:** se eliminó codigo sin utilizar ([9619329](https://github.com/j-dominguezp/servercraft-web/commit/9619329dbc1a6f78ecb821873e7b9dc8fcea700c))
* **listadomotoresbd:** se quitó boton para ocultar filtros ([754d9d4](https://github.com/j-dominguezp/servercraft-web/commit/754d9d426f636d10e0d23812db949c23baf858af))
* **listadounidadnegocios:** se arregla problema con borrar la query, filtro funcionando perfecto ([b78b6aa](https://github.com/j-dominguezp/servercraft-web/commit/b78b6aa9d09b8ce12e647e5456acf10a4bb41318))
* **listadounidadnegocios:** se quitó boton ocultar filtros ([5cd9c34](https://github.com/j-dominguezp/servercraft-web/commit/5cd9c348f41f479b2cb53c70327199f9df21433e))
* **listadousuarios:** arreglo de comentario solicitado en pull request ([056a983](https://github.com/j-dominguezp/servercraft-web/commit/056a983ad54a7400e2306fea5b7bb313c103826f))
* **listadousuarios:** se eliminó codigo que no se utilizaba ([8a1cbe0](https://github.com/j-dominguezp/servercraft-web/commit/8a1cbe0986e6a43f5dc2c12e6a8aea4250aec4ee))
* **listadousuarios:** se quitó el boton ocultar filtros y dejo filtros en una linea ([eb1e508](https://github.com/j-dominguezp/servercraft-web/commit/eb1e50817a52d13227c40dcb833605f9e48d90dd))
* **listaousuarios:** se arregla problema con borrar query, filtros totalmente funcionando ([ed499cd](https://github.com/j-dominguezp/servercraft-web/commit/ed499cd6cebeba3d5cb285855dc7c69b46f3b82a))
* **proveedor:** corrección según los comentarios en el git pull ([6703898](https://github.com/j-dominguezp/servercraft-web/commit/67038983a522f53c8ebc5e9fe2a5e9a5c55cb718))
* **racks:** se añade soporte para filtros en listar racks ([6effb40](https://github.com/j-dominguezp/servercraft-web/commit/6effb40e8a1951deff86a7957b0d79c85e8bb3cc))
* **salas:** se añade soporte para filtros por region y pais ([5589600](https://github.com/j-dominguezp/servercraft-web/commit/5589600ccaf3dce0772635368110ef0fd6e7bf68))
* **salas:** se muestran siempre los filtros en listado de salas ([cf4ec2e](https://github.com/j-dominguezp/servercraft-web/commit/cf4ec2e79a528e3b35879da217a08f7530e175cc))
* **sistema:** corrección de las variables nivelSeguridad y nivelSensibilidad al abrir los filtros ([1235b15](https://github.com/j-dominguezp/servercraft-web/commit/1235b15cb21a148f2b29d109463ad552e715c58c))
* **sistema:** corrección en el http de sistemas, cambios de las variables seguridad y sensibilidad ([45524bf](https://github.com/j-dominguezp/servercraft-web/commit/45524bf0fe8c6f6c97ea0123e6b37899064af2da))
* **sistemas:** corrección según los comentarios en el git pull ([11b10a9](https://github.com/j-dominguezp/servercraft-web/commit/11b10a9bf6fec449847fd3458e947792991062ec))


### Reverts

* Revert "feat(listadomotoresbd): se agrega filtro a motores BD" ([07530ed](https://github.com/j-dominguezp/servercraft-web/commit/07530ed5d9a2da499d16d9210993f3749b687f40))

### [1.1.1](https://github.com/j-dominguezp/servercraft-web/compare/v1.1.0...v1.1.1) (2021-11-04)


### Bug Fixes

* **formulario servidores:** el check de garantia afectaba la creacion al no renderizarse, arreglado ([d9fb075](https://github.com/j-dominguezp/servercraft-web/commit/d9fb075756d79ff0a76a9bb3ba27fce178b6f1f8))
* **incidentes:** se corrige formulario de incidentes ([6090ebc](https://github.com/j-dominguezp/servercraft-web/commit/6090ebcb675906e6de5fa5750e8d89a77638d6b6))
* **incidentes:** se corrige seleccion de equipo ([9dca428](https://github.com/j-dominguezp/servercraft-web/commit/9dca428027aa1b8862abb07162f7cdac3b674096))
* **incidentes:** sE corrige seleccion de sistema en creador de incidentes ([0098fd1](https://github.com/j-dominguezp/servercraft-web/commit/0098fd1a28e7d73dea50cd089b7be853c09f8486))

## [1.1.0](https://github.com/j-dominguezp/servercraft-web/compare/v1.0.1...v1.1.0) (2021-11-04)


### Features

* **autenticacion:** cuando el usuario esta logueado se redirige del login al menu ([3f5390e](https://github.com/j-dominguezp/servercraft-web/commit/3f5390e1ed26d7940904d0f2158db98aa49938ab))
* **autenticacion:** se añade verificacion del lado del servidor para redirigir en base a login ([15b10e1](https://github.com/j-dominguezp/servercraft-web/commit/15b10e19fcda82e6ba55bb22a5ce84dfad4606bc))
* **servidores:** se añaden filtros al listado ([86c99b2](https://github.com/j-dominguezp/servercraft-web/commit/86c99b2a89806f4edfb6c85c20ba5d66b6e05f83))


### Bug Fixes

* **arquitectura:** se mueve sidebar desde moleculas a organismos ([b6c6804](https://github.com/j-dominguezp/servercraft-web/commit/b6c680475bc63cf332fd5012a68b4bb037c485df))
* **listado servidores:** se corrige error al presionar X en search box ([9b212aa](https://github.com/j-dominguezp/servercraft-web/commit/9b212aa105cdfc8cc5c7059c9468ba24bbeaf83d))
* **login:** se remueve redireccion del lado del cliente en favor de la estrategia de middleware ([5f6755a](https://github.com/j-dominguezp/servercraft-web/commit/5f6755a51f22e053a82e5f92c437f0c240b661e5))
* **middleware:** mejora semantica de condicional ([816a117](https://github.com/j-dominguezp/servercraft-web/commit/816a1170e536880ba50d72e42fecca78d0db85b3))
* **middleware:** se añade deteccion para no redireccionar consultas a archivos estaticos (imagenes) ([36275f1](https://github.com/j-dominguezp/servercraft-web/commit/36275f18df4a778ab5430f78dd316c1fb7b3a68c))
* **middleware:** se añaden logs para verificar funcionamiento en servidor ([dab3aa8](https://github.com/j-dominguezp/servercraft-web/commit/dab3aa82fbeb2c163d850ce40b36ea4cb4967cb8))
* **middleware:** se corrige condicion para forzar valores booleanos puros ([47b879f](https://github.com/j-dominguezp/servercraft-web/commit/47b879f14d24826811fff125ee92086cb545fdfb))
* **middleware:** se corrige error que no permitia cargar imagenes por interrupcion del middleware ([a326f78](https://github.com/j-dominguezp/servercraft-web/commit/a326f784a111ffb4fb3a35d30fda1fb37ad41208))
* **middleware:** se fuerza la redireccion por GET (code 302) ([bb817a2](https://github.com/j-dominguezp/servercraft-web/commit/bb817a2dacea74b5ff59814128cff985aa8e78ba))
* **middleware:** se implementa deteccion de assets utilizando otra API disponible ([f6235c1](https://github.com/j-dominguezp/servercraft-web/commit/f6235c1cf1e0e01441d3cf72582e288a0208ea68))
* **middleware:** se reemplaza href por pathname para evitar leer el dominio de la url ([0c752fd](https://github.com/j-dominguezp/servercraft-web/commit/0c752fda26faee92258eda1f724d710b1d7992b6))
* **middleware:** se remueven logs sin uso ([94f85f5](https://github.com/j-dominguezp/servercraft-web/commit/94f85f57fe757a7c2a8c98571b17cf97957ecc4c))
* **middleware:** se utiliza proceso de deteccion por inclusion en vez de match perfecto ([5da2bbb](https://github.com/j-dominguezp/servercraft-web/commit/5da2bbb731b20cc46fdb5ea4251d83804cf519f5))
* **proveedores:** se corrige nombre de funcion swr importada ([bd4c62e](https://github.com/j-dominguezp/servercraft-web/commit/bd4c62ed537a620e04ac3ad14d20b78caa649fc1))
* **ubicaciones:** se corrige importacion de sidebar ([2e26ccb](https://github.com/j-dominguezp/servercraft-web/commit/2e26ccbb1503d5f432c94b89c11ef69f9bc8c450))


### Performance Improvements

* **middleware:** optimizacion final de condicional ([57dd0ef](https://github.com/j-dominguezp/servercraft-web/commit/57dd0ef80eeb84e2c844a7798c9b3dfb8ef590e4))
* **middleware:** se mejora validacion para utilizar menos memoria ([89b5127](https://github.com/j-dominguezp/servercraft-web/commit/89b51277d10805615989a7286935240e06d8f88e))


### Code Refactoring

* **formulario equipoencargado:** se generar un useEfect para gernerar los datos de equipoEncar ([b700297](https://github.com/j-dominguezp/servercraft-web/commit/b7002974b5d790fe1fdca842d752ec3abaff592c))


### Build System

* **next config:** se des habilita configuracion de modulos esm para que no rompa react-hook-form ([e0d409a](https://github.com/j-dominguezp/servercraft-web/commit/e0d409aa98989070e0c0ad8b7bcec685b6990001))


### Others

* **npm packages:** se actualizan paquetes a ultima version segura ([8a1040c](https://github.com/j-dominguezp/servercraft-web/commit/8a1040cd9652e12466e207b175e9cd7a7a058ff3))

### [1.0.1](https://github.com/j-dominguezp/servercraft-web/compare/v1.0.0...v1.0.1) (2021-11-03)


### Bug Fixes

* **proveedores:** se corrige nombre de funcion swr importada ([d8b182f](https://github.com/j-dominguezp/servercraft-web/commit/d8b182feb0d0fd45e37f116723de9b47dec00166))

## 1.0.0 (2021-11-03)


### Features

* **api y listado:** creacion de consultas para aplicar la api y llamdas get a los listados vistas ([e946a75](https://github.com/j-dominguezp/servercraft-web/commit/e946a75ffd80f7c00a57ee17db1f502c29a20d52))
* **api:** nuevo servicio para usar la api, se implemente login y get del profile,usuarios WIP ([e434a79](https://github.com/j-dominguezp/servercraft-web/commit/e434a79d8d2580b2142a4914121e07f1c67888f9))
* **arquitectura:** arquitectura del proyecto ([0871eda](https://github.com/j-dominguezp/servercraft-web/commit/0871eda8ff5fb163db9c11796b223f2ed441f07e))
* **avances menu:** se agregar botontes y diseño de la vita menú ([721900d](https://github.com/j-dominguezp/servercraft-web/commit/721900dc76b69177c0fb9db1ec0544bae709b144))
* **axios:** configuracion inicial para el futuro uso de la api ([1bc6d35](https://github.com/j-dominguezp/servercraft-web/commit/1bc6d359197e5a0ed7e0d983c8d226f024ddcfbb))
* **boton ud:** nuevo dropdown para usar en las tablas, se usa para Editar y Eliminar una columna ([89fa8e5](https://github.com/j-dominguezp/servercraft-web/commit/89fa8e514154f991f8477d0d7b765db3d490e772))
* **botonud:** se añade booleando para habilitar opcion de ver detalle de elemento ([c117b40](https://github.com/j-dominguezp/servercraft-web/commit/c117b407f4c30e8b9e882d3a82cc92fc83c3b53e))
* **configuracion del proyecto:** configuracion de prettier para usar indentacion de 4 espacios ([6c6bd89](https://github.com/j-dominguezp/servercraft-web/commit/6c6bd896767e33e2703d43cddd327da6fb67f0d3))
* **consultas:** finalizadas las consultas con sus respectivos crud de la api, para ser utilizadas ([2ff11a9](https://github.com/j-dominguezp/servercraft-web/commit/2ff11a969d5cd02bc05687bb73a2ce7c06f4f428))
* **controlled checkbox:** nuevo componente checkbox ([ac8710d](https://github.com/j-dominguezp/servercraft-web/commit/ac8710df2bf689016d3ec86942b6a84c7fd87715))
* **crud equipo trabajo:** creacion de crud y vista de listado de equipo de trabajo, falta mejorar ([26f0129](https://github.com/j-dominguezp/servercraft-web/commit/26f012970277ce14e8e932d03bddbbf5f03eb514))
* **crud equipo trabajo:** se realiza la vista de equipo de trabajo además del crud completo ([6b804ef](https://github.com/j-dominguezp/servercraft-web/commit/6b804efeca93228619c5ee467f161925ebfb8182))
* **crud incidentes:** crud de incidentes, falta aun por terminar las demas relaciones para terminar ([813c580](https://github.com/j-dominguezp/servercraft-web/commit/813c58086475396604d4c676d3f8501cc859f7ab))
* **crud lenguaje:** se crea el crud y la vista del lenguaje de programación ([2ca69d7](https://github.com/j-dominguezp/servercraft-web/commit/2ca69d79858e816b6b3f44b0ca270aa1b4be10dc))
* **crud proveedores:** se creo formulari de proveedores ([74eaa6f](https://github.com/j-dominguezp/servercraft-web/commit/74eaa6fb9aa564b6c8fcfd15345e4f2b2562d52c))
* **crud tipo de problema:** se crea crud tipo de problemas en la seccion de incidentes ([fdefb24](https://github.com/j-dominguezp/servercraft-web/commit/fdefb241ae2f3844c74f39288ae248e9ff526fcb))
* **crud tipo de solucion:** crud de tipo de solucion de la seccion de incidentes ([c12e775](https://github.com/j-dominguezp/servercraft-web/commit/c12e7755b65c2aba89bf7cdbc19d28931688a3fd))
* **crud unidad de negocio:** se realiza el crud de la vista unidad de negocio ([6d268f4](https://github.com/j-dominguezp/servercraft-web/commit/6d268f4ffb3495288f040021af5af992c257576a))
* **dependencias:** se añadio react-hot-toaster para hacer uso de toast en mensajes de exito y error ([f2b9b98](https://github.com/j-dominguezp/servercraft-web/commit/f2b9b9894bf119b830c3ee68633872e41074df55))
* **detalleequipoproveedor:** se creó el DetalleEquipoProveedor y los cambios asociados ([73692af](https://github.com/j-dominguezp/servercraft-web/commit/73692af420a67f5ce8c7b95791c0812cd1ee76bf))
* **detalleusuario:** cambios asociados al detalleusuario ([71cffae](https://github.com/j-dominguezp/servercraft-web/commit/71cffaecc0d91f29f25f8c347065215c0f8e56d7))
* **detalleusuario:** se creo la vista detalle usuario con cambios asociados ([ce188fe](https://github.com/j-dominguezp/servercraft-web/commit/ce188fead52f46c4a61a6510a70c14beb8317999))
* **home login:** react hook form y yup instalados para la utilización de formularios y validacion ([8e36b7d](https://github.com/j-dominguezp/servercraft-web/commit/8e36b7d7d278755aa2c24127c2c539410fc33541))
* **home:** nueva vista de login, funcionalidades por implementar ([094ee1c](https://github.com/j-dominguezp/servercraft-web/commit/094ee1ca14bd4082ac9f1f1f140f621e8ea6d105))
* **home:** pagina home en estado inicial ([84e318b](https://github.com/j-dominguezp/servercraft-web/commit/84e318bf54cba382c189a71aa129dbbfdcf68bae))
* **home:** se cambia titulo de la vista home ([c1a5718](https://github.com/j-dominguezp/servercraft-web/commit/c1a5718d0cb3129ff9363e0afcf156acf3204132))
* **incidentes:** cRUD funcionando, falta ver detalles, se rellenan las llamadas a la api necesarias ([e064b81](https://github.com/j-dominguezp/servercraft-web/commit/e064b815d8e5c5ae3cfb5bdfe9522649e037d5c5))
* **incidentes:** nuevo listado de incidentes, layout para sidebar, sidebar para incidentes ([1d2b030](https://github.com/j-dominguezp/servercraft-web/commit/1d2b030f1efbdd8b89357f3d24c780daf497938c))
* **incidentes:** se añade modal de detalle de incidente ([8d4f80a](https://github.com/j-dominguezp/servercraft-web/commit/8d4f80af7ac4967a136a264a058e9be41930f0d6))
* **lenguajes:** se agrega vista de lenguajes de programacion ([b54e654](https://github.com/j-dominguezp/servercraft-web/commit/b54e65467a18c0694c5b41f3ed1fa20206374b4c))
* **listado de usuarios:** boton ver detalle agregado ([7b92eb8](https://github.com/j-dominguezp/servercraft-web/commit/7b92eb813865cf3609156227b9b12ea5396d03ee))
* **listado de usuarios:** tabla de ejemplo a poblar en un futuro ([a6b567b](https://github.com/j-dominguezp/servercraft-web/commit/a6b567b97b1713b4cb8c8f43a2f260f8917c0caf))
* **listado usuarios:** se refactorizan los inputs y los toast, se añade el rol a la tabla y fixes ([c508b5c](https://github.com/j-dominguezp/servercraft-web/commit/c508b5c5477eaea093c59419efb77fca9399deaf))
* **logo:** nuevo logo para navbar ([412e23b](https://github.com/j-dominguezp/servercraft-web/commit/412e23b2a368e3782ee39ff5c9ebbbb929bd206c))
* **menu principal:** avance inicial ([3aea132](https://github.com/j-dominguezp/servercraft-web/commit/3aea1320c7487f774ba76b3ff4256fd37fe83fe5))
* **menuprincipal:** se crea nuevo boton menu, se agregan  grid y carpeta con iconos ([066eb73](https://github.com/j-dominguezp/servercraft-web/commit/066eb7351118ab6937e41079caeeac26ff2c3ffa))
* **menuprincipal:** se quitan importaciones inecesarias ([bf9f14c](https://github.com/j-dominguezp/servercraft-web/commit/bf9f14c69e717c260e288d179db6b56093feac94))
* **menusistemas:** se agregan vistas de raks, salas, tipo de solucion y tipos de problemas ([c32e117](https://github.com/j-dominguezp/servercraft-web/commit/c32e11762ffe04ed1d6a0b24abcc64a3aa3d1d41))
* **motores de base de datos crud:** se agregan crud de motores bd y se corrigen calls y endpoint ([f7f22c1](https://github.com/j-dominguezp/servercraft-web/commit/f7f22c14006c3c494e44811908c6cfc3bea1e574))
* **motores-bd:** se crea vista de motores de bd ([c2713ca](https://github.com/j-dominguezp/servercraft-web/commit/c2713ca0226b64a28aa3d8b4d3003cd209337e60))
* **next config:** dominio del s3 de imagenes añadido al next config ([15e06ba](https://github.com/j-dominguezp/servercraft-web/commit/15e06bab73d00f9a1933fd3e75b1e5e5f0bfc461))
* **pagina 404:** nueva pagina para cuando una ruta no existe ([6019d1b](https://github.com/j-dominguezp/servercraft-web/commit/6019d1bccf8d71b38deb52f71138f71b886e68f7))
* **perfil usuario:** funcionalidad implementada en el perfil del usuario ([0531710](https://github.com/j-dominguezp/servercraft-web/commit/053171072797346178677b17f9e6ba7cf6d41915))
* **proveedor:** se añade la función de obtener detalle del proveedor (HTTP) ([5c0ca2d](https://github.com/j-dominguezp/servercraft-web/commit/5c0ca2dd131c0fe3db79b15ba9cb99860de9573e))
* **proveedor:** se crea el detalle del proveedor como opción del listar proveedores ([cbc2490](https://github.com/j-dominguezp/servercraft-web/commit/cbc249009b3e083a3d61ae1de1fb341a13eeab8f))
* **proyecto:** configuracion para iconos de fluent ui ([e2bbdd5](https://github.com/j-dominguezp/servercraft-web/commit/e2bbdd58ae82e490e592c82f82687c232d856775))
* **proyecto:** inicializando el proyecto con las dependencias base ([9378160](https://github.com/j-dominguezp/servercraft-web/commit/93781604a35d371d6f65c700c424e4a19b7e04b0))
* **proyecto:** links y redirecciones temporales para navegar dentro de la pagina ([7188468](https://github.com/j-dominguezp/servercraft-web/commit/7188468ad4c3b9cb95698f2cbf43145934242e85))
* **sala servidor:** crud funcionando ([faa96b9](https://github.com/j-dominguezp/servercraft-web/commit/faa96b902a043b217eb392b648812447ee16be30))
* **salas:** crud funcionando en salas ([32e1ed7](https://github.com/j-dominguezp/servercraft-web/commit/32e1ed7e4f9a68d6f5a767b6872ad8331bc384c7))
* **servidor:** cRUD en Servidor, falta la vista de detalles ([f4ca3f5](https://github.com/j-dominguezp/servercraft-web/commit/f4ca3f5462fd910c0b6fc093e2b25ecb1e3bd1f5))
* **servidores:** listadores de servidores, vista de servidores ([250043f](https://github.com/j-dominguezp/servercraft-web/commit/250043fa94cce02f01aab81d71e17f1663008177))
* **servidores:** se añade boton y modal de ver detalle de servidor ([55853f0](https://github.com/j-dominguezp/servercraft-web/commit/55853f06c370edf0f5ec661424ac970220867225))
* **servidor:** se añade componente de información de servidor y sus relaciones ([792c01b](https://github.com/j-dominguezp/servercraft-web/commit/792c01b0c14b77a5753c412aa6967e8243f4a28a))
* **sidebar miembros:** menu para navegar en la seccion de miembros ([8d70ae3](https://github.com/j-dominguezp/servercraft-web/commit/8d70ae3d4992a15ef67ce3be32b5a3b259d2dfe9))
* **sistema:** nuevo CRUD para sistemas, falta realizar la vista de detalle ([7daa9e0](https://github.com/j-dominguezp/servercraft-web/commit/7daa9e057e4da809e090a66241774787f716d8ab))
* **sistema:** se realizo el detalle del sistema ([0975b42](https://github.com/j-dominguezp/servercraft-web/commit/0975b4269c5537d2ef1befbdfdfb7d1d4146f496))
* **sistemas:** nueva vista de sistemas ([d5ba216](https://github.com/j-dominguezp/servercraft-web/commit/d5ba216702eed21321f4881c7f6d072fa5b2ccb9))
* **tailwind:** color primario implementado ([6195994](https://github.com/j-dominguezp/servercraft-web/commit/619599486c6426132890cf1200066a59f0d24876))
* **tema de tailwind:** nuevos colores para estados ([ddd994b](https://github.com/j-dominguezp/servercraft-web/commit/ddd994b6a80749f6bbab7613268a9c5157a8ca33))
* **ubicaciones:** la obtencion de regiones ya no depende exclusivamente de un pais ([48fdeed](https://github.com/j-dominguezp/servercraft-web/commit/48fdeedc829f5d84613840158c372efc68811931))
* **ubicaciones:** nuevo crud de paises y regiones ([49307a8](https://github.com/j-dominguezp/servercraft-web/commit/49307a8740486ef083129bf5ebc2efa30bc7a7e3))
* **usuarios & miembrostemplate:** pagina en donde estaran los usuarios y su template ([53dfc10](https://github.com/j-dominguezp/servercraft-web/commit/53dfc1012ba74054bd824dfadd19861874f55080))
* **usuarios:** creacion de usuario agregada, falta añadir mensaje para success y error ([5f18f6b](https://github.com/j-dominguezp/servercraft-web/commit/5f18f6ba3dc313bdd1f23a7b0bd923f416b337cc))
* **usuarios:** editar y eliminar añadidos, falta refactorizar para estandarizar este proceso ([f18201d](https://github.com/j-dominguezp/servercraft-web/commit/f18201dc42b9bab94d95c8f630dcee975c6aeb57))
* **usuarios:** listar usuarios implementado, se agrega esqueleto para tablas ([6d7b7a9](https://github.com/j-dominguezp/servercraft-web/commit/6d7b7a9fe0f4754859e14c8ee2f0a0332f4ace1a))


### Bug Fixes

* **clientes o proveedores:** se mueven paginas de clientes a rutas donede hagan mas sentido ([93b3919](https://github.com/j-dominguezp/servercraft-web/commit/93b39198284320f5fd62efe00c95140e047f6b9f))
* **clientes:** se reempalaza clientes por Equipos de proveedores ([0a9049f](https://github.com/j-dominguezp/servercraft-web/commit/0a9049f2f337830ab6b1581a80b32d0bf14013b4))
* **controlled inputs:** ahora muestran bien los mensajes de errores ([b7182b0](https://github.com/j-dominguezp/servercraft-web/commit/b7182b094599673b011a0d94d970f7ac3bcc2516))
* **detalleequipoproveedor:** arreglo de botonUD y separacion entre componentes hermanos ([2447700](https://github.com/j-dominguezp/servercraft-web/commit/24477009ba27d418d2186e9c91205248fd03997e))
* **detalleusuario:** arreglo de botonUD y separación entre componentes hermanos ([8078767](https://github.com/j-dominguezp/servercraft-web/commit/80787670edaa48c7e5a8997d15cf4ea05d9f38fb))
* **detalleusuario:** cambios en indentación ([3a89bcd](https://github.com/j-dominguezp/servercraft-web/commit/3a89bcd2912541bc08c0682bbebb875c77514f2d))
* **detalleusuario:** se hizo un cambio en la imagen de usuario ([1d65dff](https://github.com/j-dominguezp/servercraft-web/commit/1d65dfffdfcc9a76ff2d4222115be3b38ddf5eeb))
* **documentos servicio:** se mejora informacion mostrada en en listadod ([b7a5fbb](https://github.com/j-dominguezp/servercraft-web/commit/b7a5fbb4bb40ec698526b2877efe9bfbdaf399cc))
* **equipo encargado:** se arreglan los conflictos de merge ([57fbf58](https://github.com/j-dominguezp/servercraft-web/commit/57fbf58072a79415af25d5dea279fdb28c8b5e72))
* **equipos proveedor:** se mejora informacion mostrada en listado de equipos ([b7a7fbc](https://github.com/j-dominguezp/servercraft-web/commit/b7a7fbc699de7308ce8a61956fd0981297b0558b))
* **equipos trabajo:** se corrige informacion mostrada en listado, además se edita tamaño de columnas ([ea8f811](https://github.com/j-dominguezp/servercraft-web/commit/ea8f811aecc8a51a70681432e51f782f2645e111))
* **formulario login:** import no usado ([ed72a11](https://github.com/j-dominguezp/servercraft-web/commit/ed72a11de19f01eb23b3ae94f40f87be710d6e97))
* **formulario login:** se quita el prefetch ya que al construir la instancia del router no está ([f164135](https://github.com/j-dominguezp/servercraft-web/commit/f164135b1905bb06327afb845a8dd80b10d9443d))
* **formulario perfil:** flag para que solo se hagan el set field 1 vez ([07362a4](https://github.com/j-dominguezp/servercraft-web/commit/07362a4b2447583a191a58b38c5f19867039f3ee))
* **formulario servidor:** default checked corregido en editar servidor ([c9dc577](https://github.com/j-dominguezp/servercraft-web/commit/c9dc57740718eb369171d8b51db71ec7dedf9741))
* **formulario servidor:** se condiciona la desabilitacion de los campos segun el tipo del formulario ([e7f5586](https://github.com/j-dominguezp/servercraft-web/commit/e7f55867664469ac5c89a19a946dd6c0a77541c6))
* **formulario sistema:** filtro actualizado por cambio en la api ([bd93da0](https://github.com/j-dominguezp/servercraft-web/commit/bd93da06240050a39085643136dd055c6067087d))
* **home template:** al usar layout no se requiere usar width y height ([5692549](https://github.com/j-dominguezp/servercraft-web/commit/5692549c11c108642c60318d686f91f1b0df87ea))
* **home:** se arreglo la importacion de modulos que no existen y los que no estan siendo utilizados ([14a832c](https://github.com/j-dominguezp/servercraft-web/commit/14a832c9d86c9c52a66eca6ef40afe5f633d3377))
* **http:** documentoSistema,nivel seguridad y sensibilidad, servicioWeb y lenguaje prog arreglados ([13308c9](https://github.com/j-dominguezp/servercraft-web/commit/13308c9a3e46d2589e8bdd9bec75093342fa0a0b))
* **iconos:** eliminación temporal de los iconos para arreglar el nombre en el repositorio ([445169c](https://github.com/j-dominguezp/servercraft-web/commit/445169cd043bf36c8b1dd60dbaa189ec6e86cb6e))
* **iconos:** se agregan los iconos con las mayusculas correpondientes ([4c27759](https://github.com/j-dominguezp/servercraft-web/commit/4c2775959e44fceb1190c89524629e435f488ad7))
* **incidentes:** cambio de nombre en rutas de tipo de solucion y problemas ([b67b072](https://github.com/j-dominguezp/servercraft-web/commit/b67b0724914505b67746d3263e82e9d4523bbadf))
* **incidentes:** se añade booleano para habilitar opcion de ver detalle ([70215b9](https://github.com/j-dominguezp/servercraft-web/commit/70215b98f6d056c0258fdc4bc1ba5d8b9a199010))
* **incidentes:** se corrige breadcrumb en listado de problemas y soluciones ([dcd3a18](https://github.com/j-dominguezp/servercraft-web/commit/dcd3a18701e28aeda336f43153304809e244364d))
* **incidentes:** se mejora informacion mostrada en listado de incidentes ([a2cc93d](https://github.com/j-dominguezp/servercraft-web/commit/a2cc93d08011ca0d0742dec642dcb6f48e6a4c2c))
* **index:** cambio de navbar ([c7b7ada](https://github.com/j-dominguezp/servercraft-web/commit/c7b7ada0bb834be77175dccf378aabe2ba372adc))
* **index:** correcion de navbar ([5c156aa](https://github.com/j-dominguezp/servercraft-web/commit/5c156aa4041a8f507add397ad87bb77a97b16a8f))
* **index:** correcion en importacion de navbar ([2474381](https://github.com/j-dominguezp/servercraft-web/commit/2474381ec9abde102b1076ed8590c1550a221938))
* **lenguajes:** correcion de textos ([7fe4e31](https://github.com/j-dominguezp/servercraft-web/commit/7fe4e31c8e87e53f5d2fbeb0e02b8ab9ec7f1abf))
* **lenguajes:** se corrige informacion mostrada en el listado y tamaño de columnas ([78dc4d7](https://github.com/j-dominguezp/servercraft-web/commit/78dc4d74f6869d07e215a5becc0e0f33dab07f69))
* **listado clientes:** se corrige el nombre del hook useEquipoEncargado ([d32ac8a](https://github.com/j-dominguezp/servercraft-web/commit/d32ac8aa50f494190b93c26d2c05ac21e4240ada))
* **listado lenguajes:** se corrigen los nombres de las variables ([30b5dc9](https://github.com/j-dominguezp/servercraft-web/commit/30b5dc928c727272599509478e35b0ac63a830df))
* **listar usuarios:** se quita el select none ([e39055b](https://github.com/j-dominguezp/servercraft-web/commit/e39055b652561f307c3f0884a346e0a72e3d7b2e))
* **login:** fluent se debe usar con controlled inputs, se creará un comp que use "useController" ([5fd2ac0](https://github.com/j-dominguezp/servercraft-web/commit/5fd2ac0f0957fbec8320362e195300110523c132))
* **menu principal:** arreglos visuales ([46063fb](https://github.com/j-dominguezp/servercraft-web/commit/46063fb65ab2d8584b9eac56bedff092e6e14742))
* **menu principal:** menu principal se arregla un tema visual, en el template se arregla el fondo ([f927a3e](https://github.com/j-dominguezp/servercraft-web/commit/f927a3e2a6b89bab13ecaeaae6a7975a7933de7c))
* **menu principal:** se corrige ruta de acceso a paginas de proveedores ([f59fee7](https://github.com/j-dominguezp/servercraft-web/commit/f59fee7678ed4debd7776b58b4b0b04596f9b853))
* **menu principal:** se corrige ruta de acceso a ubicaciones ([027cd25](https://github.com/j-dominguezp/servercraft-web/commit/027cd252560aa549835c753fc98aa9016380cf67))
* **menuprincipal:** cambio de textos ([3548ad0](https://github.com/j-dominguezp/servercraft-web/commit/3548ad0f55e8520397d485d3eebc4703bbcffba5))
* **menusistema:** cambio en nombre de referencia sugeridas por jp ([6fb3b17](https://github.com/j-dominguezp/servercraft-web/commit/6fb3b17ba988d6ef2fa9da28db5241ad5b45b840))
* **menusistema:** se agrega efecto visual a los bonotes ([f40483b](https://github.com/j-dominguezp/servercraft-web/commit/f40483b5a8f1b2db345cd16909fa7cdd41b38b4a))
* **menusistemas:** se agregar link de referencias a los botones del menu ([f241a07](https://github.com/j-dominguezp/servercraft-web/commit/f241a074ad6e7dd80ebf048579d98a0b90e5c46d))
* **motores bd:** se corrige informacion mostrada en listado y tamaño columnas ([eaa8d96](https://github.com/j-dominguezp/servercraft-web/commit/eaa8d960dde9a52274d054abc1676e3cb34da912))
* **perfil:** se añaden correcciones para el correcto funcionamiento de actualizacion de contraseña ([547e974](https://github.com/j-dominguezp/servercraft-web/commit/547e974e8053fe3dc5c875f2d818a7a49bbf6aef))
* **perfil:** se añaden keys faltantes ([a02c91b](https://github.com/j-dominguezp/servercraft-web/commit/a02c91b455d13f0be1b15617d7d0e1a8bc940fb7))
* **perfil:** se limpia el campo imagen para que al siguiente req no se mande ([b1172cf](https://github.com/j-dominguezp/servercraft-web/commit/b1172cf5c3fbf3d3687ceefb50e3f97066a5c572))
* **proveedores:** se corrige informacion mostrada en listado de proveedores ([8425104](https://github.com/j-dominguezp/servercraft-web/commit/84251047a44de53e255067e4d24b5f030376f403))
* **proyecto:** fixes generales, de indentacion y visuales ([1e77fe7](https://github.com/j-dominguezp/servercraft-web/commit/1e77fe7a66bc19499eb92c068c65ec61316e1edb))
* **racks:** se corrige informacion mostrada en el listado de racks ([9ebd698](https://github.com/j-dominguezp/servercraft-web/commit/9ebd698a87eedeb2d0faa321ae5d69a58b5cfb9c))
* **salas:** se corrige informacion mostrada en el listado de salas de servidores ([5461614](https://github.com/j-dominguezp/servercraft-web/commit/54616149f61d19766a8e9011ab0795f178654b59))
* **servicios web:** se corrige informacion mostrada en listado y tamaño columnas ([8ba2246](https://github.com/j-dominguezp/servercraft-web/commit/8ba2246f84d938159abd2af93f3482af3bfe7f0c))
* **servidores:** se corrige información mostrada en el listado de servidores ([90212ab](https://github.com/j-dominguezp/servercraft-web/commit/90212ab2c0e7afc3e8c926daaab139a3535f0d8b))
* **sistema:** eliminación de importaciones que no se utilizan en el detalle del sistema ([c41b34d](https://github.com/j-dominguezp/servercraft-web/commit/c41b34df3fff7eec0e232029d32f19cd329addcf))
* **sistema:** reorganización de la información general del sistema en 3 columnas ([4017474](https://github.com/j-dominguezp/servercraft-web/commit/4017474c4374df8c389af8c08775cbcb45680230))
* **sistemas:** se corrige informacion mostrada en el listado de sistemas ([590f7b0](https://github.com/j-dominguezp/servercraft-web/commit/590f7b04909fd6b3851524a9a33dee14f62af6d1))
* **sistema:** subtitulos de las instancias se valido para que no aparecieran al no existir instancia ([b00edc2](https://github.com/j-dominguezp/servercraft-web/commit/b00edc24a30944aa7ce3b2fe91e7636dd10540af))
* **tailwind:** se quita purge ya que afecta las clases de fluent ui ([fa887fa](https://github.com/j-dominguezp/servercraft-web/commit/fa887faecd45f260b105e2caff567c12d0588fb5))
* **ubicaciones:** se añade nuevo sidebar para ubicaciones ([6780233](https://github.com/j-dominguezp/servercraft-web/commit/6780233971db61b2541238280abea491872ac8c0))
* **ubicaciones:** se mueven ruta dinamica de paises y ruta regiones a un solo origen "/ubicaciones" ([7b10ca2](https://github.com/j-dominguezp/servercraft-web/commit/7b10ca25875c19b7a0f40ff38ffe26456e5c3c41))
* **unidades negocio:** se corrige informacion mostrada en el listado y tamaño de columna ([409a07f](https://github.com/j-dominguezp/servercraft-web/commit/409a07f85d13f2f2584b8a7a2142b69a9cbdfb3e))
* **usuarios:** navbar correcto, template nuevo usado, estilos arreglados ([24b3cb8](https://github.com/j-dominguezp/servercraft-web/commit/24b3cb86d5cf05901cf59110d68a275f2f3a229f))
* **usuarios:** se corrige informacion mostrada en el listado de usuarios ([cee636f](https://github.com/j-dominguezp/servercraft-web/commit/cee636fa5c8be57c88bf17b5a92c9eb1fff65b31))
* **variables entorno:** actualice la variable API en el ejemplo ([1a75e55](https://github.com/j-dominguezp/servercraft-web/commit/1a75e55303556b0df47497ffa211c1de2a9dff9e))


### Performance Improvements

* **cargando tablas:** se agrega useMemo para optimizar ([89b39e0](https://github.com/j-dominguezp/servercraft-web/commit/89b39e0633e4d6cdd44c749f227c6fb427de75c0))
* **sidebar y listados:** cambios de pocision de sidebar y cambio el de nombre en listados ([877845e](https://github.com/j-dominguezp/servercraft-web/commit/877845e61255a7178b51a56311e17d3f3bcf88c9))


### Styling

* **package.json:** se indento con espacios de 4 ([b8d6b20](https://github.com/j-dominguezp/servercraft-web/commit/b8d6b2090f3d11fe73f152a224b41922a4d9f11f))


### Others

* **configuracion:** correccion de configuraciones iniciales ([c162da3](https://github.com/j-dominguezp/servercraft-web/commit/c162da32a93f81f19996fc2ad496c1ef00e4052a))
* **dependencias:** se actualizan paquetes para utilizar nuevas caracteristicas ([59b1cb4](https://github.com/j-dominguezp/servercraft-web/commit/59b1cb4922ca7eac8937b2df35603593b3b6a2ad))


### Code Refactoring

* **api y consultas:** renombrar la carpeta de api a http ([286f432](https://github.com/j-dominguezp/servercraft-web/commit/286f432f8744dfcad700bbfd452145ec6b88b399))
* **api:** se cambia nombre de carpeta 'api' a 'http' por conflictos con next, fix para [#21](https://github.com/j-dominguezp/servercraft-web/issues/21) ([a50a50f](https://github.com/j-dominguezp/servercraft-web/commit/a50a50fe29549c4014289ec9ce061ce6d278f375))
* **equipo encargado calls:** elimine el undified de la funcion eliminar ([7e3f6fc](https://github.com/j-dominguezp/servercraft-web/commit/7e3f6fc86a5477532e273c13c5344d2134a2ea15))
* **formulario documentoservicio:** se correige el mostrar datos en el formulario de documento ([2cf2f3d](https://github.com/j-dominguezp/servercraft-web/commit/2cf2f3d87bb4bf6e5d6ab8665dd4b0e758b36860))
* **formulario y listado servicio:** se arreglan llamdas y nombres de funciones ([390fcf1](https://github.com/j-dominguezp/servercraft-web/commit/390fcf1058c79582e0b643a095a0d716eb192e78))
* **formulario:** cambio del nombre editar documento ([61680b5](https://github.com/j-dominguezp/servercraft-web/commit/61680b549d02763b18eff46fccc1ee5c3fc8dfde))
* **menu principal:** se estandarizo el template para ser reutilizado en otras partes ([5d67ba3](https://github.com/j-dominguezp/servercraft-web/commit/5d67ba3a56af0a924d3ded8db9132adbb3d14c5c))
* **usuarios:** console.log eliminados ([5cbadb6](https://github.com/j-dominguezp/servercraft-web/commit/5cbadb630b69abb5397bd5daa4014f9a53004bfb))
