// Dependencies
import Head from 'next/head';
import FormularioNuevaContrasena from '../../molecules/FormularioNuevaContrasena';
import NavbarPublico from '../../organisms/NavbarPublico';
import LoginTemplate from '../../templates/LoginTemplate';

// Pagina
const CrearNuevaContrasena = () => {
    return (
        <>
            <div>
                <Head>
                    <title>Crear Nueva Contraseña - Servercraft</title>

                    <link rel="icon" href="/favicon.ico" />
                </Head>

                <LoginTemplate
                    bg={{ src: '/bg-login.png', alt: 'Fondo acrilico' }}
                    navbar={<NavbarPublico />}
                    formulario={<FormularioNuevaContrasena />}
                />
            </div>
        </>
    );
};

// Export
export default CrearNuevaContrasena;
