// Dependencias
import Head from 'next/head';
import LoginTemplate from '../../templates/LoginTemplate';
import NavbarPublico from '../../organisms/NavbarPublico';
import FormularioRecuperar from '../../molecules/FormularioRecuperar';

// Pagina
const RecuperarContrasena = () => {
    return (
        <>
            <Head>
                <title>Recuperar contraseña - Servercraft</title>
            </Head>

            <LoginTemplate
                bg={{ src: '/bg-login.png', alt: 'Fondo acrilico' }}
                navbar={<NavbarPublico />}
                formulario={<FormularioRecuperar />}
            />
        </>
    );
};

// Export
export default RecuperarContrasena;
