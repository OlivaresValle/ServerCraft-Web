import { NextResponse } from 'next/server';

export function middleware(req) {
    const isLoginPage = ['/', '/recuperar', '/recuperar/nueva-contrasena'].includes(req.nextUrl.pathname);
    const imageTypes = ['.ico', '.png', '.jpg', '.jpeg', '.svg'];
    const isAsset = imageTypes.some((t) => req.nextUrl.href.includes(t));
    const hasToken = req.cookies['auth-token'];

    if (!isAsset && !!isLoginPage === !!hasToken) {
        return NextResponse.redirect(isLoginPage ? '/menu' : '/', 302);
    }

    return NextResponse.next();
}
