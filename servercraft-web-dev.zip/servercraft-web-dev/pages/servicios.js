// Dependencias
import Head from 'next/head';
import ListadoServicioWeb from '../molecules/ListadoServicioWeb';
import SideBarServicioWeb from '../organisms/SideBarServicioWeb';
import NavbarUsuario from '../organisms/NavbarUsuario';
import SideBarTemplate from '../templates/SideBarTemplate';
import nookies from 'nookies';
import { useEffect } from 'react';
import { useUsuario } from '../http/lib/usuario';
import { useRouter } from 'next/router';

// Componente
const ServicioWeb = () => {
    // Estados
    const router = useRouter();
    const token = nookies.get()['auth-token'];
    const { data } = useUsuario(0, token);

    // Effect
    useEffect(() => {
        if (data && data?.data?.usuario?.rol?.id === 4) {
            router.push('/menu');
        }
    }, [data, router]);

    return (
        <>
            <Head>
                <title>Servicios Web - Servercraft</title>
            </Head>

            {data?.data?.usuario?.rol?.id !== 4 && (
                <SideBarTemplate
                    bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                    navbar={<NavbarUsuario />}
                    sidebar={<SideBarServicioWeb selectedKey="servicios" />}
                    cuerpo={<ListadoServicioWeb />}
                />
            )}
        </>
    );
};

// Exportación
export default ServicioWeb;
