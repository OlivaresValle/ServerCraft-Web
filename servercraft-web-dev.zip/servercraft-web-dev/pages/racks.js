// Dependencias
import Head from 'next/head';
import ListadoRacks from '../molecules/ListadoRacks';
import SideBarRacks from '../organisms/SideBarServidores';
import NavbarUsuario from '../organisms/NavbarUsuario';
import SideBarTemplate from '../templates/SideBarTemplate';
import nookies from 'nookies';
import { useEffect } from 'react';
import { useUsuario } from '../http/lib/usuario';
import { useRouter } from 'next/router';

// Componente
const Racks = () => {
    // Estados
    const router = useRouter();
    const token = nookies.get()['auth-token'];
    const { data } = useUsuario(0, token);

    // Effect
    useEffect(() => {
        if (data && [3, 4].includes(data?.data?.usuario?.rol?.id)) {
            router.push('/menu');
        }
    }, [data, router]);

    return (
        <>
            <Head>
                <title>Racks - Servercraft</title>
            </Head>

            {![3, 4].includes(data?.data?.usuario?.rol?.id) && (
                <SideBarTemplate
                    bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                    navbar={<NavbarUsuario />}
                    sidebar={<SideBarRacks selectedKey="racks" />}
                    cuerpo={<ListadoRacks />}
                />
            )}
        </>
    );
};

// Exportación
export default Racks;
