// Dependencias
import Head from 'next/head';
import ListadoTipoSoluciones from '../molecules/ListadoTipoSoluciones';
import SideBarTipoSoluciones from '../organisms/SideBarIncidentes';
import NavbarUsuario from '../organisms/NavbarUsuario';
import SideBarTemplate from '../templates/SideBarTemplate';

// Componente
const TipoSoluciones = () => {
    // Estados
    return (
        <>
            <Head>
                <title>Tipo Solución Incidentes - Servercraft</title>
            </Head>

            <SideBarTemplate
                bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                navbar={<NavbarUsuario />}
                sidebar={<SideBarTipoSoluciones selectedKey="tipo-solucion" />}
                cuerpo={<ListadoTipoSoluciones />}
            />
        </>
    );
};

// Exportación
export default TipoSoluciones;
