// Dependencias
import Head from 'next/head';
import Error404 from '../molecules/Error404';
import NavbarPublico from '../organisms/NavbarPublico';
import LoginTemplate from '../templates/LoginTemplate';

// Componente

const Custom404 = () => {
    return (
        <div>
            <Head>
                <title>Página no encontrada</title>
                <meta name="description" content="No se encontró la página" />
                <link rel="icon" href="/favicon.ico" />
            </Head>

            <LoginTemplate
                bg={{ src: '/bg-login.png', alt: 'Fondo acrilico' }}
                navbar={<NavbarPublico />}
                formulario={<Error404 />}
            />
        </div>
    );
};

// Exportación
export default Custom404;
