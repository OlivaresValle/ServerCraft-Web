// Dependencias
import Head from 'next/head';
import MenuPrincipal from '../molecules/MenuPrincipal';
import MenuPrincipalConsultor from '../molecules/MenuPrincipalConsultor';
import MenuPrincipalResponsable from '../molecules/MenuPrincipalResponsable';
import NavbarUsuario from '../organisms/NavbarUsuario';
import NavbarTemplate from '../templates/NavbarTemplate';
import { useUsuario } from '../http/lib/usuario';
import nookies from 'nookies';
import MenuPrincipalInformante from '../molecules/MenuPrincipalInformante';

const MenuPage = () => {
    // States
    const token = nookies.get()['auth-token'];
    const { data } = useUsuario(0, token);

    return (
        <div>
            <Head>
                <title>Menu principal - ServerCraft</title>
                <meta name="description" content="Menu principal" />
                <link rel="icon" href="/favicon.ico" />
            </Head>

            <NavbarTemplate
                bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                navbar={<NavbarUsuario />}
                contenido={
                    data?.data?.usuario.rol.id === 1 ? (
                        <MenuPrincipal />
                    ) : data?.data?.usuario.rol.id === 2 ? (
                        <MenuPrincipalResponsable />
                    ) : data?.data?.usuario.rol.id === 3 ? (
                        <MenuPrincipalConsultor />
                    ) : data?.data?.usuario.rol.id === 4 ? (
                        <MenuPrincipalInformante />
                    ) : (
                        <></>
                    )
                }
            />
        </div>
    );
};

export default MenuPage;
