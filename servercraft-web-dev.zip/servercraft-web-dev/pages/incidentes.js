// Dependencias
import ListadoIncidentes from '../molecules/ListadoIncidentes';
import SideBarIncidentes from '../organisms/SideBarIncidentes';
import NavbarUsuario from '../organisms/NavbarUsuario';
import SideBarTemplate from '../templates/SideBarTemplate';
import Head from 'next/head';

// Componente
const Incidentes = () => {
    // Estados
    return (
        <>
            <Head>
                <title>Incidentes - Servercraft</title>
            </Head>

            <SideBarTemplate
                bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                navbar={<NavbarUsuario />}
                sidebar={<SideBarIncidentes selectedKey="incidentes" />}
                cuerpo={<ListadoIncidentes />}
            />
        </>
    );
};

// Exportación
export default Incidentes;
