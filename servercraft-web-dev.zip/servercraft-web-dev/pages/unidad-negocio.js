// Dependencias
import Head from 'next/head';
import ListadoUnidad from '../molecules/ListadoUnidadNegocios';
import SideBarUnidad from '../organisms/SideBarMiembros';
import NavbarUsuario from '../organisms/NavbarUsuario';
import SideBarTemplate from '../templates/SideBarTemplate';
import nookies from 'nookies';
import { useEffect } from 'react';
import { useUsuario } from '../http/lib/usuario';
import { useRouter } from 'next/router';

// Componente
const UnidadNegocio = () => {
    // Estados
    const router = useRouter();
    const token = nookies.get()['auth-token'];
    const { data } = useUsuario(0, token);

    // Effect
    useEffect(() => {
        if (data && data?.data?.usuario?.rol?.id === 4) {
            router.push('/menu');
        }
    }, [data, router]);

    return (
        <div>
            <Head>
                <title>Unidad Negocio - Servercraft</title>
                <meta name="description" content="Ubicaciones" />
                <link rel="icon" href="/favicon.ico" />
            </Head>

            {data?.data?.usuario?.rol?.id !== 4 && (
                <SideBarTemplate
                    bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                    navbar={<NavbarUsuario />}
                    sidebar={<SideBarUnidad selectedKey="unidad-negocio" />}
                    cuerpo={<ListadoUnidad />}
                />
            )}
        </div>
    );
};

// Exportación
export default UnidadNegocio;
