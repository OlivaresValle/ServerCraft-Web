import Head from 'next/head';
import ListadoMotoresBD from '../molecules/ListadoMotoresBD';
import NavbarUsuario from '../organisms/NavbarUsuario';
import NavbarTemplate from '../templates/NavbarTemplate';
import nookies from 'nookies';
import { useEffect } from 'react';
import { useUsuario } from '../http/lib/usuario';
import { useRouter } from 'next/router';

const MotoresBD = () => {
    /// Estados
    const router = useRouter();
    const token = nookies.get()['auth-token'];
    const { data } = useUsuario(0, token);

    // Effect
    useEffect(() => {
        if (data && [3, 4].includes(data?.data?.usuario?.rol?.id)) {
            router.push('/menu');
        }
    }, [data, router]);

    return (
        <div>
            <Head>
                <title>Bases de datos - ServerCraft</title>
                <meta
                    name="description"
                    content="Listados de Motores de base de datos"
                />
                <link rel="icon" href="/favicon.ico" />
            </Head>

            {![3, 4].includes(data?.data?.usuario?.rol?.id) && (
                <NavbarTemplate
                    bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                    navbar={<NavbarUsuario />}
                    contenido={<ListadoMotoresBD />}
                />
            )}
        </div>
    );
};

export default MotoresBD;
