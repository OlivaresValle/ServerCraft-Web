import Head from 'next/head';
import ListadoLenguajes from '../molecules/ListadoLenguajes';
import NavbarUsuario from '../organisms/NavbarUsuario';
import NavbarTemplate from '../templates/NavbarTemplate';
import nookies from 'nookies';
import { useEffect } from 'react';
import { useUsuario } from '../http/lib/usuario';
import { useRouter } from 'next/router';

const Lenguajes = () => {
    /// Estados
    const router = useRouter();
    const token = nookies.get()['auth-token'];
    const { data } = useUsuario(0, token);

    // Effect
    useEffect(() => {
        if (data && data?.data?.usuario?.rol?.id === 4) {
            router.push('/menu');
        }
    }, [data, router]);

    return (
        <div>
            <Head>
                <title>Lenguajes - ServerCraft</title>
                <meta name="description" content="Listados de lenguajes" />
                <link rel="icon" href="/favicon.ico" />
            </Head>

            {data?.data?.usuario?.rol?.id !== 4 && (
                <NavbarTemplate
                    bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                    navbar={<NavbarUsuario />}
                    contenido={<ListadoLenguajes />}
                />
            )}
        </div>
    );
};

export default Lenguajes;
