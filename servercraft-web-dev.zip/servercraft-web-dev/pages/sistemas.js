import Head from 'next/head';
import ListadoSistemas from '../molecules/ListadoSistemas';
import NavbarUsuario from '../organisms/NavbarUsuario';
import NavbarTemplate from '../templates/NavbarTemplate';

const SistemasPage = () => {
    // States
    return (
        <div>
            <Head>
                <title>Sistemas - ServerCraft</title>
                <meta name="description" content="Listados de sistemas" />
                <link rel="icon" href="/favicon.ico" />
            </Head>

            <NavbarTemplate
                bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                navbar={<NavbarUsuario />}
                contenido={<ListadoSistemas />}
            />
        </div>
    );
};

export default SistemasPage;
