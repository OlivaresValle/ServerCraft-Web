// Dependencias
import Head from 'next/head';
import { useEffect } from 'react';
import NavbarTemplate from '../templates/NavbarTemplate';
import NavbarUsuario from '../organisms/NavbarUsuario';
import ContenidoEstadisticas from '../organisms/ContenidoEstadisticas';
import nookies from 'nookies';
import { useUsuario } from '../http/lib/usuario';
import { useRouter } from 'next/router';

// Pagina
const Estadisticas = () => {
    // Estados
    const router = useRouter();
    const token = nookies.get()['auth-token'];
    const { data } = useUsuario(0, token);

    // Effect
    useEffect(() => {
        if (data && data?.data?.usuario?.rol?.id !== 1) {
            router.push('/menu');
        }
    }, [data, router]);

    return (
        <>
            <Head>
                <title>Estadísticas - Servercraft</title>
            </Head>

            {data?.data?.usuario?.rol?.id === 1 ? (
                <NavbarTemplate
                    bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                    navbar={<NavbarUsuario />}
                    contenido={<ContenidoEstadisticas />}
                />
            ) : (
                <></>
            )}
        </>
    );
};

// Export
export default Estadisticas;
