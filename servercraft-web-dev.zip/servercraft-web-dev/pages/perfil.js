// Dependencias
import Head from 'next/head';
import NavbarUsuario from '../organisms/NavbarUsuario';
import PerfilUsuario from '../organisms/PerfilUsuario';
import NavbarTemplate from '../templates/NavbarTemplate';

const MenuPage = () => {
    // States
    return (
        <div>
            <Head>
                <title>Perfil - ServerCraft</title>
                <meta name="description" content="Perfil del usuario" />
                <link rel="icon" href="/favicon.ico" />
            </Head>

            <NavbarTemplate
                bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                navbar={<NavbarUsuario />}
                contenido={<PerfilUsuario />}
            />
        </div>
    );
};

export default MenuPage;
