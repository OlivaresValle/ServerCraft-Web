// Dependencias
import '../styles/globals.css';
import { initializeIcons, ThemeProvider } from '@fluentui/react';
import { Toaster } from 'react-hot-toast';

initializeIcons(undefined, { disableWarnings: true });

function MyApp({ Component, pageProps }) {
    // Estados
    return (
        <ThemeProvider>
            <Component {...pageProps} />

            <Toaster />
        </ThemeProvider>
    );
}

export default MyApp;
