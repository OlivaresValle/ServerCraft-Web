// Dependencias
import Head from 'next/head';
import ListadoPaises from '../../molecules/ListadoPaises';
import SideBarUbicaciones from '../../organisms/SideBarUbicaciones';
import NavbarUsuario from '../../organisms/NavbarUsuario';
import SideBarTemplate from '../../templates/SideBarTemplate';
import nookies from 'nookies';
import { useEffect } from 'react';
import { useUsuario } from '../../http/lib/usuario';
import { useRouter } from 'next/router';

// Componente
const Paises = () => {
    // Estados
    const router = useRouter();
    const token = nookies.get()['auth-token'];
    const { data } = useUsuario(0, token);

    // Effect
    useEffect(() => {
        if (data && data?.data?.usuario?.rol?.id !== 1) {
            router.push('/menu');
        }
    }, [data, router]);

    return (
        <div>
            <Head>
                <title>Ubicaciones - Servercraft</title>
                <meta name="description" content="Ubicaciones" />
                <link rel="icon" href="/favicon.ico" />
            </Head>

            {data?.data?.usuario?.rol?.id === 1 && (
                <SideBarTemplate
                    bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                    sidebar={<SideBarUbicaciones selectedKey="paises" />}
                    navbar={<NavbarUsuario />}
                    cuerpo={<ListadoPaises />}
                />
            )}
        </div>
    );
};

// Exportación
export default Paises;
