// Dependencias
import Head from 'next/head';
import ListadoRegiones from '../../molecules/ListadoRegiones';
import SideBarUbicaciones from '../../organisms/SideBarUbicaciones';
import NavbarUsuario from '../../organisms/NavbarUsuario';
import SideBarTemplate from '../../templates/SideBarTemplate';
import nookies from 'nookies';
import { useEffect } from 'react';
import { useUsuario } from '../../http/lib/usuario';
import { useRouter } from 'next/router';

// Componente
const Regiones = () => {
    // Estados
    const router = useRouter();
    const token = nookies.get()['auth-token'];
    const { data } = useUsuario(0, token);

    // Effect
    useEffect(() => {
        if (data && data?.data?.usuario?.rol?.id !== 1) {
            router.push('/menu');
        }
    }, [data, router]);

    return (
        <div>
            <Head>
                <title>Regiones - Servercraft</title>
                <meta name="description" content="Regiones" />
                <link rel="icon" href="/favicon.ico" />
            </Head>

            {data?.data?.usuario?.rol?.id === 1 && (
                <SideBarTemplate
                    bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                    navbar={<NavbarUsuario />}
                    sidebar={<SideBarUbicaciones selectedKey="regiones" />}
                    cuerpo={<ListadoRegiones />}
                />
            )}
        </div>
    );
};

// Exportación
export default Regiones;
