// Dependencias
import Head from 'next/head';
import ListadoEquipoTrabajo from '../molecules/ListadoEquiposTrabajos';
import SideBarEquipoTrabajo from '../organisms/SideBarMiembros';
import NavbarUsuario from '../organisms/NavbarUsuario';
import SideBarTemplate from '../templates/SideBarTemplate';
import nookies from 'nookies';
import { useEffect } from 'react';
import { useUsuario } from '../http/lib/usuario';
import { useRouter } from 'next/router';

// Componente
const EquipoTrabajo = () => {
    // Estados
    const router = useRouter();
    const token = nookies.get()['auth-token'];
    const { data } = useUsuario(0, token);

    // Effect
    useEffect(() => {
        if (data && data?.data?.usuario?.rol?.id === 4) {
            router.push('/menu');
        }
    }, [data, router]);

    return (
        <>
            <Head>
                <title>Equipo de Trabajo - Servercraft</title>
            </Head>

            {data?.data?.usuario?.rol?.id !== 4 ? (
                <SideBarTemplate
                    bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                    navbar={<NavbarUsuario />}
                    sidebar={
                        <SideBarEquipoTrabajo selectedKey="equipo-trabajo" />
                    }
                    cuerpo={<ListadoEquipoTrabajo />}
                />
            ) : (
                <></>
            )}
        </>
    );
};

// Exportación
export default EquipoTrabajo;
