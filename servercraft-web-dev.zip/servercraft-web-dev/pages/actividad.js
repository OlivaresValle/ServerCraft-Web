// Dependencias
import Head from 'next/head';
import ListadoActividad from '../molecules/ListadoActividad';
import NavbarUsuario from '../organisms/NavbarUsuario';
import NavbarTemplate from '../templates/NavbarTemplate';
import nookies from 'nookies';
import { useEffect } from 'react';
import { useUsuario } from '../http/lib/usuario';
import { useRouter } from 'next/router';

// Componente
const RegistroActividad = () => {
    // Estados
    const router = useRouter();
    const token = nookies.get()['auth-token'];
    const { data } = useUsuario(0, token);

    // Effect
    useEffect(() => {
        if (data && data?.data?.usuario?.rol?.id !== 1) {
            router.push('/menu');
        }
    }, [data, router]);

    return (
        <>
            <Head>
                <title>Actividad Auditoria - Servercraft</title>
            </Head>

            {data?.data?.usuario?.rol?.id === 1 && (
                <NavbarTemplate
                    bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                    navbar={<NavbarUsuario />}
                    contenido={<ListadoActividad />}
                />
            )}
        </>
    );
};

// Exportar
export default RegistroActividad;
