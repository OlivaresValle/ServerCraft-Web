// Dependencias
import Head from 'next/head';
import ListadoTipoProblemas from '../molecules/ListadoTipoProblemas';
import SideBarTipoProblemas from '../organisms/SideBarIncidentes';
import NavbarUsuario from '../organisms/NavbarUsuario';
import SideBarTemplate from '../templates/SideBarTemplate';

// Componente
const TipoProblemas = () => {
    // Estados
    return (
        <>
            <Head>
                <title>Tipo Problemas - Servercraft</title>
            </Head>

            <SideBarTemplate
                bg={{ src: '/Background.png', alt: 'Fondo acrilico' }}
                navbar={<NavbarUsuario />}
                sidebar={<SideBarTipoProblemas selectedKey="tipo-problemas" />}
                cuerpo={<ListadoTipoProblemas />}
            />
        </>
    );
};

// Exportación
export default TipoProblemas;
