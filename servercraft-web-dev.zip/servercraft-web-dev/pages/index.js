import Head from 'next/head';
import FormularioLogin from '../molecules/FormularioLogin';
import NavbarPublico from '../organisms/NavbarPublico';
import LoginTemplate from '../templates/LoginTemplate';

const HomePage = () => {
    return (
        <div>
            <Head>
                <title>Iniciar sesión - Servercraft</title>

                <link rel="icon" href="/favicon.ico" />
            </Head>

            <LoginTemplate
                bg={{ src: '/bg-login.png', alt: 'Fondo acrilico' }}
                navbar={<NavbarPublico />}
                formulario={<FormularioLogin />}
            />
        </div>
    );
};

export default HomePage;
