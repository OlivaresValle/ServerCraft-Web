// Dependencias
import { ActionButton } from '@fluentui/react';

// Componente
const BotonUD = ({
    showDetail,
    showEdit,
    showDelete,
    onViewDetail,
    onEdit,
    onDelete,
    setSelected,
    itemToSelect,
}) => {
    // Estados
    const menuProps = {
        items: [
            ...(showDetail
                ? [
                      {
                          key: 'ver_detalle',
                          iconProps: { iconName: 'ClipboardList' },
                          text: 'Ver detalle',
                          onClick: () => {
                              setSelected(itemToSelect);
                              onViewDetail();
                          },
                      },
                  ]
                : []),

            ...(showEdit
                ? [
                      {
                          key: 'editar',
                          iconProps: { iconName: 'Edit' },
                          text: 'Editar',
                          onClick: () => {
                              setSelected(itemToSelect);
                              onEdit();
                          },
                      },
                  ]
                : []),
            ...(showDelete
                ? [
                      {
                          key: 'eliminar',
                          iconProps: { iconName: 'Delete' },
                          text: 'Eliminar',
                          onClick: () => {
                              setSelected(itemToSelect);
                              onDelete();
                          },
                      },
                  ]
                : []),
        ],
    };

    return <ActionButton text="Acciones" menuProps={menuProps} />;
};

// Exportación
export default BotonUD;
