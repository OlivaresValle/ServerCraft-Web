// Dependencias
import { Checkbox } from '@fluentui/react';
import { useController } from 'react-hook-form';

// Componente
const ControlledCheckbox = ({ control, name, ...props }) => {
    const {
        field: { value, onChange, ...inputProps },
        fieldState: { error },
    } = useController({
        name,
        control,
    });

    return (
        <Checkbox
            onChange={(_, checked) => onChange(checked)}
            errorMessage={error && error?.message}
            {...inputProps}
            {...props}
            checked={value}
            defaultChecked={value}
        />
    );
};

// Exportación
export default ControlledCheckbox;
