// Dependencias
import { VirtualizedComboBox } from '@fluentui/react';
import { useController } from 'react-hook-form';

// Componente
const ControlledSelect = ({ control, name, ...props }) => {
    const {
        field: { value, onChange, ...inputProps },
        fieldState: { error },
    } = useController({
        name,
        control,
    });

    return (
        <VirtualizedComboBox
            selectedKey={value}
            useComboBoxAsMenuWidth
            onChange={(_, item) => onChange(item.key)}
            errorMessage={error && error?.message}
            {...inputProps}
            {...props}
        />
    );
};

// Exportación
export default ControlledSelect;
