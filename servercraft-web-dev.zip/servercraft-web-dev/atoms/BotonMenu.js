// Dependencias
import Link from 'next/link';

// Componente
const BotonMenu = ({ icon, text, secondaryText, detallado, href }) => {
    // Estados

    return (
        <Link href={href ?? '/'} passHref>
            <button
                className={`w-full h-40 flex justify-center items-center bg-white bg-opacity-25 hover:bg-opacity-75 transition-all ease-in-out duration-500 hover:border-white border-4 border-transparent ${
                    detallado ? 'px-16' : 'flex-col max-w-40'
                }`}
            >
                <div
                    className={`w-24 h-24 p-3 flex justify-center items-center  ${
                        detallado ? 'mr-6' : undefined
                    }`}
                >
                    {icon}
                </div>

                <div className="flex flex-col">
                    <p
                        className={`font-semibold  mb-2 ${
                            detallado
                                ? 'text-lg text-left'
                                : 'text-sm text-center'
                        }`}
                    >
                        {text}
                    </p>

                    {secondaryText && (
                        <p className="font-normal text-left text-sm">
                            {secondaryText}
                        </p>
                    )}
                </div>
            </button>
        </Link>
    );
};

// Exportación
export default BotonMenu;
