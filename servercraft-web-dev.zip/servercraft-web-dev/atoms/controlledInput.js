// Dependencias
import { TextField } from '@fluentui/react';
import { useController } from 'react-hook-form';

// Componente
const ControlledInput = ({ control, name, ...props }) => {
    const {
        field: { ...inputProps },
        fieldState: { error },
    } = useController({
        name,
        control,
    });

    return (
        <TextField
            errorMessage={error && error?.message}
            {...inputProps}
            {...props}
        />
    );
};

// Exportación
export default ControlledInput;
