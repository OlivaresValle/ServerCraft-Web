// Dependencias
import Image from 'next/image';
import Link from 'next/link';
import { Stack } from '@fluentui/react';

// Componente
const Logo = ({ href }) => {
    return (
        <Stack horizontal>
            <Link href={href} passHref>
                <button>
                    <Image
                        src="/Logo-Servercraft.svg"
                        alt="Servercraft Logo"
                        width={228}
                        height={62}
                        className="cursor-pointer"
                    />
                </button>
            </Link>
        </Stack>
    );
};

// Exportación
export default Logo;
