// Dependencias
import { MessageBar, IconButton, MessageBarType } from '@fluentui/react';
import toast from 'react-hot-toast';

// Componente
const SuccessToast = ({ text, t }) => {
    return (
        <MessageBar
            className="max-w-md w-auto"
            messageBarType={MessageBarType.success}
        >
            {text}
            <IconButton
                className="w-4 h-4 ml-2 text-sm text-black hover:bg-transparent"
                styles={{
                    icon: {
                        fontSize: '10px',
                    },
                }}
                iconProps={{ iconName: 'ChromeClose' }}
                onClick={() => toast.dismiss(t.id)}
            />
        </MessageBar>
    );
};

// Exportación
export default SuccessToast;
