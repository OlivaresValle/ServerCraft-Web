module.exports = {
    reactStrictMode: true,
    images: {
        domains: ['servercraft.s3.us-east-2.amazonaws.com'],
    },
    experimental: {
        esmExternals: false,
    },
};
