// Dependencias
import { useMemo } from 'react';
import { Shimmer } from '@fluentui/react';
import { range } from './array';

// Componente
export const CargandoTabla = (columnas, nrDeFilas) => {
    const renderCargandoTabla = useMemo(() => {
        return [
            ...range(nrDeFilas).map((_, i) => {
                let columnasObject = { key: i };

                columnas.forEach((columna) => {
                    columnasObject[columna.key] = <Shimmer width="100%" />;
                });

                return columnasObject;
            }),
        ];
    }, [columnas, nrDeFilas]);

    return renderCargandoTabla;
};
