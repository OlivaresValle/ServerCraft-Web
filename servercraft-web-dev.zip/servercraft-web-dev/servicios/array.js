// Función para crear un array
export const range = (size, startAt = 0) => {
    return [...Array(size).keys()].map((i) => i + startAt);
};
