// Dependencias
import Image from 'next/image';

// Componente
const NavbarTemplate = ({ bg, navbar, contenido }) => {
    return (
        <div className="flex flex-col w-full min-h-screen">
            <div className="fixed top-0 w-screen h-screen">
                <Image
                    className="w-full h-full object-fill select-none pointer-events-none z-0"
                    src={bg.src}
                    alt={bg.alt}
                    layout="fill"
                />
            </div>

            {navbar}

            <div className="w-full min-h-full pt-24 relative flex-grow">
                {contenido}
            </div>
        </div>
    );
};

// Exportación
export default NavbarTemplate;
