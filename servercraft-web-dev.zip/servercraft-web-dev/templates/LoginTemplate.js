// Dependencias
import Image from 'next/image';

// Componente
const LoginTemplate = (props) => {
    // Estados
    const { bg, navbar, formulario } = props;
    return (
        <div className="flex flex-col w-full min-h-screen">
            <Image
                src={bg.src}
                alt={bg.alt}
                layout="fill"
                className="absolute w-screen h-screen object-cover select-none pointer-events-none"
            />

            {navbar}

            <div className="transform absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-xl px-4 md:px-0">
                {formulario}
            </div>
        </div>
    );
};

// Exportación
export default LoginTemplate;
