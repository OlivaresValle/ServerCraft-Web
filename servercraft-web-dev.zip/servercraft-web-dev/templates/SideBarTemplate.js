// Dependencias
import Image from 'next/image';

// Componente
const SideBarTemplate = (props) => {
    // Estados
    const { bg, navbar, sidebar, cuerpo } = props;

    return (
        <div className="flex flex-col w-full min-h-screen">
            <Image
                src={bg.src}
                alt={bg.alt}
                layout="fill"
                className="absolute w-screen h-screen object-cover select-none pointer-events-none"
            />

            {navbar}

            <div className="flex w-full min-h-full max-h-screen pt-24 h-full relative flex-grow">
                <div className="w-full max-w-xs min-h-full -mt-1">
                    {sidebar}
                </div>

                <div className="w-full overflow-x-hidden overflow-y-auto pb-12">
                    <div className="container">{cuerpo}</div>
                </div>
            </div>
        </div>
    );
};

// Exportación
export default SideBarTemplate;
