// Dependencias
import { create } from 'axios';

// API Config
export const headers = (token) => ({
    headers: {
        Authorization: `Bearer ${token}`,
    },
});

export const api = create({
    baseURL: `${process.env.NEXT_PUBLIC_API_URL}`,
});
