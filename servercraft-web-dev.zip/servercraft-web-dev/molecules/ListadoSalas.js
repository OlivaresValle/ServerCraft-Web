// Dependencias
import {
    Breadcrumb,
    PrimaryButton,
    DetailsList,
    SelectionMode,
    DetailsListLayoutMode,
    Modal,
    Dialog,
    DialogFooter,
    Spinner,
    SpinnerSize,
    DefaultButton,
    SearchBox,
    ComboBox,
} from '@fluentui/react';
import { useState } from 'react';
import nookies from 'nookies';
import toast from 'react-hot-toast';
import ErrorToast from '../atoms/errorToast';
import SuccessToast from '../atoms/successToast';
import { CargandoTabla } from '../servicios/cargandoTabla';
import { useBoolean } from '@fluentui/react-hooks';
import BotonUD from '../atoms/BotonUD';
import { useSalas, createSala, editSala, deleteSala } from '../http/lib/sala';
import FormularioSalas from './FormularioSalas';
import { useRegiones } from '../http/lib/region';
import { usePaises } from '../http/lib/pais';
import debounce from 'lodash/debounce';
import Pagination from 'rc-pagination';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoSalas = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);
    const [isLoading, setIsLoading] = useState(false);
    const [salaSeleccionada, setSalaSeleccionada] = useState(undefined);

    // Filtros
    const [query, setQuery] = useState('');
    const [region, setRegion] = useState();
    const [pais, setPais] = useState();
    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        {
            key: 'nombre',
            name: 'Nombre',
            fieldName: 'nombre',
            minWidth: 250,
            maxWidth: 320,
            onRender: (item) => <p className="font-medium">{item.nombre}</p>,
        },
        {
            key: 'descripcion',
            name: 'Descripción',
            fieldName: 'descripcion',
            minWidth: 300,
            maxWidth: 400,
        },
        {
            key: 'region',
            name: 'Región',
            fieldName: 'region',
            minWidth: 250,
            maxWidth: 300,
        },
        {
            key: 'pais',
            name: 'País',
            minWidth: 200,
            maxWidth: 300,
            fieldName: 'pais',
        },
        ...(user?.data?.usuario?.rol?.id === 1
            ? [
                  {
                      key: 'acciones',
                      name: 'Acciones',
                      fieldName: 'acciones',
                  },
              ]
            : []),
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    const { data: dataSalas, mutate: mutateSalas } = useSalas(
        10,
        currentPage,
        query,
        token,
        region,
        pais
    );

    const { data: dataRegiones } = useRegiones(null, 10000000, 1, null, token);
    const { data: dataPaises } = usePaises(10000000, 1, null, token);

    // Handlers
    const handleCreateSala = async (values) => {
        setIsLoading(true);
        try {
            const response = await createSala({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateSalas();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'Sala creada con éxito.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditSala = async (values) => {
        setIsLoading(true);
        try {
            const response = await editSala({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateSalas();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'Sala editada correctamente.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteSala = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteSala({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateSalas();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'Sala eliminada exitosamente.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col py-12 px-16">
            <Breadcrumb
                className="py-4"
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Salas',
                        href: '/salas',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-bold text-4xl">
                    Listado de salas
                </h1>

                {user?.data?.usuario?.rol?.id === 1 && (
                    <PrimaryButton
                        iconProps={{ iconName: 'Add' }}
                        text="Nueva sala"
                        className="px-12"
                        onClick={showCreateModal}
                    />
                )}
            </div>

            {/* Filtros */}
            <div className="grid grid-cols-5 gap-4 mb-4 items-end">
                {/* Cuadro de busqueda (q) */}
                <SearchBox
                    placeholder="Filtrar por nombre, región, país..."
                    className="w-full col-span-3"
                    onChange={(q) => {
                        debouncedSetQuery(q?.target?.value ?? '');
                    }}
                    onClear={() => setQuery('')}
                />

                {/* Filtros por Región */}
                <div className="col-span-1">
                    <div className="flex justify-between mb-2">
                        <label className="font-medium">Región</label>

                        {region && (
                            <button
                                className="appearance-none text-primary-500 font-medium"
                                onClick={() => setRegion(null)}
                            >
                                Limpiar
                            </button>
                        )}
                    </div>

                    <ComboBox
                        placeholder="Seleccionar"
                        options={dataRegiones?.data?.regiones?.map(
                            (region) => ({
                                key: region.id,
                                text: region.nombre,
                            })
                        )}
                        selectedKey={region}
                        onChange={(_, region) => setRegion(region.key)}
                    />
                </div>

                {/* Filtros por País */}
                <div className="col-span-1">
                    <div className="flex justify-between mb-2">
                        <label className="font-medium">País</label>

                        {pais && (
                            <button
                                className="appearance-none text-primary-500 font-medium"
                                onClick={() => setPais(null)}
                            >
                                Limpiar
                            </button>
                        )}
                    </div>

                    <ComboBox
                        placeholder="Seleccionar"
                        options={dataPaises?.data?.paises?.map((pais) => ({
                            key: pais.id,
                            text: pais.nombre,
                        }))}
                        selectedKey={pais}
                        onChange={(_, pais) => setPais(pais.key)}
                    />
                </div>
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                layoutMode={DetailsListLayoutMode.justified}
                items={
                    dataSalas?.data?.salas?.map((sala) => ({
                        key: sala.id,
                        nombre: sala.nombre,
                        descripcion: sala.descripcion,
                        region: sala.region.nombre,
                        pais: sala.region.pais.nombre,
                        acciones: (
                            <BotonUD
                                showEdit
                                showDelete
                                onEdit={() => showEditModal()}
                                onDelete={() => showDeleteModal()}
                                setSelected={setSalaSeleccionada}
                                itemToSelect={sala}
                            />
                        ),
                    })) ?? arrayCargando
                }
            />

            {/* Paginación */}
            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataSalas?.data?.meta?.total}
                    pageSize={dataSalas?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioSalas
                        tipo="crear"
                        onSubmit={handleCreateSala}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioSalas
                        tipo="editar"
                        onSubmit={handleEditSala}
                        isLoading={isLoading}
                        valoresIniciales={salaSeleccionada}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar sala',
                    subText: `¿Estás de acuerdo con eliminar la sala: "${salaSeleccionada?.nombre}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteSala({
                                id: salaSeleccionada?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoSalas;
