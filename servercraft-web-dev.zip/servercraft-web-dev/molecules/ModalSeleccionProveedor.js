// Dependencias
import { useState } from 'react';
import nookies from 'nookies';
import { PrimaryButton, IconButton, Modal, ChoiceGroup } from '@fluentui/react';
import {
    Accordion,
    AccordionItem,
    AccordionHeader,
    AccordionPanel,
} from '@fluentui/react-accordion';
import { useProveedoresSistema } from '../http/lib/proveedorSistema/proveedorSistema.calls';
import { useEquiposEncargados } from '../http/lib/equipoEncargado';

// Componente
const ModalSeleccionProveedor = ({
    isOpen,
    onClose,
    defaultValue,
    onSelectionConfirm,
}) => {
    // Estados
    const token = nookies.get()['auth-token'];
    const [selectedTeam, setSelectedTeam] = useState();
    const [showError, setShowError] = useState(false);
    const { data: dataProveedoresSistemas } = useProveedoresSistema(
        100000000000,
        1,
        null,
        token,
        null,
        true
    );
    const { data: dataEquipos } = useEquiposEncargados(
        1000000000000,
        1,
        null,
        token
    );

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            isBlocking
            allowTouchBodyScroll
            styles={{
                scrollableContent: { overflow: 'visible' },
                root: { width: '100%' },
                main: { width: '100%', maxWidth: '1024px !important' },
            }}
            containerClassName="container"
            className="w-full h-full py-4 px-4 md:px-6"
        >
            <div className="w-full h-full shadow-2xl p-8 bg-gray-50">
                <div className="flex justify-between align-center w-full">
                    <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                        Seleccionar proveedor del sistema
                    </h1>

                    <IconButton
                        iconProps={{ iconName: 'ChromeClose' }}
                        onClick={onClose}
                    />
                </div>

                <div className="w-full h-full overflow-y-auto">
                    <Accordion defaultValue={0} className="mt-4 h-full">
                        {dataProveedoresSistemas?.data?.proveedores?.map(
                            (proveedor, k) => (
                                <AccordionItem key={proveedor?.id} value={k}>
                                    <AccordionHeader>
                                        <h2 className="text-base font-medium text-primary-500 ">
                                            {proveedor?.nombre}
                                        </h2>
                                    </AccordionHeader>

                                    <AccordionPanel className="pb-6">
                                        <ChoiceGroup
                                            selectedKey={
                                                selectedTeam?.id ?? defaultValue
                                            }
                                            onChange={(_, o) => {
                                                setSelectedTeam(
                                                    dataEquipos?.data?.equipos_encargados.find(
                                                        (e) => e.id === o.key
                                                    )
                                                );
                                                setShowError(false);
                                            }}
                                            options={dataEquipos?.data?.equipos_encargados
                                                .filter(
                                                    (e) =>
                                                        e.proveedor_sistema
                                                            .id === proveedor.id
                                                )
                                                .map((eq) => ({
                                                    key: eq.id,
                                                    text: eq.nombre,
                                                }))}
                                        />
                                    </AccordionPanel>
                                </AccordionItem>
                            )
                        )}
                    </Accordion>
                </div>

                {showError && (
                    <p className="font-medium text-danger-400 mt-12">
                        Debes seleccionar al menos 1 proveedor.
                    </p>
                )}

                <PrimaryButton
                    className="mt-6"
                    onClick={() =>
                        !selectedTeam
                            ? setShowError(true)
                            : onSelectionConfirm(selectedTeam)
                    }
                >
                    Confirmar selección
                </PrimaryButton>
            </div>
        </Modal>
    );
};

// Export
export default ModalSeleccionProveedor;
