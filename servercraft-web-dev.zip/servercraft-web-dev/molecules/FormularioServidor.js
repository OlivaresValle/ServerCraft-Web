// Dependencias
import nookies from 'nookies';
import * as yup from 'yup';
import { PrimaryButton, Spinner, IconButton } from '@fluentui/react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import ControlledInput from '../atoms/controlledInput';
import ControlledSelect from '../atoms/controlledSelect';
import { useServidor } from '../http/lib/servidor';
import { useRacks } from '../http/lib/rack';
import ControlledCheckbox from '../atoms/controlledCheckbox';
import { useTiposServidores } from '../http/lib/tipoServidor';
import { useSistemasOperativos } from '../http/lib/sistemaOperativo/sistema.calls';
import { useMotoresDBList } from '../http/lib/motorDB/motorDB.calls';
import { useEffect, useState } from 'react';

const servidorSchema = yup
    .object({
        nombre: yup
            .string()
            .required('Campo obligatorio')
            .max(255, 'El campo debe tener menos de 255 caracteres'),
        ip: yup
            .string()
            .required('Campo obligatorio')
            .matches(
                /^(\d|[1-9]\d|1\d\d|2([0-4]\d|5[0-5]))\.(\d|[1-9]\d|1\d\d|2([0-4]\d|5[0-5]))\.(\d|[1-9]\d|1\d\d|2([0-4]\d|5[0-5]))\.(\d|[1-9]\d|1\d\d|2([0-4]\d|5[0-5]))$/,
                'El campo debe ser una IP válida sin puerto'
            ),
        usuarioIngreso: yup
            .string()
            .required('Campo obligatorio')
            .max(30, 'El campo debe tener menos de 30 caracteres'),
        contrasenaIngreso: yup
            .string()
            .required('Campo obligatorio')
            .max(120, 'El campo debe tener menos de 120 caracteres'),
        disco: yup
            .number()
            .min(1, 'Debes ingresar un número positivo')
            .typeError('Debes ingresar un número válido')
            .required('Campo obligatorio'),
        memoria: yup
            .number()
            .min(1, 'Debes ingresar un número positivo')
            .typeError('Debes ingresar un número válido')
            .required('Campo obligatorio'),
        poseeGarantia: yup.boolean().required('Campo obligatorio'),
        nombreContactoMantencion: yup
            .string()
            .max(120, 'El campo debe tener menos de 120 caracteres'),
        telefonoContactoMantencion: yup
            .string()
            .max(12, 'El campo debe tener menos de 12 caracteres'),
        emailContactoMantencion: yup
            .string()
            .email('Ingrese un formato correcto de email')
            .max(120, 'El campo debe tener menos de 120 caracteres'),
        idRack: yup.number().required('Campo obligatorio'),
        idTipoServidor: yup.number().required('Campo obligatorio'),
        idSistemaOperativo: yup.number().required('Campo obligatorio'),
        idBaseDatos: yup.number(),
    })
    .required();

// Componente
const FormularioServidor = ({
    valoresIniciales,
    tipo,
    onSubmit,
    isLoading,
    onCloseModal,
}) => {
    // Estados
    const token = nookies.get()['auth-token'];

    const [valoresSeteados, setValoresSeteados] = useState(false);

    const { handleSubmit, control, setValue, watch } = useForm({
        resolver: yupResolver(servidorSchema),
        defaultValues: {
            ...valoresIniciales,
        },
    });

    const poseeGarantia = watch('poseeGarantia');
    const tipoServidor = watch('idTipoServidor');

    const { data: dataServidor } = useServidor(valoresIniciales?.id, token);

    const { data: dataRacks } = useRacks(100000000, 1, null, token);

    const { data: dataTiposServidores } = useTiposServidores(
        100000000,
        1,
        null,
        token
    );

    const { data: dataSistemasOperativos } = useSistemasOperativos(
        100000000,
        1,
        null,
        token
    );

    const { data: dataMotoresDB } = useMotoresDBList(
        1000000000,
        1,
        null,
        token
    );

    // Efecto
    useEffect(() => {
        if (!valoresSeteados && dataServidor && tipo === 'editar') {
            setValue('nombre', dataServidor?.data?.servidor?.nombre);
            setValue('ip', dataServidor?.data?.servidor?.ip);
            setValue(
                'usuarioIngreso',
                dataServidor?.data?.servidor?.usuario_ingreso
            );
            setValue(
                'contrasenaIngreso',
                dataServidor?.data?.servidor?.contrasena_ingreso
            );
            setValue('disco', dataServidor?.data?.servidor?.disco);
            setValue('memoria', dataServidor?.data?.servidor?.memoria);
            setValue(
                'poseeGarantia',
                dataServidor?.data?.servidor?.posee_garantia
            );
            setValue(
                'nombreContactoMantencion',
                dataServidor?.data?.servidor?.nombre_contacto_mantencion
            );
            setValue(
                'telefonoContactoMantencion',
                dataServidor?.data?.servidor?.telefono_contacto_mantencion
            );
            setValue(
                'emailContactoMantencion',
                dataServidor?.data?.servidor?.email_contacto_mantencion
            );
            setValue('idRack', dataServidor?.data?.servidor?.rack?.id);
            setValue(
                'idTipoServidor',
                dataServidor?.data?.servidor?.tipo_servidor?.id
            );
            setValue(
                'idSistemaOperativo',
                dataServidor?.data?.servidor?.sistema_operativo?.id
            );
            setValue(
                'idBaseDatos',
                dataServidor?.data?.servidor?.base_datos?.id
            );
            setValoresSeteados(true);
        }
    }, [valoresIniciales, dataServidor, valoresSeteados, tipo, setValue]);

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            className="w-full shadow-2xl p-8 bg-gray-50"
        >
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                    {tipo === 'crear' ? 'Crear servidor' : 'Editar servidor'}
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                />
            </div>

            <div className="grid gap-y-4">
                <ControlledInput
                    control={control}
                    name="nombre"
                    label="Nombre del servidor"
                    disabled={
                        !valoresSeteados && !dataServidor && tipo === 'editar'
                    }
                />

                <ControlledInput
                    control={control}
                    name="ip"
                    label="Dirección IP"
                    disabled={
                        !valoresSeteados && !dataServidor && tipo === 'editar'
                    }
                />

                <ControlledInput
                    control={control}
                    name="usuarioIngreso"
                    label="Usuario de ingreso"
                    disabled={
                        !valoresSeteados && !dataServidor && tipo === 'editar'
                    }
                />

                <ControlledInput
                    control={control}
                    name="contrasenaIngreso"
                    label="Contraseña de ingreso"
                    type="password"
                    canRevealPassword
                    disabled={
                        !valoresSeteados && !dataServidor && tipo === 'editar'
                    }
                />

                <ControlledInput
                    control={control}
                    name="disco"
                    type="number"
                    label="Almacenamiento (GB)"
                    disabled={
                        !valoresSeteados && !dataServidor && tipo === 'editar'
                    }
                />

                <ControlledInput
                    control={control}
                    name="memoria"
                    type="number"
                    label="Memoria RAM (GB)"
                    placeholder="16"
                    disabled={
                        !valoresSeteados && !dataServidor && tipo === 'editar'
                    }
                />

                <h1
                    className={`font-semibold mb-0 ${
                        !valoresSeteados && !dataServidor && tipo === 'editar'
                            ? 'text-gray-400'
                            : ''
                    }`}
                >
                    Garantía
                </h1>

                {(tipo === 'editar' ? poseeGarantia !== undefined : true) && (
                    <ControlledCheckbox
                        control={control}
                        name="poseeGarantia"
                        label="Posee garantía"
                        disabled={
                            !valoresSeteados &&
                            !dataServidor &&
                            tipo === 'editar'
                        }
                    />
                )}

                <ControlledInput
                    control={control}
                    name="nombreContactoMantencion"
                    label="Nombre del contacto de mantención"
                    placeholder="Ingrese el nombre del contacto"
                    disabled={
                        !valoresSeteados && !dataServidor && tipo === 'editar'
                    }
                />

                <ControlledInput
                    control={control}
                    name="telefonoContactoMantencion"
                    label="Teléfono del contacto de mantención"
                    placeholder="+56912345678"
                    disabled={
                        !valoresSeteados && !dataServidor && tipo === 'editar'
                    }
                />

                <ControlledInput
                    control={control}
                    name="emailContactoMantencion"
                    label="Email del contacto de mantención"
                    placeholder="direccion@email.cl"
                    disabled={
                        !valoresSeteados && !dataServidor && tipo === 'editar'
                    }
                />

                <ControlledSelect
                    control={control}
                    name="idRack"
                    label="Rack del servidor"
                    placeholder="Seleccione el Rack del servidor"
                    disabled={
                        !valoresSeteados && !dataServidor && tipo === 'editar'
                    }
                    options={
                        dataRacks?.data?.racks?.map((rack) => ({
                            key: rack.id,
                            text: rack.nombre,
                        })) ?? []
                    }
                />

                <ControlledSelect
                    control={control}
                    name="idTipoServidor"
                    label="Tipo de servidor"
                    placeholder="Seleccione el Tipo de servidor"
                    disabled={
                        !valoresSeteados && !dataServidor && tipo === 'editar'
                    }
                    options={
                        dataTiposServidores?.data?.tipos_servidor?.map(
                            (tipoServidor) => ({
                                key: tipoServidor.id,
                                text: tipoServidor.nombre,
                            })
                        ) ?? []
                    }
                />

                <ControlledSelect
                    control={control}
                    name="idSistemaOperativo"
                    label="Sistema operativo"
                    placeholder="Seleccione el S.O"
                    disabled={
                        !valoresSeteados && !dataServidor && tipo === 'editar'
                    }
                    options={
                        dataSistemasOperativos?.data?.sistemas_operativos?.map(
                            (sistemaOperativo) => ({
                                key: sistemaOperativo.id,
                                text: sistemaOperativo.nombre,
                            })
                        ) ?? []
                    }
                />

                {[2, 3].includes(tipoServidor) && (
                    <ControlledSelect
                        control={control}
                        name="idBaseDatos"
                        label="Motor de la Base de datos"
                        placeholder="Seleccione el Motor de la base de datos"
                        disabled={
                            !valoresSeteados &&
                            !dataServidor &&
                            tipo === 'editar'
                        }
                        options={
                            dataMotoresDB?.data?.bases_de_datos?.map(
                                (motorDB) => ({
                                    key: motorDB.id,
                                    text: motorDB.nombre,
                                })
                            ) ?? []
                        }
                    />
                )}
            </div>

            <PrimaryButton type="submit" className="mt-8 w-full" loading>
                {isLoading && <Spinner className="mr-2" />}Guardar servidor
            </PrimaryButton>
        </form>
    );
};

// Exportación
export default FormularioServidor;
