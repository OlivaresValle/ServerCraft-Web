// Dependencias
import nookies from 'nookies';
import * as yup from 'yup';
import { PrimaryButton, Spinner, IconButton } from '@fluentui/react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useRol } from '../http/lib/roles/roles.calls';
import { useEquiposTrabajos } from '../http/lib/equipoTrabajo/equipoTrabajo.calls';
import ControlledInput from '../atoms/controlledInput';
import ControlledSelect from '../atoms/controlledSelect';

const usuarioSchema = (tipo) =>
    yup
        .object({
            email: yup
                .string()
                .email('Ingresa un email válido')
                .required('Campo obligatorio')
                .max(250, 'El campo debe tener menos de 250 caracteres')
                .matches(
                    /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                    'Ingresa un email válido'
                ),
            rut: yup
                .string()
                .required('Campo obligatorio')
                .min(9, 'El rut debe tener mínimo 9 caracteres')
                .max(10, 'El rut debe tener máximo 10 caracteres')
                .matches(
                    /^[0-9]+[-|‐]{1}[0-9kK]{1}$/,
                    'El campo debe ser un rut válido'
                ),
            nombre: yup
                .string()
                .required('Campo obligatorio')
                .max(120, 'El campo debe tener menos de 120 caracteres'),
            apellidos: yup
                .string()
                .required('Campo obligatorio')
                .max(50, 'El campo debe tener menos de 50 caracteres'),
            telefonoContacto: yup
                .number()
                .typeError('El teléfono debe ser un número válido')
                .required('Campo obligatorio')
                .min(
                    900000000,
                    'El teléfono debe ser un número positivo de 9 caracteres'
                )
                .max(
                    999999999,
                    'El número de teléfono debe ser de 9 caracteres'
                ),
            password:
                tipo === 'crear' &&
                yup
                    .string()
                    .required('Campo obligatorio')
                    .max(255, 'El campo debe tener menos de 255 caracteres'),
            confirmPassword:
                tipo === 'crear' &&
                yup
                    .string()
                    .required('Campo obligatorio')
                    .oneOf(
                        [yup.ref('password'), null],
                        'Las contraseñas no coinciden'
                    ),
            idRol: yup.number().required('Campo obligatorio'),
            idEquipo: yup.number().nullable(true),
        })
        .required();

// Componente
const FormularioUsuario = ({
    valoresIniciales,
    tipo,
    onSubmit,
    isLoading,
    onCloseModal,
}) => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: dataRoles } = useRol(10, 1, null, token);
    const { data: dataEquiposTrabajo } = useEquiposTrabajos(
        999,
        1,
        undefined,
        token
    );

    const { handleSubmit, control } = useForm({
        resolver: yupResolver(usuarioSchema(tipo)),
        defaultValues: {
            ...valoresIniciales,
            telefonoContacto: valoresIniciales?.telefono_contacto,
            idRol: valoresIniciales?.rol?.id,
            idEquipo: valoresIniciales?.equipo_trabajo?.id,
        },
    });

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            className="w-full shadow-2xl p-8 bg-gray-50"
        >
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                    {tipo === 'crear' ? 'Crear usuario' : 'Editar usuario'}
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                ></IconButton>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 md:gap-x-12">
                <ControlledInput
                    control={control}
                    name="nombre"
                    label="Nombres"
                    placeholder=""
                    className="col-span-1"
                />

                <ControlledInput
                    control={control}
                    name="apellidos"
                    label="Apellidos"
                    placeholder=""
                    className="col-span-1"
                />

                <ControlledInput
                    control={control}
                    name="rut"
                    label="Rut"
                    placeholder="12345678-9"
                    className="col-span-1"
                    disabled={tipo === 'editar'}
                />

                <ControlledInput
                    control={control}
                    name="email"
                    label="Correo electrónico"
                    placeholder="correo@correo.cl"
                    className="col-span-1"
                    disabled={tipo === 'editar'}
                />

                <ControlledInput
                    control={control}
                    name="telefonoContacto"
                    label="Teléfono"
                    placeholder="912345678"
                    prefix="+56"
                    type="number"
                    className="col-span-1"
                />

                <ControlledSelect
                    control={control}
                    name="idRol"
                    label="Rol"
                    placeholder="Seleccionar rol"
                    className="col-span-1"
                    options={
                        dataRoles?.data?.rol?.map((rol) => ({
                            key: rol.id,
                            text: rol.nombre,
                        })) ?? []
                    }
                />

                <ControlledSelect
                    control={control}
                    name="idEquipo"
                    label="Equipo de trabajo (opcional)"
                    placeholder="Seleccionar equipo de trabajo"
                    className="col-span-1"
                    options={
                        dataEquiposTrabajo?.data?.equipos_trabajo?.map(
                            (equipoTrabajo) => ({
                                key: equipoTrabajo.id,
                                text: equipoTrabajo.nombre,
                            })
                        ) ?? []
                    }
                />

                {tipo === 'crear' && (
                    <ControlledInput
                        control={control}
                        name="password"
                        label="Contraseña"
                        type="password"
                        canRevealPassword
                        className="col-span-1"
                    />
                )}

                {tipo === 'crear' && (
                    <ControlledInput
                        control={control}
                        name="confirmPassword"
                        label="Confirmar contraseña"
                        type="password"
                        canRevealPassword
                        className="col-span-1"
                    />
                )}
            </div>

            <PrimaryButton type="submit" className="mt-8 w-full" loading>
                {isLoading && <Spinner className="mr-2" />}Guardar usuario
            </PrimaryButton>
        </form>
    );
};

// Exportación
export default FormularioUsuario;
