// Dependencias
import { useEffect, useState } from 'react';
import {
    Breadcrumb,
    PrimaryButton,
    DetailsList,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    DefaultButton,
    Spinner,
    SpinnerSize,
    SearchBox,
    ComboBox,
} from '@fluentui/react';
import { useBoolean } from '@fluentui/react-hooks';
import nookies from 'nookies';
import {
    useEquiposEncargados,
    createEquipoEncargado,
    editEquipoEncargado,
    deleteEquipoEncargado,
} from '../http/lib/equipoEncargado';
import { useProveedoresSistema } from '../http/lib/proveedorSistema';
import { CargandoTabla } from '../servicios/cargandoTabla';
import FormularioCliente from './FormularioEquipoProveedor';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import SuccessToast from '../atoms/successToast';
import ErrorToast from '../atoms/errorToast';
import DetalleEquipoProveedor from './DetalleEquipoProveedor';
import debounce from 'lodash/debounce';
import Pagination from 'rc-pagination';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoEquipoEncargado = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);

    const [isLoading, setIsLoading] = useState(false);
    const [EquipoEncargadoSeleccionado, setEquipoEncargadoSeleccionado] =
        useState(undefined);

    //Filtros
    const [query, setQuery] = useState('');
    const [proveedor, setProveedor] = useState();

    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isDetailModalOpen,
        { setTrue: showDetailModal, setFalse: hideDetailModal },
    ] = useBoolean(false);
    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        { key: 'nombre', name: 'Equipo', fieldName: 'nombre' },
        {
            key: 'representante',
            name: 'Representante',
            fieldName: 'representante',
            minWidth: 230,
        },
        {
            key: 'proveedor',
            name: 'Proveedor',
            fieldName: 'proveedor',
            minWidth: 230,
        },
        {
            key: 'acciones',
            name: 'Acciones',
            fieldName: 'acciones',
        },
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    const { data: dataEquiposEncargado, mutate: mutateEncargado } =
        useEquiposEncargados(10, currentPage, query, token, proveedor);

    const { data: dataProveedor } = useProveedoresSistema(
        10000,
        1,
        null,
        token
    );

    // Efectos
    useEffect(() => {
        setCurrentPage(1);
    }, [query, proveedor]);

    // Handlers
    const handleCreateEquipoEncargado = async (values) => {
        setIsLoading(true);
        try {
            const response = await createEquipoEncargado({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateEncargado();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'Cliente creado con éxito.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditEquipoEncargado = async ({ ...values }) => {
        setIsLoading(true);
        try {
            const response = await editEquipoEncargado({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateEncargado();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Cliente editado correctamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteEquipoEncargado = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteEquipoEncargado({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateEncargado();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Cliente eliminado exitosamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-6 px-16">
            <Breadcrumb
                className="py-4"
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Clientes o proveedores',
                        key: 'equipo_encargado',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-semibold text-4xl">
                    Listado de equipos de proveedores
                </h1>

                {[1, 2].includes(user?.data?.usuario?.rol?.id)
                    ? [
                          <PrimaryButton
                              iconProps={{ iconName: 'Add' }}
                              text="Nuevo equipo"
                              className="px-12"
                              onClick={showCreateModal}
                              key={user?.data?.usuario?.rol?.id}
                          />,
                      ]
                    : []}
            </div>

            {/* Filtros */}
            <div className="grid grid-cols-5 gap-4 mb-4 items-end">
                {/* Cuadro de busqueda (q) */}
                <SearchBox
                    placeholder="Filtrar por nombre, proveedor..."
                    className="col-span-4"
                    onChange={(q) => {
                        debouncedSetQuery(q?.target?.value ?? '');
                    }}
                    onClear={() => setQuery('')}
                />

                {/* Filtros por Tipo Servidor */}
                <div className="col-span-1">
                    <div className="flex justify-between mb-2">
                        <label className="font-medium">Proveedor</label>

                        {proveedor && (
                            <button
                                className="appearance-none text-primary-500 font-medium"
                                onClick={() => setProveedor(null)}
                            >
                                Limpiar
                            </button>
                        )}
                    </div>

                    <ComboBox
                        placeholder="Seleccionar"
                        options={dataProveedor?.data?.proveedores?.map(
                            (proveedor) => ({
                                key: proveedor.id,
                                text: proveedor.nombre,
                            })
                        )}
                        selectedKey={proveedor}
                        onChange={(_, proveedor) => setProveedor(proveedor.key)}
                    />
                </div>
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataEquiposEncargado?.data?.equipos_encargados?.map(
                        (equipo_encargado) => ({
                            key: equipo_encargado.id,
                            nombre: equipo_encargado.nombre,
                            proveedor:
                                equipo_encargado.proveedor_sistema.nombre,
                            representante:
                                equipo_encargado?.proveedor_sistema
                                    ?.nombre_representante,
                            acciones: (
                                <BotonUD
                                    showDetail={
                                        user?.data?.usuario?.rol?.id !== 4
                                    }
                                    showEdit={[1, 2].includes(
                                        user?.data?.usuario?.rol?.id
                                    )}
                                    showDelete={
                                        user?.data?.usuario?.rol?.id === 1
                                    }
                                    onViewDetail={() => showDetailModal()}
                                    onEdit={() => showEditModal()}
                                    onDelete={() => showDeleteModal()}
                                    setSelected={setEquipoEncargadoSeleccionado}
                                    itemToSelect={equipo_encargado}
                                />
                            ),
                        })
                    ) ?? arrayCargando
                }
            />

            {/* Paginación */}
            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataEquiposEncargado?.data?.meta?.total}
                    pageSize={dataEquiposEncargado?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            <Modal
                isOpen={isDetailModalOpen}
                onDismiss={hideDetailModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isDetailModalOpen && (
                    <DetalleEquipoProveedor
                        equipo_encargado={EquipoEncargadoSeleccionado}
                        onCloseModal={hideDetailModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioCliente
                        tipo="crear"
                        onSubmit={handleCreateEquipoEncargado}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioCliente
                        tipo="editar"
                        onSubmit={handleEditEquipoEncargado}
                        isLoading={isLoading}
                        valoresIniciales={EquipoEncargadoSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar equipo',
                    subText: `¿Estás de acuerdo con eliminar el equipo: "${EquipoEncargadoSeleccionado?.nombre} - ${EquipoEncargadoSeleccionado?.proveedor_sistema?.nombre}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteEquipoEncargado({
                                id: EquipoEncargadoSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoEquipoEncargado;
