// Dependencias
import { useEffect, useState } from 'react';
import {
    Breadcrumb,
    PrimaryButton,
    DetailsList,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    DefaultButton,
    Spinner,
    SpinnerSize,
    SearchBox,
} from '@fluentui/react';
import Pagination from 'rc-pagination';
import { useBoolean } from '@fluentui/react-hooks';
import nookies from 'nookies';
import {
    createUnidadNegocio,
    editUnidadNegocio,
    useUnidadNegocios,
    deleteUnidadNegocio,
} from '../http/lib/unidadNegocio';
import { CargandoTabla } from '../servicios/cargandoTabla';
import FormularioUnidadNegocio from './FormularioUnidadNegocio';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import SuccessToast from '../atoms/successToast';
import ErrorToast from '../atoms/errorToast';
import debounce from 'lodash/debounce';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

//componentes

const ListadoUnidadNegocio = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);

    const [isLoading, setIsLoading] = useState(false);
    const [unidadSeleccionado, setUnidadSeleccionado] = useState(undefined);

    // Filtros
    const [query, setQuery] = useState('');

    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        { key: 'nombre', name: 'Nombre', fieldName: 'nombre' },
        {
            key: 'equipos',
            name: 'Cantidad de equipos',
            fieldName: 'equipos',
            minWidth: 180,
        },
        ...(user?.data?.usuario?.rol?.id === 1
            ? [
                  {
                      key: 'acciones',
                      name: 'Acciones',
                      fieldName: 'acciones',
                  },
              ]
            : []),
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    // API
    const { data: dataUnidadNegocios, mutate: mutateUnidadNegocio } =
        useUnidadNegocios(10, currentPage, query, token);

    // Efectos
    useEffect(() => {
        setCurrentPage(1);
    }, [query]);

    // Handlers
    const handleCreateUnidadNegocio = async (values) => {
        setIsLoading(true);
        try {
            const response = await createUnidadNegocio({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateUnidadNegocio();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'unidad creado con éxito.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditUnidadNegocio = async ({ ...values }) => {
        setIsLoading(true);
        try {
            const response = await editUnidadNegocio({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateUnidadNegocio();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Unidad de Negocio editado correctamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteUnidadNegocio = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteUnidadNegocio({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateUnidadNegocio();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Unidad negocio eliminado exitosamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-6 px-16">
            <Breadcrumb
                className="py-4"
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Usuarios y equipos',
                        key: 'unidad-negocio',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-semibold text-4xl">
                    Listado de unidades de negocio
                </h1>

                {user?.data?.usuario?.rol?.id === 1 && (
                    <PrimaryButton
                        iconProps={{ iconName: 'Add' }}
                        text="Nueva unidad de negocio"
                        className="px-12"
                        onClick={showCreateModal}
                    />
                )}
            </div>

            {/* Filtros */}
            <div>
                <div className="flex justify-between flex-wrap gap-4 mb-4">
                    {/* Cuadro de busqueda (q) */}
                    <SearchBox
                        placeholder="Filtrar por nombre de unidad de negocios"
                        className="w-full"
                        onChange={(q) => {
                            debouncedSetQuery(q?.target?.value ?? '');
                        }}
                        onClear={() => setQuery('')}
                    />
                </div>
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataUnidadNegocios?.data?.unidades_negocio?.map(
                        (unidadNegocio) => ({
                            key: unidadNegocio.id,
                            nombre: unidadNegocio.nombre,
                            equipos: unidadNegocio.meta.equipos_count,
                            acciones: (
                                <BotonUD
                                    showEdit
                                    showDelete
                                    onEdit={() => showEditModal()}
                                    onDelete={() => showDeleteModal()}
                                    setSelected={setUnidadSeleccionado}
                                    itemToSelect={unidadNegocio}
                                />
                            ),
                        })
                    ) ?? arrayCargando
                }
            />

            {/* Paginación */}

            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataUnidadNegocios?.data?.meta?.total}
                    pageSize={dataUnidadNegocios?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>
            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioUnidadNegocio
                        tipo="crear"
                        onSubmit={handleCreateUnidadNegocio}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioUnidadNegocio
                        tipo="editar"
                        onSubmit={handleEditUnidadNegocio}
                        isLoading={isLoading}
                        valoresIniciales={unidadSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar unidad',
                    subText: `¿Estás de acuerdo con eliminar la unidad: "${unidadSeleccionado?.nombre}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteUnidadNegocio({
                                id: unidadSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoUnidadNegocio;
