// Dependencies
import { IconButton, Separator } from '@fluentui/react';
import { useUsuario } from '../http/lib/usuario';
import nookies from 'nookies';
import { Shimmer } from '@fluentui/react';
import { Persona, PersonaSize } from '@fluentui/react';

// Componente
const DetalleUsuario = ({ usuario, onCloseModal }) => {
    // Estados
    const token = nookies.get()['auth-token'];

    const { data: dataUsuario } = useUsuario(usuario.id, token);

    return (
        <div className="w-full p-8 bg-gray-50">
            {/* Titulo de Modal */}
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                    Detalle de usuario
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                />
            </div>

            {/* Información General */}
            <div className="flex flex-col mt-4 mb-4">
                <div className="grid grid-cols-2 gap-y-6">
                    <div className="col-span-2">
                        <Persona
                            size={PersonaSize.size72}
                            imageUrl={dataUsuario?.data?.usuario?.imagen?.url}
                            imageAlt={dataUsuario?.data?.usuario?.nombre}
                            styles={{
                                primaryText: { fontWeight: '600' },
                            }}
                        />
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Rut usuario
                        </h3>

                        {dataUsuario ? (
                            <p>{dataUsuario.data.usuario.rut}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Nombre completo
                        </h3>

                        {dataUsuario ? (
                            <p>
                                {dataUsuario.data.usuario.nombre +
                                    ' ' +
                                    dataUsuario.data.usuario.apellidos}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Email
                        </h3>

                        {dataUsuario ? (
                            <p>{dataUsuario.data.usuario.email}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Teléfono contacto
                        </h3>

                        {dataUsuario ? (
                            <p>{dataUsuario.data.usuario.telefono_contacto}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Equipo de trabajo
                        </h3>

                        {dataUsuario ? (
                            <p>
                                {dataUsuario.data.usuario.equipo_trabajo
                                    ? data.data.usuario.equipo_trabajo
                                    : 'Usuario sin equipo'}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Rol usuario
                        </h3>

                        {dataUsuario ? (
                            <p>{dataUsuario.data.usuario.rol.nombre}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

// Export
export default DetalleUsuario;
