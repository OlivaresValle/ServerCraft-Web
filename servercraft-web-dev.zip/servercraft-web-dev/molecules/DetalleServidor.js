// Dependencies
import { IconButton, Separator } from '@fluentui/react';
import { useIncidente } from '../http/lib/incidente';
import nookies from 'nookies';
import dayjs from 'dayjs';
import { Shimmer } from '@fluentui/react';
import localizedFormat from 'dayjs/plugin/localizedFormat';
import { useServidor } from '../http/lib/servidor';

dayjs.extend(localizedFormat);
dayjs.locale('es');

// Componente
const DetalleServidor = ({ servidor, onCloseModal }) => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data } = useServidor(servidor.id, token);

    return (
        <div className="w-full p-8 bg-gray-50">
            {/* Titulo de Modal */}
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                    Detalle de Servidor
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                />
            </div>

            {/* Detalle General */}
            <div className="flex flex-col mt-4 mb-4">
                <h2 className="font-semibold text-lg text-primary-500 mb-3">
                    Información general
                </h2>

                <div className="grid grid-cols-4 gap-y-6">
                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Nombre servidor
                        </h3>

                        {data ? (
                            <p>{data.data.servidor.nombre}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Tipo servidor
                        </h3>

                        {data ? (
                            <p>{data.data.servidor.tipo_servidor.nombre}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            IP
                        </h3>

                        {data ? (
                            <p>{data.data.servidor.ip}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Sistema operativo
                        </h3>

                        {data ? (
                            <p>{data.data.servidor.sistema_operativo.nombre}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Base de datos
                        </h3>

                        {data ? (
                            <p>
                                {data?.data?.servidor?.base_datos?.nombre ??
                                    'No aplica'}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Almacenamiento
                        </h3>

                        {data ? (
                            <p>{data.data.servidor.disco} GB</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Memoria RAM
                        </h3>

                        {data ? (
                            <p>{data.data.servidor.memoria} GB</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>
                </div>
            </div>

            <Separator />

            {/* Ubicacion Física */}
            <div className="flex flex-col mt-4 mb-4">
                <h2 className="font-semibold text-lg text-primary-500 mb-3">
                    Ubicación física
                </h2>

                <div className="grid grid-cols-4 gap-y-6">
                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Rack
                        </h3>

                        {data ? (
                            <p>{data.data.servidor.rack.nombre}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Sala
                        </h3>

                        {data ? (
                            <p>{data.data.servidor.rack.sala.nombre}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Región
                        </h3>

                        {data ? (
                            <p>{data.data.servidor.rack.sala.region.nombre}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            País
                        </h3>

                        {data ? (
                            <p>
                                {
                                    data.data.servidor.rack.sala.region.pais
                                        .nombre
                                }
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>
                </div>
            </div>

            <Separator />

            {/* Credenciales Acceso */}
            <div className="flex flex-col mt-4 mb-4">
                <h2 className="font-semibold text-lg text-primary-500 mb-3">
                    Credenciales acceso
                </h2>

                <div className="grid grid-cols-4 gap-y-6">
                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Usuario
                        </h3>

                        {data ? (
                            <p>
                                {data?.data?.servidor?.usuario_ingreso ??
                                    'No posee permisos para ver esta información'}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Contraseña
                        </h3>

                        {data ? (
                            <p>
                                {data?.data?.servidor?.contrasena_ingreso ??
                                    'No posee permisos para ver esta información'}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>
                </div>
            </div>

            <Separator />

            {/* Contacto mantención */}
            <div className="flex flex-col mt-4 mb-4">
                <h2 className="font-semibold text-lg text-primary-500 mb-3">
                    Contacto mantención
                </h2>

                <div className="grid grid-cols-4 gap-y-6">
                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Nombre completo
                        </h3>

                        {data ? (
                            <p>
                                {
                                    data?.data?.servidor
                                        ?.nombre_contacto_mantencion
                                }
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Email
                        </h3>

                        {data ? (
                            <p>
                                {
                                    data?.data?.servidor
                                        ?.email_contacto_mantencion
                                }
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Teléfono
                        </h3>

                        {data ? (
                            <p>
                                {
                                    data?.data?.servidor
                                        ?.telefono_contacto_mantencion
                                }
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            ¿Posee garantía?
                        </h3>

                        {data ? (
                            <p>
                                {data?.data?.servidor?.posee_garantia
                                    ? 'Si, posee garantía'
                                    : 'No posee garantía'}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

// Export
export default DetalleServidor;
