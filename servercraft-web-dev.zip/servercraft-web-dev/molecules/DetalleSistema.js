//Dependencies
import { IconButton, Separator, Link, Icon } from '@fluentui/react';
import { useSistema } from '../http/lib/sistema/sistema.calls';
import nookies from 'nookies';
import { Shimmer } from '@fluentui/react';

//Componente
const DetalleSistema = ({ sistema, onCloseModal }) => {
    //Estados
    const token = nookies.get()['auth-token'];
    const { data } = useSistema(sistema.id, token);

    return (
        <div className="w-full p-8 bg-gray-50">
            {/* Titulo del Modal */}
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                    Detalle del sistema
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                />
            </div>

            {/* Detalle del Sistema */}
            <div className="flex flex-col mt-4 mb-4">
                {/* Información General Sistema */}
                <h2 className="font-semibold text-lg text-primary-500 mb-3">
                    Información general
                </h2>

                <div className="grid grid-cols-3 gap-y-6">
                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Nombre del sistema
                        </h3>

                        {data ? (
                            <p>{data.data.sistema.nombre}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Equipo del proveedor
                        </h3>

                        {data ? (
                            <p>{data.data.sistema.equipo_proveedor.nombre}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Servidor de la base de datos
                        </h3>

                        {data ? (
                            <p>
                                {data.data.sistema.servidor_db
                                    ? data.data.sistema.servidor_db.nombre
                                    : 'Sin servidor base de datos'}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Nivel de seguridad
                        </h3>

                        {data ? (
                            <p>{data.data.sistema.nivel_seguridad.nombre}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Nivel de sensibilidad
                        </h3>

                        {data ? (
                            <p>
                                {data.data.sistema.nivel_sensibilidad
                                    ? data.data.sistema.nivel_sensibilidad
                                          .nombre
                                    : 'Sin nivel de sensibilidad'}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Usuario
                        </h3>

                        {data ? (
                            <p>{data.data.sistema.usuario.nombre}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>
                </div>

                <Separator />

                {/* Instancias del Sistema */}
                <h2 className="font-semibold text-lg text-primary-500 mb-3">
                    Instancias del sistema
                </h2>

                <div>
                    {data?.data?.sistema?.instancias.length > 0 && (
                        <div className="grid grid-cols-3 gap-y-6">
                            <h3 className="font-medium text-primary-500 mb-1">
                                Servidor de las instancias
                            </h3>

                            <h3 className="font-medium text-primary-500 mb-1">
                                Tipo de las instancias
                            </h3>

                            <h3 className="font-medium text-primary-500 mb-1">
                                Estado de las instancias
                            </h3>
                        </div>
                    )}

                    {data ? (
                        data?.data?.sistema?.instancias?.length > 0 ? (
                            data?.data?.sistema?.instancias.map((instancia) => (
                                <div
                                    key={instancia.id}
                                    className="grid grid-cols-3 gap-y-6 mb-2"
                                >
                                    <p className="col-span-1">
                                        {instancia.servidor.nombre}
                                    </p>

                                    <p className="col-span-1">
                                        {instancia.tipo_instancia.nombre}
                                    </p>

                                    <p
                                        className={`font-medium ${
                                            instancia.estado_instancia.id === 1
                                                ? 'text-red-500'
                                                : instancia.estado_instancia
                                                      .id === 2
                                                ? 'text-warning-500'
                                                : 'text-success-500'
                                        }`}
                                    >
                                        {instancia.estado_instancia.nombre}
                                    </p>
                                </div>
                            ))
                        ) : (
                            'Sin instancias'
                        )
                    ) : (
                        <>
                            <Shimmer width="100%" className="mr-12 mb-2" />
                            <Shimmer width="100%" className="mr-12 mb-2" />
                            <Shimmer width="100%" className="mr-12 mb-2" />
                        </>
                    )}
                </div>

                <Separator />

                {/* Documentos del Sistema */}
                <h2 className="font-semibold text-lg text-primary-500 mb-3">
                    Documentos del sistema
                </h2>

                {data ? (
                    data?.data?.sistema?.documentos.length > 0 ? (
                        data?.data?.sistema?.documentos.map((documento) => (
                            <div
                                className="flex"
                                key={'documento' + documento.id}
                            >
                                <Link
                                    href={documento.url}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="flex items-center"
                                >
                                    <Icon iconName="link" className="mr-2" />
                                    {documento.nombre}
                                </Link>
                            </div>
                        ))
                    ) : (
                        'Sin Documentos'
                    )
                ) : (
                    <>
                        <Shimmer width="100%" className="mr-12 mb-2" />
                        <Shimmer width="100%" className="mr-12 mb-2" />
                        <Shimmer width="100%" className="mr-12 mb-2" />
                    </>
                )}

                <Separator />

                {/* Lenguajes del Sistema */}
                <h2 className="font-semibold text-lg text-primary-500 mb-3">
                    Lenguajes del sistema
                </h2>

                {data ? (
                    data?.data?.sistema?.lenguajes.length > 0 ? (
                        data?.data?.sistema?.lenguajes.map((lenguaje) => (
                            <p key={'lenguaje' + lenguaje.id}>
                                {lenguaje.nombre}
                            </p>
                        ))
                    ) : (
                        'Sin lenguajes'
                    )
                ) : (
                    <>
                        <Shimmer width="100%" className="mr-12 mb-2" />
                        <Shimmer width="100%" className="mr-12 mb-2" />
                        <Shimmer width="100%" className="mr-12 mb-2" />
                    </>
                )}

                <Separator />

                {/* Servicios Web del Sistema */}
                <h2 className="font-semibold text-lg text-primary-500 mb-3">
                    Servicios web del sistema
                </h2>

                {data ? (
                    data?.data?.sistema?.servicios_web.length > 0 ? (
                        data?.data?.sistema?.servicios_web.map((web) => (
                            <p key={'web' + web.id}>{web.nombre}</p>
                        ))
                    ) : (
                        'Sin servicios web'
                    )
                ) : (
                    <>
                        <Shimmer width="100%" className="mr-12 mb-2" />
                        <Shimmer width="100%" className="mr-12 mb-2" />
                        <Shimmer width="100%" className="mr-12 mb-2" />
                    </>
                )}
            </div>
        </div>
    );
};

//Export
export default DetalleSistema;
