// Dependencias
import { useEffect, useState } from 'react';
import nookies from 'nookies';
import {
    Breadcrumb,
    PrimaryButton,
    DetailsList,
    ComboBox,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    DefaultButton,
    Spinner,
    SpinnerSize,
    Shimmer,
    SearchBox,
} from '@fluentui/react';
import Pagination from 'rc-pagination';
import {
    useIncidentes,
    createIncidente,
    editIncidente,
    deleteIncidente,
} from '../http/lib/incidente';
import { CargandoTabla } from '../servicios/cargandoTabla';
import dayjs from 'dayjs';
import localizedFormat from 'dayjs/plugin/localizedFormat';
import 'dayjs/locale/es';
import { useBoolean } from '@fluentui/react-hooks';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import SuccessToast from '../atoms/successToast';
import ErrorToast from '../atoms/errorToast';
import FormularioIncidentes from './FormularioIncidentes';
import DetalleIncidente from './DetalleIncidentes';
import { useEstadoIncidente } from '../http/lib/estadoIncidente';
import debounce from 'lodash/debounce';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoIncidentes = () => {
    // Estados
    dayjs.extend(localizedFormat);
    dayjs.locale('es');

    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);
    const [isLoading, setIsLoading] = useState(false);
    const [incidenteSeleccionado, setIncidenteSeleccionado] = useState();

    // Filtros
    const [query, setQuery] = useState('');
    const [estados, setEstado] = useState();

    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isDetailModalOpen,
        { setTrue: showDetailModal, setFalse: hideDetailModal },
    ] = useBoolean(false);
    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        {
            key: 'sistema',
            name: 'Incidente',
            fieldName: 'sistema',
            onRender: (item) => <p className="font-medium">{item.sistema}</p>,
        },

        {
            key: 'estado',
            name: 'Estado',
            fieldName: 'estado',
            minWidth: 180,
            onRender: (item) => (
                <p
                    className={`font-bold ${
                        item.estado === 1
                            ? 'text-danger-500'
                            : item.estado === 2
                            ? 'text-warning-500'
                            : item.estado === 3
                            ? 'text-success-500'
                            : ''
                    }`}
                >
                    {item.estado === 1 ? (
                        'Sin acciones'
                    ) : item.estado === 2 ? (
                        'En revisión'
                    ) : item.estado === 3 ? (
                        'Corregido'
                    ) : (
                        <Shimmer width="100%" />
                    )}
                </p>
            ),
        },

        { key: 'fecha', name: 'Fecha', fieldName: 'fecha', minWidth: 180 },

        { key: 'hora', name: 'Hora', fieldName: 'hora' },

        {
            key: 'acciones',
            name: 'Acciones',
            fieldName: 'acciones',
        },
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    //API
    const { data: dataIncidentes, mutate: mutateIncitendes } = useIncidentes(
        10,
        currentPage,
        query,
        estados,
        token
    );

    const { data: dataEstado } = useEstadoIncidente(
        10000,
        1,
        null,
        null,
        token
    );

    // Efectos
    useEffect(() => {
        setCurrentPage(1);
    }, [query, estados]);

    // Handlers
    const handleCreateIncidentes = async ({
        idSistema,
        idTipoProblema,
        detalleProblema,
    }) => {
        setIsLoading(true);
        try {
            const response = await createIncidente({
                idSistema,
                idTipoProblema,
                detalleProblema,
                token,
            });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateIncitendes();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'Incidente creado con éxito.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditIncidentes = async ({ ...values }) => {
        setIsLoading(true);
        try {
            const response = await editIncidente({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateIncitendes();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Incidente editado correctamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteIncidente = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteIncidente({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateIncitendes();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Incidente eliminado exitosamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-12 px-16">
            <Breadcrumb
                className="py-4"
                styles={{}}
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Incidentes',
                        href: '/incidentes',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-bold text-4xl">
                    Listado de incidentes
                </h1>

                <PrimaryButton
                    onClick={showCreateModal}
                    iconProps={{ iconName: 'Add' }}
                    text="Nuevo incidente"
                    className="px-12"
                />
            </div>

            {/* Filtros */}
            <div>
                <div className="grid grid-cols-5 gap-4 mb-4 items-end">
                    {/* Cuadro de busqueda (q) */}
                    <SearchBox
                        placeholder="Filtrar por nombre de sistema o estado"
                        className="col-span-4"
                        onChange={(q) => {
                            debouncedSetQuery(q?.target?.value ?? '');
                        }}
                        onClear={() => setQuery('')}
                    />

                    {/* Filtros por Estado_incidente */}
                    <div className="col-span-1">
                        <div className="flex justify-between mb-2">
                            <label className="font-medium">Estado</label>

                            {estados && (
                                <button
                                    className="appearance-none text-primary-500 font-medium"
                                    onClick={() => setEstado(null)}
                                >
                                    Limpiar
                                </button>
                            )}
                        </div>

                        <ComboBox
                            placeholder="Seleccionar"
                            options={dataEstado?.data?.estados_incidente?.map(
                                (r) => ({
                                    key: r.id,
                                    text: r.nombre,
                                })
                            )}
                            selectedKey={estados}
                            onChange={(_, r) => setEstado(r.key)}
                        />
                    </div>
                </div>
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataIncidentes?.data?.incidentes?.map((incidentes) => ({
                        key: incidentes?.id,
                        sistema: `Incidente #${incidentes?.id} - ${incidentes?.instancia_sistema?.sistema?.nombre}`,
                        estado: incidentes.estado_incidente.id,
                        fecha: dayjs(incidentes.fecha_hora_problema).format(
                            'LL'
                        ),
                        hora: dayjs(incidentes.fecha_hora_problema).format(
                            'LTS'
                        ),
                        acciones: (
                            <BotonUD
                                showDetail
                                showEdit={[1, 2].includes(
                                    user?.data?.usuario?.rol?.id
                                )}
                                showDelete={user?.data?.usuario?.rol?.id === 1}
                                onViewDetail={() => showDetailModal()}
                                onEdit={() => showEditModal()}
                                onDelete={() => showDeleteModal()}
                                setSelected={setIncidenteSeleccionado}
                                itemToSelect={incidentes}
                            />
                        ),
                    })) ?? arrayCargando
                }
            />

            {/* Paginación */}

            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataIncidentes?.data?.meta?.total}
                    pageSize={dataIncidentes?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            {/* Modal Detalle  */}
            <Modal
                isOpen={isDetailModalOpen}
                onDismiss={hideDetailModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isDetailModalOpen && (
                    <DetalleIncidente
                        incidente={incidenteSeleccionado}
                        onCloseModal={hideDetailModal}
                    />
                )}
            </Modal>

            {/* Modal Crear  */}
            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioIncidentes
                        tipo="crear"
                        onSubmit={handleCreateIncidentes}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            {/* Modal Editar  */}
            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioIncidentes
                        tipo="editar"
                        onSubmit={handleEditIncidentes}
                        isLoading={isLoading}
                        valoresIniciales={incidenteSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            {/* Modal Eliminar  */}
            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar incidente',
                    subText: `¿Estás de acuerdo con eliminar el incidente:  "${incidenteSeleccionado?.instancia_sistema?.sistema?.nombre} - #${incidenteSeleccionado?.instancia_sistema?.id}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteIncidente({
                                id: incidenteSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoIncidentes;
