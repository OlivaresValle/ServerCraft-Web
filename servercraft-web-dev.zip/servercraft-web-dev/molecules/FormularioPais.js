// Dependencias
import nookies from 'nookies';
import * as yup from 'yup';
import { PrimaryButton, Spinner, IconButton } from '@fluentui/react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import ControlledInput from '../atoms/controlledInput';

const paisSchema = yup
    .object({
        nombre: yup
            .string()
            .required('Campo obligatorio')
            .max(150, 'El campo debe tener menos de 150 caracteres'),
    })
    .required();

// Componente
const FormularioPais = ({
    valoresIniciales,
    tipo,
    onSubmit,
    isLoading,
    onCloseModal,
}) => {
    // Estados
    const { handleSubmit, control } = useForm({
        resolver: yupResolver(paisSchema),
        defaultValues: {
            ...valoresIniciales,
        },
    });

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            className="w-full shadow-2xl p-8 bg-gray-50"
        >
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-8">
                    {tipo === 'crear' ? 'Crear país' : 'Editar país'}
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                />
            </div>

            <ControlledInput
                control={control}
                name="nombre"
                label="Nombre del país"
            />

            <PrimaryButton type="submit" className="mt-8 w-full" loading>
                {isLoading && <Spinner className="mr-2" />}Guardar país
            </PrimaryButton>
        </form>
    );
};

// Exportación
export default FormularioPais;
