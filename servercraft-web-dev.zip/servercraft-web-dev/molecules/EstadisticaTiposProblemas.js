// Dependencias
import React from 'react';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { useTiposProblemas } from '../http/lib/estadistica';
import nookies from 'nookies';

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend
);

export const options = {
    responsive: true,
    plugins: {
        legend: {
            position: 'bottom',
        },
        title: {
            display: true,
            text: 'Tipos de problemas mensuales',
            font: {
                size: 20,
            },
            color: '#007FD2',
            padding: {
                bottom: 30,
            },
            align: 'start',
        },
    },
    scales: {
        y: {
            suggestedMax: 10,
        },
    },
};

const EstadisticaTiposProblemas = () => {
    //Estados
    const token = nookies.get()['auth-token'];
    const { data } = useTiposProblemas(token);

    const labels = data?.data?.data.map((tip) => tip.tipo_problema);

    const contador = {
        labels,
        datasets: [
            {
                label: 'Incidentes',
                data: data?.data?.data.map((con) => con.contador),
                backgroundColor: 'rgb(0,120,212,0.5)',
            },
        ],
    };

    return (
        <Bar className="bg-white px-6 pt-8" options={options} data={contador} />
    );
};

export default EstadisticaTiposProblemas;
