// Dependencias
import { useState } from 'react';
import Link from 'next/link';
import {
    PrimaryButton,
    Icon,
    DefaultButton,
    Link as FluentLink,
    Spinner,
} from '@fluentui/react';
import { recoverPassword } from '../http/lib/auth';

// Componente
const RecuperacionSuccess = ({ correo }) => {
    // Estados
    const [isLoading, setIsLoading] = useState(false);

    // Handler
    const onReenviarRecuperacion = async () => {
        setIsLoading(true);

        try {
            await recoverPassword({ email: correo });
        } catch (error) {}

        setIsLoading(false);
    };

    return (
        <div className="bg-transparent w-full">
            <h1 className="text-lg font-semibold text-primary-500 mb-2">
                Correo enviado correctamente
            </h1>

            <p className="font-medium mb-5">
                Si <span className="font-bold">{correo}</span> se encuentra en
                nuestra base de datos, recibirás un email con las instrucciones
                para recuperar tu contraseña.
            </p>

            <div className="hidden md:flex px-3 py-2 bg-warning-100 items-center border-l-2 border-warning-500 mb-5">
                <Icon
                    iconName="AlertSolid"
                    className="mr-4 text-xl text-warning-500 mb-2"
                />

                <p className="text-warning-500 font-medium">
                    Si no ves el correo en tu bandeja de entrada, por favor,
                    revisa la bandeja de spam.
                </p>
            </div>

            <div className="flex flex-col items-start">
                <p className="mt-4 font-medium">
                    ¿Aún no has recibido el correo de recuperación?
                </p>

                <PrimaryButton
                    className="mt-4 w-full"
                    onClick={() => onReenviarRecuperacion()}
                    loading
                >
                    {isLoading && <Spinner className="mr-2" />}
                    Reenviar correo
                </PrimaryButton>

                <Link href="/" passHref>
                    <FluentLink className="mt-4 w-full">
                        <DefaultButton className="w-full" loading>
                            Volver al inicio de sesión
                        </DefaultButton>
                    </FluentLink>
                </Link>
            </div>
        </div>
    );
};

// Export
export default RecuperacionSuccess;
