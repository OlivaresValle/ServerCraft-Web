// Dependencias
import nookies from 'nookies';
import * as yup from 'yup';
import {
    PrimaryButton,
    DefaultButton,
    Spinner,
    ChoiceGroup,
    IconButton,
} from '@fluentui/react';
import { Controller, useForm, useFieldArray } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useNivelesSensibilidad } from '../http/lib/nivelSensiblidad/nivelSensibilidad.calls';
import { useNivelesSeguridad } from '../http/lib/nivelSeguridad/nivelSeguridad.calls';
import ControlledInput from '../atoms/controlledInput';
import ControlledSelect from '../atoms/controlledSelect';
import { useUsuarios } from '../http/lib/usuario';
import { useEffect, useState } from 'react';
import { useSistema } from '../http/lib/sistema/sistema.calls';
import ModalSeleccionProveedor from './ModalSeleccionProveedor';
import ModalSeleccionServidor from './ModalSeleccionServidor';
import ModalSeleccionBD from './ModalSeleccionBD';
import ModalSeleccionLenguaje from './ModalSeleccionLenguaje';
import ModalSeleccionServicio from './ModalSeleccionServicio';
import ModalCrearDocumento from './ModalCrearDocumento';

const sistemaSchema = yup
    .object({
        nombre: yup.string().required('Campo obligatorio.'),
        equipoProveedor: yup
            .object({
                id: yup.number().required('Campo obligatorio.'),
            })
            .required('Campo obligatorio'),
        servidorBD: yup
            .object({
                id: yup.number().required('Campo obligatorio.'),
            })
            .required('Campo obligatorio'),

        instancias: yup.array(
            yup.object({
                tipo_instancia: yup.object({
                    id: yup.number().required('Campo obligatorio'),
                }),
                servidor: yup.object({
                    id: yup.number().required('Campo obligatorio.'),
                }),
            })
        ),

        lenguajes: yup
            .array(
                yup.object({
                    id: yup.number().required('Campo obligatorio'),
                })
            )
            .required('Campo obligatorio')
            .min(1, 'Debes seleccionar al menos 1 lenguaje de programación'),

        serviciosWeb: yup.array(
            yup.object({
                id: yup.number().required('Campo obligatorio'),
            })
        ),

        documentos: yup.array(
            yup.object({
                nombre: yup.string().required('Campo obligatorio'),
                url: yup
                    .string()
                    .required('Campo obligatorio')
                    .url('Debes ingresar una URL válida.'),
            })
        ),

        idNivelSeguridad: yup.number().required('Campo obligatorio.'),
        idNivelSensibilidad: yup.number().optional(),
        idUsuario: yup.number().required('Campo obligatorio.'),
    })
    .required();

const roles = [1, 2];

// Componente
const FormularioSistema = ({
    valoresIniciales,
    tipo,
    onSubmit,
    isLoading,
    onCloseModal,
}) => {
    // Estados
    const token = nookies.get()['auth-token'];
    const [isProveedoresOpen, setProveedoresOpen] = useState(false);
    const [isServidoresOpen, setServidoresOpen] = useState(false);
    const [isBDOpen, setIsBDOpen] = useState(false);
    const [isLenguajesOpen, setLenguajesOpen] = useState(false);
    const [isServiciosOpen, setServiciosOpen] = useState(false);
    const [isDocumentosOpen, setDocumentosOpen] = useState(false);
    const [valoresSeteados, setValoresSeteados] = useState(false);
    const {
        formState: { errors },
        handleSubmit,
        control,
        setValue,
    } = useForm({
        resolver: yupResolver(sistemaSchema),
    });
    const { fields, append, remove } = useFieldArray({
        control,
        name: 'instancias',
        keyName: 'key',
    });
    const {
        fields: lenguajesFields,
        append: appendLenguaje,
        remove: removeLenguaje,
    } = useFieldArray({
        control,
        name: 'lenguajes',
        keyName: 'key',
    });
    const {
        fields: serviciosFields,
        append: appendServicio,
        remove: removeServicio,
    } = useFieldArray({
        control,
        name: 'serviciosWeb',
        keyName: 'key',
    });
    const {
        fields: documentosFields,
        append: appendDocumento,
        remove: removeDocumento,
    } = useFieldArray({
        control,
        name: 'documentos',
        keyName: 'key',
    });

    const { data: dataSistema, mutate } = useSistema(
        valoresIniciales?.id,
        token
    );
    const { data: dataUsuarios } = useUsuarios(
        1000000000,
        1,
        null,
        roles,
        null,
        token
    );
    const { data: dataNivelesSensibilidad } = useNivelesSensibilidad(
        1000000000,
        1,
        null,
        token
    );
    const { data: dataNivelesSeguridad } = useNivelesSeguridad(
        1000000000,
        1,
        null,
        token
    );

    // Efecto
    useEffect(() => {
        if (!valoresSeteados && dataSistema && tipo === 'editar') {
            setValue('nombre', dataSistema?.data?.sistema?.nombre);
            setValue(
                'equipoProveedor',
                dataSistema?.data?.sistema?.equipo_proveedor
            );
            setValue(
                'instancias',
                dataSistema?.data?.sistema?.instancias ?? []
            );
            setValue('servidorBD', dataSistema?.data?.sistema?.servidor_db);
            setValue('lenguajes', dataSistema?.data?.sistema?.lenguajes ?? []);
            setValue('serviciosWeb', dataSistema?.data?.sistema?.servicios_web);
            setValue('documentos', dataSistema?.data?.sistema?.documentos);

            setValue(
                'idNivelSeguridad',
                dataSistema?.data?.sistema?.nivel_seguridad?.id
            );
            setValue(
                'idNivelSensibilidad',
                dataSistema?.data?.sistema?.nivel_sensibilidad?.id
            );
            setValue('idUsuario', dataSistema?.data?.sistema?.usuario?.id);
            setValoresSeteados(true);
        }
    }, [valoresIniciales, tipo, setValue, valoresSeteados, dataSistema]);

    return (
        <>
            <form
                className="w-full shadow-2xl p-8 bg-gray-50"
                onSubmit={handleSubmit((values) => onSubmit(values, mutate))}
            >
                <div className="flex justify-between align-center w-full">
                    <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                        {tipo === 'crear' ? 'Crear sistema' : 'Editar sistema'}
                    </h1>

                    <IconButton
                        iconProps={{ iconName: 'ChromeClose' }}
                        onClick={onCloseModal}
                    />
                </div>

                <div className="grid grid-cols-1 gap-4 md:gap-6 md:gap-x-12">
                    {/* Nombre sistema */}
                    <ControlledInput
                        control={control}
                        name="nombre"
                        label="Nombre del sistema"
                        placeholder="Ingrese el nombre del sistema"
                        className="col-span-1"
                        disabled={
                            !valoresSeteados &&
                            !dataSistema &&
                            tipo === 'editar'
                        }
                    />

                    {/* Proveedor del sistema */}
                    <div className="w-full flex flex-col">
                        <label className="font-medium mb-2">
                            Proveedor del sistema
                        </label>

                        <Controller
                            name="equipoProveedor"
                            control={control}
                            render={({
                                field: { value, onChange },
                                fieldState: { error },
                            }) => (
                                <>
                                    {value && (
                                        <div className="flex w-full justify-between items-center border border-gray-100 bg-white mb-4 shadow-md pr-4">
                                            <div className="w-full grid grid-cols-3 py-4 px-4">
                                                <p className="font-medium col-span-1">
                                                    {
                                                        value?.proveedor_sistema
                                                            ?.nombre
                                                    }
                                                </p>

                                                <p className="col-span-2">
                                                    <span className="font-medium">
                                                        {'Equipo encargado: '}
                                                    </span>
                                                    {value?.nombre}
                                                </p>
                                            </div>

                                            <IconButton
                                                iconProps={{
                                                    iconName: 'ChromeClose',
                                                    style: { color: 'red' },
                                                }}
                                                onClick={() =>
                                                    onChange(undefined)
                                                }
                                            />
                                        </div>
                                    )}

                                    <DefaultButton
                                        className="w-48"
                                        onClick={() => setProveedoresOpen(true)}
                                    >
                                        {value
                                            ? 'Cambiar proveedor'
                                            : 'Seleccionar proveedor'}
                                    </DefaultButton>

                                    {error?.id && (
                                        <p className="text-danger-500 text-xs mt-2">
                                            {error?.id?.message}
                                        </p>
                                    )}

                                    <ModalSeleccionProveedor
                                        isOpen={isProveedoresOpen}
                                        defaultValue={value}
                                        onSelectionConfirm={(value) => {
                                            onChange(value);
                                            setProveedoresOpen(false);
                                        }}
                                        onClose={() =>
                                            setProveedoresOpen(false)
                                        }
                                    />
                                </>
                            )}
                        />
                    </div>

                    {/* Instancias */}
                    <div className="w-full flex flex-col">
                        <label className="font-medium mb-2">
                            Asignar servidores
                        </label>

                        {fields?.map((instancia, index) => (
                            <div
                                key={instancia.key}
                                className="flex flex-col w-full"
                            >
                                <div className="flex w-full justify-between items-center border border-gray-100 bg-white mb-4 shadow-md pr-4">
                                    <div className="w-full grid grid-cols-4 py-4 px-4">
                                        <p className="font-medium col-span-1">
                                            {instancia?.servidor?.nombre}
                                        </p>

                                        <p className="col-span-1">
                                            <span className="font-medium">
                                                {'Tipo de servidor: '}
                                            </span>
                                            {
                                                instancia?.servidor
                                                    ?.tipo_servidor?.nombre
                                            }
                                        </p>

                                        <p className="col-span-1">
                                            <span className="font-medium">
                                                {'Disco: '}
                                            </span>
                                            {`${instancia?.servidor?.disco} GB`}
                                        </p>

                                        <p className="col-span-1">
                                            <span className="font-medium">
                                                {'Memoria: '}
                                            </span>
                                            {`${instancia?.servidor?.memoria} GB`}
                                        </p>
                                    </div>

                                    <IconButton
                                        iconProps={{
                                            iconName: 'ChromeClose',
                                            style: {
                                                color: 'red',
                                            },
                                        }}
                                        onClick={() => remove(instancia?.key)}
                                    />
                                </div>

                                <Controller
                                    control={control}
                                    name={`instancias.${index}.tipo_instancia.id`}
                                    render={({
                                        field: { value, onChange },
                                    }) => (
                                        <ChoiceGroup
                                            selectedKey={value}
                                            className="mb-8"
                                            styles={{
                                                flexContainer: {
                                                    display: 'flex',
                                                    flexDirection: 'row',
                                                    '& > div': {
                                                        marginTop: 0,
                                                        marginRight: '20px',
                                                    },
                                                },
                                            }}
                                            options={[
                                                {
                                                    key: 1,
                                                    text: 'Primario',
                                                },
                                                {
                                                    key: 2,
                                                    text: 'Contingencia',
                                                },
                                            ]}
                                            onChange={(e, o) =>
                                                onChange(o?.key)
                                            }
                                        />
                                    )}
                                />
                            </div>
                        ))}

                        <DefaultButton
                            className="w-48"
                            onClick={() => setServidoresOpen(true)}
                        >
                            Añadir servidor
                        </DefaultButton>

                        <ModalSeleccionServidor
                            isOpen={isServidoresOpen}
                            defaultValue={fields}
                            onSelectionConfirm={(selected) => {
                                append(selected);
                                setServidoresOpen(false);
                            }}
                            onClose={() => setServidoresOpen(false)}
                        />
                    </div>

                    {/* Servidores BD */}
                    <div className="w-full flex flex-col">
                        <label className="font-medium mb-2">
                            Asignar servidor de base de datos
                        </label>

                        <Controller
                            name="servidorBD"
                            control={control}
                            render={({
                                field: { value, onChange },
                                fieldState: { error },
                            }) => (
                                <>
                                    {value && (
                                        <div className="flex w-full justify-between items-center border border-gray-100 bg-white mb-4 shadow-md pr-4">
                                            <div className="w-full grid grid-cols-3 py-4 px-4">
                                                <p className="font-medium col-span-1">
                                                    {value?.base_datos?.nombre}
                                                </p>

                                                <p className="col-span-1">
                                                    <span className="font-medium">
                                                        {'Servidor: '}
                                                    </span>

                                                    {value?.nombre}
                                                </p>

                                                <p className="col-span-1">
                                                    <span className="font-medium">
                                                        {'Memoria: '}
                                                    </span>
                                                    {value?.memoria} GB
                                                </p>
                                            </div>

                                            <IconButton
                                                iconProps={{
                                                    iconName: 'ChromeClose',
                                                    style: { color: 'red' },
                                                }}
                                                onClick={() =>
                                                    onChange(undefined)
                                                }
                                            />
                                        </div>
                                    )}

                                    <DefaultButton
                                        className="w-56"
                                        onClick={() => setIsBDOpen(true)}
                                    >
                                        {value
                                            ? 'Editar base de datos'
                                            : 'Seleccionar base de datos'}
                                    </DefaultButton>

                                    {error?.id && (
                                        <p className="text-danger-500 text-xs mt-2">
                                            {error?.id?.message}
                                        </p>
                                    )}

                                    <ModalSeleccionBD
                                        isOpen={isBDOpen}
                                        defaultValue={value}
                                        onSelectionConfirm={(value) => {
                                            onChange(value);
                                            setIsBDOpen(false);
                                        }}
                                        onClose={() => setIsBDOpen(false)}
                                    />
                                </>
                            )}
                        />
                    </div>

                    {/* Lenguajes de Programación */}
                    <div className="w-full flex flex-col">
                        <label className="font-medium mb-2">
                            Lenguajes de programación
                        </label>

                        <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                            {lenguajesFields?.map((lenguaje) => (
                                <div
                                    key={lenguaje.key}
                                    className="flex flex-col w-full"
                                >
                                    <div className="flex w-full justify-between items-center border border-gray-100 bg-white mb-4 shadow-md pr-4">
                                        <div className="w-full  py-4 px-4">
                                            <p className="font-medium truncate">
                                                {lenguaje?.nombre}
                                            </p>
                                        </div>

                                        <IconButton
                                            iconProps={{
                                                iconName: 'ChromeClose',
                                                style: {
                                                    color: 'red',
                                                },
                                            }}
                                            onClick={() =>
                                                removeLenguaje(lenguaje?.key)
                                            }
                                        />
                                    </div>
                                </div>
                            ))}
                        </div>

                        <DefaultButton
                            className="w-64"
                            onClick={() => setLenguajesOpen(true)}
                        >
                            Añadir lenguaje de programación
                        </DefaultButton>

                        {errors?.lenguajes && (
                            <p className="text-danger-500 text-xs mt-2">
                                {errors?.lenguajes?.message}
                            </p>
                        )}

                        <ModalSeleccionLenguaje
                            isOpen={isLenguajesOpen}
                            defaultValue={lenguajesFields}
                            onSelectionConfirm={(selected) => {
                                appendLenguaje(selected);
                                setLenguajesOpen(false);
                            }}
                            onClose={() => setLenguajesOpen(false)}
                        />
                    </div>

                    {/* Servicios Web */}
                    <div className="w-full flex flex-col">
                        <label className="font-medium mb-2">
                            Servicios externos
                        </label>

                        <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                            {serviciosFields?.map((servicio) => (
                                <div
                                    key={servicio.key}
                                    className="flex flex-col w-full"
                                >
                                    <div className="flex w-full justify-between items-center border border-gray-100 bg-white mb-4 shadow-md pr-4">
                                        <div className="w-full  py-4 px-4">
                                            <p className="font-medium truncate">
                                                {servicio?.nombre}
                                            </p>
                                        </div>

                                        <IconButton
                                            iconProps={{
                                                iconName: 'ChromeClose',
                                                style: {
                                                    color: 'red',
                                                },
                                            }}
                                            onClick={() =>
                                                removeServicio(servicio?.key)
                                            }
                                        />
                                    </div>
                                </div>
                            ))}
                        </div>

                        <DefaultButton
                            className="w-40"
                            onClick={() => setServiciosOpen(true)}
                        >
                            Añadir servicio
                        </DefaultButton>

                        <ModalSeleccionServicio
                            isOpen={isServiciosOpen}
                            defaultValue={serviciosFields}
                            onSelectionConfirm={(selected) => {
                                appendServicio(selected);
                                setServiciosOpen(false);
                            }}
                            onClose={() => setServiciosOpen(false)}
                        />
                    </div>

                    {/* Responsable del sistema */}
                    <ControlledSelect
                        control={control}
                        name="idUsuario"
                        label="Responsable del sistema"
                        placeholder="Seleccione al usuario responsable del sistema"
                        className="col-span-1"
                        disabled={
                            !valoresSeteados &&
                            !dataSistema &&
                            tipo === 'editar'
                        }
                        options={
                            dataUsuarios?.data?.usuarios?.map((usuario) => ({
                                key: usuario.id,
                                text: `${usuario.nombre} ${usuario.apellidos} - ${usuario.rol.nombre}`,
                            })) ?? []
                        }
                    />

                    {/* Nivel de seguridad */}
                    <ControlledSelect
                        control={control}
                        name="idNivelSeguridad"
                        label="Nivel de seguridad del sistema"
                        placeholder="Seleccionar nivel de seguridad del sistema"
                        className="col-span-1"
                        disabled={
                            !valoresSeteados &&
                            !dataSistema &&
                            tipo === 'editar'
                        }
                        options={
                            dataNivelesSeguridad?.data?.niveles_seguridad?.map(
                                (nivelSeguridad) => ({
                                    key: nivelSeguridad?.id,
                                    text: nivelSeguridad?.nombre,
                                })
                            ) ?? []
                        }
                    />

                    {/* Nivel de sensibilidad */}
                    <ControlledSelect
                        control={control}
                        name="idNivelSensibilidad"
                        label="Nivel de sensibilidad del sistema"
                        placeholder="Seleccionar nivel de sensibilidad del sistema"
                        className="col-span-1"
                        disabled={
                            !valoresSeteados &&
                            !dataSistema &&
                            tipo === 'editar'
                        }
                        options={
                            dataNivelesSensibilidad?.data?.niveles_sensibilidad?.map(
                                (nivelSensibilidad) => ({
                                    key: nivelSensibilidad?.id,
                                    text: nivelSensibilidad?.nombre,
                                })
                            ) ?? []
                        }
                    />

                    {/* Documentos */}
                    <div className="w-full flex flex-col">
                        <label className="font-medium mb-2">
                            Documentación
                        </label>

                        {documentosFields?.map((documento) => (
                            <div
                                key={documento.key}
                                className="flex flex-col w-full"
                            >
                                <div className="flex w-full justify-between items-center border border-gray-100 bg-white mb-4 shadow-md pr-4">
                                    <div className="w-full grid grid-cols-3  py-4 px-4">
                                        <p className="font-medium truncate col-span-1">
                                            {documento?.nombre}
                                        </p>

                                        <a
                                            href={documento?.url}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="truncate col-span-2 text-blue-500 underline"
                                        >
                                            {documento?.url}
                                        </a>
                                    </div>

                                    <IconButton
                                        iconProps={{
                                            iconName: 'ChromeClose',
                                            style: {
                                                color: 'red',
                                            },
                                        }}
                                        onClick={() =>
                                            removeDocumento(documento?.key)
                                        }
                                    />
                                </div>
                            </div>
                        ))}

                        <DefaultButton
                            className="w-44"
                            onClick={() => setDocumentosOpen(true)}
                        >
                            Añadir documento
                        </DefaultButton>

                        <ModalCrearDocumento
                            isOpen={isDocumentosOpen}
                            defaultValue={documentosFields}
                            onSelectionConfirm={(selected) => {
                                appendDocumento(selected);
                                setDocumentosOpen(false);
                            }}
                            onClose={() => setDocumentosOpen(false)}
                        />
                    </div>

                    <PrimaryButton type="submit" className="mt-4">
                        {isLoading && <Spinner className="mr-2" />}Guardar
                        sistema
                    </PrimaryButton>
                </div>
            </form>
        </>
    );
};

// Exportación
export default FormularioSistema;
