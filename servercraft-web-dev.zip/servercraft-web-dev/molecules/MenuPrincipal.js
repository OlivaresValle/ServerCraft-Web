// Dependencias
import BotonMenu from '../atoms/BotonMenu';
import Image from 'next/image';

const menuIzquierda = [
    {
        shape: 'rectangle',
        icon: '/Iconos/Server_Icon.png',
        text: 'Sala, rack y servidores',
        secondaryText:
            'Listar, crear, editar o eliminar salas, rack y servidores.',
        detallado: true,
        href: '/servidores',
    },

    {
        shape: 'square',
        icon: '/Iconos/Users_Icon.png',
        text: 'Usuarios y equipos',
        href: '/usuarios',
    },
    {
        shape: 'square',
        icon: '/Iconos/Programming_Icon.png',
        text: 'Lenguajes de programación',
        href: '/lenguajes',
    },
    {
        shape: 'square',
        icon: '/Iconos/Database_Icon.png',
        text: 'Motores de bases de datos',
        href: '/motores-bd',
    },
    {
        shape: 'square',
        icon: '/Iconos/Services_Icon.png',
        text: 'Servicios Web auxiliares',
        href: '/servicios',
    },
    {
        shape: 'square',
        icon: '/Iconos/Customer_Icon.png',
        text: 'Clientes o Proveedores',
        href: '/proveedores',
    },
    {
        shape: 'square',
        icon: '/Iconos/Location_Icon.png',
        text: 'Ubicaciones',
        href: '/ubicaciones/paises',
    },
    {
        shape: 'rectangle',
        icon: '/Iconos/System_Icon.png',
        text: 'Sistemas o aplicaciones',
        secondaryText: 'Listar, crear, editar o eliminar sistemas.',
        detallado: true,
        href: '/sistemas',
    },
];

const menuDerecha = [
    {
        shape: 'rectangle',
        icon: '/Iconos/Statistics_Icon.png',
        text: 'Estadísticas',
        secondaryText:
            'Visualizar estadísticas de la plataforma, su uso y los eventos que en ella ocurren.',
        detallado: true,
        href: '/estadisticas',
    },
    {
        shape: 'rectangle',
        icon: '/Iconos/Issues_Icon.png',
        text: 'Incidentes',
        secondaryText:
            'Gestionar incidentes, problemas, de los sistemas administrados.',
        detallado: true,
        href: '/incidentes',
    },
    {
        shape: 'rectangle',
        icon: '/Iconos/Activity_Icon.png',
        text: 'Registro de actividad',
        secondaryText:
            'Revisar auditoría de actividad de los usuarios que utilizan el sistema.',
        detallado: true,
        href: '/actividad',
    },
];

// Componente
const MenuPrincipal = () => {
    // Estados

    return (
        <div className="container py-8 mx-auto px-4">
            <h1 className="text-primary-500 font-semibold text-4xl mb-6">
                Menú Principal
            </h1>

            <div className="flex items-start">
                <div className="grid grid-cols-4 gap-4 mr-8 w-7/12">
                    {menuIzquierda.map((menu) => (
                        <div
                            key={menu?.href}
                            className={
                                menu.shape === 'rectangle'
                                    ? 'col-span-3'
                                    : 'col-span-1'
                            }
                        >
                            <BotonMenu
                                icon={
                                    <Image
                                        src={menu?.icon}
                                        alt="icono"
                                        width={130}
                                        height={110}
                                        className="flex-grow object-contain"
                                    />
                                }
                                text={menu.text}
                                secondaryText={menu.secondaryText}
                                detallado={menu.detallado}
                                href={menu.href}
                            />
                        </div>
                    ))}
                </div>

                <div className="grid grid-cols-3 gap-4 ml-8 w-5/12">
                    {menuDerecha.map((menu) => (
                        <div
                            key={menu?.href}
                            className={
                                menu.shape === 'rectangle'
                                    ? 'col-span-3'
                                    : 'col-span-1'
                            }
                        >
                            <BotonMenu
                                icon={
                                    <Image
                                        src={menu?.icon}
                                        alt="icono"
                                        width={130}
                                        height={110}
                                        className="flex-grow object-contain"
                                    />
                                }
                                text={menu.text}
                                secondaryText={menu.secondaryText}
                                detallado={menu.detallado}
                                href={menu.href}
                            />
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

// Exportación
export default MenuPrincipal;
