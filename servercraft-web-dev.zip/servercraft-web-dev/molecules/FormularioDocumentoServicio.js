// Dependencias
import nookies from 'nookies';
import * as yup from 'yup';
import { PrimaryButton, Spinner, IconButton } from '@fluentui/react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import ControlledInput from '../atoms/controlledInput';
import { useServiciosWeb } from '../http/lib/servicioWeb/servicioWeb.calls';
import ControlledSelect from '../atoms/controlledSelect';

const documentoSchema = () =>
    yup
        .object({
            nombre: yup
                .string()
                .required('Campo obligatorio')
                .max(150, 'El campo debe tener menos de 150 caracteres'),
            url: yup
                .string()
                .url('Ingrese una URL válida')
                .required('Campo obligatorio')
                .max(255, 'El campo debe tener menos de 255 caracteres'),
            idServicioWeb: yup.number().required('Campo obligatorio'),
        })
        .required();

// Componente
const FormularioDocumentoServicio = ({
    valoresIniciales,
    tipo,
    onSubmit,
    isLoading,
    onCloseModal,
}) => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: dataServicios } = useServiciosWeb(
        10000000000000,
        1,
        null,
        token
    );

    const { handleSubmit, control, errors } = useForm({
        resolver: yupResolver(documentoSchema()),
        defaultValues: {
            ...valoresIniciales,
            idServicioWeb: valoresIniciales?.servicio_web?.id,
        },
    });

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            className="w-full shadow-2xl p-8 bg-gray-50"
        >
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                    {tipo === 'crear' ? 'Crear documento' : 'Editar documento'}
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                ></IconButton>
            </div>

            <div className="grid grid-cols-1 gap-4 md:gap-6 md:gap-x-12">
                <ControlledInput
                    control={control}
                    name="nombre"
                    label="Nombre"
                    placeholder=""
                    className="col-span-1"
                />
                <ControlledInput
                    control={control}
                    name="url"
                    label="Url"
                    placeholder=""
                    className="col-span-1"
                />

                <ControlledSelect
                    control={control}
                    name="idServicioWeb"
                    label="Servicio web"
                    placeholder="Seleccionar servicio web"
                    className="col-span-1"
                    options={
                        dataServicios?.data?.servicios?.map((servicio) => ({
                            key: servicio.id,
                            text: servicio.nombre,
                        })) ?? []
                    }
                />
            </div>

            <PrimaryButton type="submit" className="mt-8 w-full" loading>
                {isLoading && <Spinner className="mr-2" />}Guardar documento
            </PrimaryButton>
        </form>
    );
};

// Exportación
export default FormularioDocumentoServicio;
