// Dependencias
import { useState } from 'react';
import * as yup from 'yup';
import { PrimaryButton, Spinner } from '@fluentui/react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useRouter } from 'next/dist/client/router';
import { createNewPassword } from '../http/lib/auth/auth.calls';
import ControlledInput from '../atoms/controlledInput';
import ContrasenaExito from './NuevaContrasenaExitosa';

const newPassSchema = yup
    .object({
        password: yup
            .string()
            .required('Campo obligatorio')
            .min(6, 'La contraseña debe tener al menos 6 caracteres'),

        confirmPassword: yup
            .string()
            .required('Campo obligatorio')
            .oneOf(
                [yup.ref('password'), null],
                'La nueva contraseña y su confirmación no coinciden'
            ),
    })
    .required();

// Componente
const FormularioLogin = () => {
    // Estados
    const router = useRouter();
    const [isLoading, setIsLoading] = useState(false);
    const [step, setStep] = useState(1);

    const { control, handleSubmit } = useForm({
        resolver: yupResolver(newPassSchema),
    });

    // Handlers
    const onSubmit = async (values) => {
        setIsLoading(true);
        try {
            await createNewPassword({
                contrasenaNueva: values.password,
                confirmarNuevaContrasena: values.confirmPassword,
                token: router.query.t,
            });

            setStep(2);
        } catch (e) {}
        setIsLoading(false);
    };

    if (step === 2) {
        return <ContrasenaExito></ContrasenaExito>;
    }
    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            className="w-full shadow-2xl p-8 grid grid-cols-1 gap-6 bg-gray-50 relative"
        >
            <h1 className="text-primary-500 font-semibold text-4xl mb-6">
                Crear Nueva Contraseña
            </h1>

            <ControlledInput
                control={control}
                name="password"
                label="Nueva Contraseña"
                type="password"
                canRevealPassword
            />

            <ControlledInput
                control={control}
                name="confirmPassword"
                label="Confirmar Contraseña"
                type="password"
                canRevealPassword
            />

            <PrimaryButton type="submit" className="mt-4" loading>
                {isLoading && <Spinner className="mr-2" />}Crear Nueva
                Contraseña
            </PrimaryButton>
        </form>
    );
};

// Exportación
export default FormularioLogin;
