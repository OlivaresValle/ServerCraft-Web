// Dependencias
import { useState } from 'react';
import { setCookie } from 'nookies';
import * as yup from 'yup';
import {
    Link as FluentLink,
    PrimaryButton,
    MessageBar,
    MessageBarType,
    Spinner,
} from '@fluentui/react';
import { useBoolean } from '@fluentui/react-hooks';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useRouter } from 'next/dist/client/router';
import { login } from '../http/lib/auth/auth.calls';
import ControlledInput from '../atoms/controlledInput';
import Link from 'next/link';

const loginSchema = yup
    .object({
        email: yup
            .string()
            .email('Ingresa un email válido')
            .required('Campo obligatorio'),
        password: yup.string().required('Campo obligatorio'),
    })
    .required();

// Componente
const FormularioLogin = () => {
    // Estados
    const router = useRouter();
    const [isLoading, setIsLoading] = useState(false);
    const [loginError, { toggle: toggleLoginError }] = useBoolean(false);

    const { control, handleSubmit } = useForm({
        resolver: yupResolver(loginSchema),
    });

    // Handlers
    const onSubmit = async (values) => {
        setIsLoading(true);
        try {
            const response = await login(values);

            setCookie(null, 'auth-token', response.data.token.token, {
                maxAge: 30 * 24 * 60 * 60,
                path: '/',
            });

            if (response.status) {
                router.push('/menu');
            }
        } catch (e) {
            setIsLoading(false);
            toggleLoginError();
        }
    };

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            className="w-full shadow-2xl p-8 grid grid-cols-1 gap-6 bg-gray-50 relative"
        >
            <h1 className="text-primary-500 font-semibold text-4xl mb-6">
                Iniciar Sesión
            </h1>

            <ControlledInput
                control={control}
                name="email"
                label="Correo electrónico"
                placeholder="correo@correo.cl"
            />

            <ControlledInput
                control={control}
                name="password"
                label="Contraseña"
                type="password"
                canRevealPassword
            />

            <PrimaryButton type="submit" className="mt-4" loading>
                {isLoading && <Spinner className="mr-2" />}Iniciar Sesión
            </PrimaryButton>

            {loginError && (
                <MessageBar
                    messageBarType={MessageBarType.error}
                    isMultiline={false}
                    onDismiss={toggleLoginError}
                    dismissButtonAriaLabel="Close"
                >
                    <p className="font-semibold mb-2">
                        Error al iniciar sesión
                    </p>

                    <p>
                        El email y/o la clave no coinciden con ningún registro,
                        intenta con algo distinto.
                    </p>
                </MessageBar>
            )}

            <Link href="/recuperar" passHref>
                <FluentLink className="w-full text-center">
                    ¿Olvidaste tu contraseña?
                </FluentLink>
            </Link>
        </form>
    );
};

// Exportación
export default FormularioLogin;
