// Dependencias
import nookies, { destroyCookie } from 'nookies';
import {
    Stack,
    Persona,
    CommandBar,
    ContextualMenuItemType,
    Link,
} from '@fluentui/react';
import { useUsuario } from '../http/lib/usuario';
import { useRouter } from 'next/dist/client/router';

// Componente
const MenuUsuario = () => {
    // Estados
    const router = useRouter();
    const token = nookies.get()['auth-token'];

    const { data: dataUsuario } = useUsuario(0, token);

    const cerrarSesion = () => {
        destroyCookie(null, 'auth-token');
        router.push('/');
    };

    return (
        <Stack horizontal>
            <CommandBar
                name="A"
                styles={{
                    primarySet: {
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                    },
                    root: {
                        paddingLeft: '0px',
                        paddingRight: '0px',
                    },
                }}
                items={[
                    {
                        key: 'asd',
                        text: (
                            <Link
                                href="/perfil"
                                className="hover:no-underline focus:no-underline"
                            >
                                <Persona
                                    size={40}
                                    text={dataUsuario?.data?.usuario?.nombre}
                                    secondaryText={
                                        dataUsuario?.data?.usuario?.rol?.nombre
                                    }
                                    imageUrl={
                                        dataUsuario?.data?.usuario?.imagen?.url
                                    }
                                    imageAlt={
                                        dataUsuario?.data?.usuario?.nombre
                                    }
                                    styles={{
                                        primaryText: { fontWeight: '600' },
                                    }}
                                />
                            </Link>
                        ),
                        split: true,
                        subMenuProps: {
                            items: [
                                {
                                    key: 'asd',
                                    name: 'Perfil',
                                    onClick: () => router.push('/perfil'),
                                },
                                {
                                    key: 'divider',
                                    name: '-',
                                    itemType: ContextualMenuItemType.Divider,
                                },
                                {
                                    key: 'asd',
                                    name: 'Cerrar Sesión',
                                    onClick: () => cerrarSesion(),
                                },
                            ],
                        },
                    },
                ]}
            />
        </Stack>
    );
};

// Exportación
export default MenuUsuario;
