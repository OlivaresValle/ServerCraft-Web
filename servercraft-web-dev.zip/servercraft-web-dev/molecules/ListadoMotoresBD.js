// Dependencias
import {
    DetailsList,
    Breadcrumb,
    PrimaryButton,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    DefaultButton,
    Spinner,
    SpinnerSize,
    SearchBox,
} from '@fluentui/react';
import Pagination from 'rc-pagination';
import nookies from 'nookies';
import { useEffect, useState } from 'react';
import {
    useMotoresDBList,
    createMotorDB,
    editMotorDB,
    deleteMotorDB,
} from '../http/lib/motorDB';
import { CargandoTabla } from '../servicios/cargandoTabla';
import { useBoolean } from '@fluentui/react-hooks';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import SuccessToast from '../atoms/successToast';
import ErrorToast from '../atoms/errorToast';
import FormularioMotorDB from '../molecules/FormularioMotorDB';
import debounce from 'lodash/debounce';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoMotoresBD = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);
    const [isLoading, setIsLoading] = useState(false);
    const [motorSeleccionado, setMotorSeleccionado] = useState();

    // Filtros
    const [query, setQuery] = useState('');

    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        {
            key: 'nombre',
            name: 'Nombre',
            fieldName: 'nombre',
            onRender: (item) => (
                <p className="font-bold d-inline-block">{item.nombre}</p>
            ),
        },
        {
            key: 'servidores',
            name: 'Cantidad de servidores',
            fieldName: 'servidores',
            minWidth: 200,
        },
        ...([1, 2].includes(user?.data?.usuario?.rol?.id)
            ? [
                  {
                      key: 'acciones',
                      name: 'Acciones',
                      fieldName: 'acciones',
                  },
              ]
            : []),
    ];

    const arrayCargando = CargandoTabla(columnas, 4);

    // API
    const { data: dataMotoresDB, mutate: mutateMotoresDB } = useMotoresDBList(
        10,
        currentPage,
        query,
        token
    );

    // Efectos
    useEffect(() => {
        setCurrentPage(1);
    }, [query]);

    // Handlers
    const handleCreateMotorBD = async (values) => {
        setIsLoading(true);
        try {
            const response = await createMotorDB({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateMotoresDB();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Motor de base de datos creado con éxito.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditMotorBD = async ({ ...values }) => {
        setIsLoading(true);
        try {
            const response = await editMotorDB({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateMotoresDB();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Motor de base de datos editado correctamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteMotorBD = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteMotorDB({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateMotoresDB();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Motor de base de datos eliminado exitosamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-12 px-16">
            <Breadcrumb
                className="py-4"
                styles={{}}
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Motores de base de datos',
                        href: '/motores-bd',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-semibold text-4xl">
                    Listado de motores de bases de datos
                </h1>

                <PrimaryButton
                    onClick={showCreateModal}
                    iconProps={{ iconName: 'Add' }}
                    text="Nuevo motor de base de datos"
                    className="px-12"
                />
            </div>

            {/* Filtros */}
            <div>
                <div className="flex justify-between flex-wrap gap-4 mb-4">
                    {/* Cuadro de busqueda (q) */}
                    <SearchBox
                        placeholder="Filtrar por nombre de base de datos"
                        className="w-full"
                        onChange={(q) => {
                            debouncedSetQuery(q?.target?.value ?? '');
                        }}
                        onClear={() => setQuery('')}
                    />
                </div>
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataMotoresDB?.data?.bases_de_datos?.map((motorDB) => ({
                        key: motorDB.id,
                        nombre: motorDB.nombre,
                        servidores: motorDB.meta.servidores_count,
                        acciones: (
                            <BotonUD
                                showEdit
                                showDelete={user?.data?.usuario?.rol?.id === 1}
                                onEdit={() => showEditModal()}
                                onDelete={() => showDeleteModal()}
                                setSelected={setMotorSeleccionado}
                                itemToSelect={motorDB}
                            />
                        ),
                    })) ?? arrayCargando
                }
            />

            {/* Paginación */}

            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataMotoresDB?.data?.meta?.total}
                    pageSize={dataMotoresDB?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioMotorDB
                        tipo="crear"
                        onSubmit={handleCreateMotorBD}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioMotorDB
                        tipo="editar"
                        onSubmit={handleEditMotorBD}
                        isLoading={isLoading}
                        valoresIniciales={motorSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar motor de base de datos',
                    subText: `¿Estás de acuerdo con eliminar el motor de bases de datos: "${motorSeleccionado?.nombre}" ?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteMotorBD({
                                id: motorSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoMotoresBD;
