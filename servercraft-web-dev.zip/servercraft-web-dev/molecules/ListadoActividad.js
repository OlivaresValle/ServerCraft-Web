// Dependencias
import {
    Breadcrumb,
    DetailsList,
    SelectionMode,
    SearchBox,
} from '@fluentui/react';
import { useActividad } from '../http/lib/actividadAuditoria';
import nookies from 'nookies';
import { CargandoTabla } from '../servicios/cargandoTabla';
import { useEffect, useState } from 'react';
import dayjs from 'dayjs';
import debounce from 'lodash/debounce';
import Pagination from 'rc-pagination';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoActividad = () => {
    // Estados
    const token = nookies.get()['auth-token'];

    // Filtro
    const [query, setQuery] = useState('');
    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    // API
    const { data } = useActividad(10, currentPage, query, token);

    const columnas = [
        { key: 'fecha', name: 'Fecha', fieldName: 'fecha', maxWidth: 100 },
        { key: 'hora', name: 'Hora', fieldName: 'hora', maxWidth: 100 },
        { key: 'detalle', name: 'Detalle', fieldName: 'detalle' },
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    // Efectos
    useEffect(() => {
        setCurrentPage(1);
    }, [query]);

    return (
        <div className="flex flex-col pt-12 px-16 pb-20">
            <Breadcrumb
                className="py-4"
                items={[
                    { text: 'Menú principal', href: '/menu' },

                    {
                        text: 'Registro de actividad',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-semibold text-4xl">
                    Registro de actividad
                </h1>
            </div>

            {/* Filtro */}
            <div className="flex justify-between flex-wrap gap-4 mb-4">
                {/* Cuadro de busqueda (q) */}
                <SearchBox
                    placeholder="Filtrar por descripción ..."
                    className="w-full"
                    onChange={(q) => {
                        debouncedSetQuery(q?.target?.value ?? '');
                    }}
                    onClear={() => setQuery('')}
                />
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    data?.data?.eventos?.map((evento) => ({
                        key: evento?.id,
                        fecha: dayjs(evento?.fecha_hora).format('DD/MM/YYYY'),
                        hora: dayjs(evento?.fecha_hora).format('HH:mm:ss'),
                        detalle: evento?.detalle_actividad,
                    })) ?? arrayCargando
                }
            />

            {/* Paginación */}
            <div className="flex justify-center mt-4">
                <Pagination
                    total={data?.data?.meta?.total}
                    pageSize={data?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>
        </div>
    );
};

// Export
export default ListadoActividad;
