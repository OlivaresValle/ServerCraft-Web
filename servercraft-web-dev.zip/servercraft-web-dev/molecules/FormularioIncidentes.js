// Dependencias
import nookies from 'nookies';
import * as yup from 'yup';
import { PrimaryButton, Spinner, IconButton } from '@fluentui/react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import ControlledInput from '../atoms/controlledInput';
import ControlledSelect from '../atoms/controlledSelect';
import { useTiposProblema } from '../http/lib/tipoProblema/tipoProblema.calls';
import { useTipoSoluciones } from '../http/lib/tipoSolucion/tipoSolucion.calls';
import { useEffect, useState } from 'react';
import { useIncidente } from '../http/lib/incidente';
import { useInstancia } from '../http/lib/instancia/instancia.calls';
import { useEquiposTrabajos } from '../http/lib/equipoTrabajo/equipoTrabajo.calls';

const incidenteSchema = (tipo) =>
    yup
        .object({
            idSistema: yup.number().required('Campo obligatorio.'),
            idTipoProblema: yup.number().required('Campo obligatorio.'),
            detalleProblema: yup.string().required('Campo obligatorio'),
            detalleSolucion: tipo === 'editar' && yup.string().nullable(),
            idTipoSolucion: tipo === 'editar' && yup.number(),
            idEquipoSolucion: tipo === 'editar' && yup.number(),
            idEstadoIncidente:
                tipo === 'editar' && yup.number().required('Campo obligatorio'),
        })
        .required();

// Componente
const FormularioIncidentes = ({
    valoresIniciales,
    tipo,
    onSubmit,
    isLoading,
    onCloseModal,
}) => {
    // Estados
    const token = nookies.get()['auth-token'];
    const [valoresSeteados, setValoresSeteados] = useState(false);

    const { data: dataIncidente } = useIncidente(valoresIniciales?.id, token);

    const { data: dataInstancias } = useInstancia(10000000000, 1, null, token);

    const { data: dataTiposProblema } = useTiposProblema(
        10000000000,
        1,
        null,
        token
    );

    const { data: dataTiposSoluciones } = useTipoSoluciones(
        10000000000,
        1,
        null,
        token
    );

    const { data: dataEquiposEncargados } = useEquiposTrabajos(
        10000000000,
        1,
        null,
        token
    );

    const { handleSubmit, control, setValue } = useForm({
        resolver: yupResolver(incidenteSchema(tipo)),
        defaultValues: {
            ...valoresIniciales,
        },
    });

    // Efecto
    useEffect(() => {
        if (!valoresSeteados && dataIncidente && tipo === 'editar') {
            setValue(
                'idSistema',
                dataIncidente?.data?.incidente?.instancia_sistema?.id
            );
            setValue(
                'idTipoProblema',
                dataIncidente?.data?.incidente?.tipo_problema?.id
            );
            setValue(
                'detalleProblema',
                dataIncidente?.data?.incidente?.detalle_problema
            );
            setValue(
                'detalleSolucion',
                dataIncidente?.data?.incidente?.detalle_solucion
            );
            setValue(
                'idTipoSolucion',
                dataIncidente?.data?.incidente?.tipo_solucion?.id
            );
            setValue(
                'idEquipoSolucion',
                dataIncidente?.data?.incidente?.equipo_trabajo?.id
            );
            setValue(
                'idEstadoIncidente',
                dataIncidente?.data?.incidente?.estado_incidente?.id
            );
            setValoresSeteados(true);
        }
    }, [valoresIniciales, dataIncidente, valoresSeteados, tipo, setValue]);

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            className="w-full shadow-2xl p-8 bg-gray-50"
        >
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                    {tipo === 'crear' ? 'Crear incidente' : 'Editar incidente'}
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                />
            </div>

            <div className="grid grid-cols-1 gap-4 md:gap-6 md:gap-x-12">
                <ControlledSelect
                    control={control}
                    name="idSistema"
                    label="Sistema afectado"
                    placeholder="Seleccionar Sistema afectado"
                    className="col-span-1"
                    disabled={!dataIncidente && tipo === 'editar'}
                    options={
                        dataInstancias?.data?.instancias?.map((instancia) => ({
                            key: instancia?.id,
                            text: `${instancia?.sistema?.nombre} - Instancia ${instancia?.tipo_instancia?.nombre}`,
                        })) ?? []
                    }
                />

                {tipo === 'editar' && (
                    <ControlledSelect
                        control={control}
                        name="idEstadoIncidente"
                        label="Estado del incidente"
                        placeholder="Seleccionar Estado del Incidente"
                        className="col-span-1"
                        disabled={!dataIncidente && tipo === 'editar'}
                        options={[
                            {
                                key: 1,
                                text: 'Sin acciones',
                            },
                            {
                                key: 2,
                                text: 'En revisión',
                            },
                            {
                                key: 3,
                                text: 'Corregido',
                            },
                        ]}
                    />
                )}

                <ControlledSelect
                    control={control}
                    name="idTipoProblema"
                    label="Tipo de problema"
                    placeholder="Seleccionar Tipo de Problema"
                    className="col-span-1"
                    disabled={!dataIncidente && tipo === 'editar'}
                    options={
                        dataTiposProblema?.data?.tipos_problema?.map(
                            (tipoProblema) => ({
                                key: tipoProblema?.id,
                                text: tipoProblema?.nombre,
                            })
                        ) ?? []
                    }
                />

                <ControlledInput
                    control={control}
                    name="detalleProblema"
                    label="Detalle problema"
                    className="col-span-1"
                    placeholder="Describe el problema detectado"
                    disabled={!dataIncidente && tipo === 'editar'}
                    multiline
                    autoAdjustHeight
                />

                {tipo === 'editar' && (
                    <ControlledSelect
                        control={control}
                        name="idTipoSolucion"
                        label="Tipo de solución"
                        placeholder="Seleccionar Tipo de Solución"
                        className="col-span-1"
                        disabled={!dataIncidente && tipo === 'editar'}
                        options={
                            dataTiposSoluciones?.data?.tipos_solucion?.map(
                                (tipoSolucion) => ({
                                    key: tipoSolucion?.id,
                                    text: tipoSolucion?.nombre,
                                })
                            ) ?? []
                        }
                    />
                )}

                {tipo === 'editar' && (
                    <ControlledSelect
                        control={control}
                        name="idEquipoSolucion"
                        label="Equipo encargado"
                        placeholder="Seleccionar Equipo encargado de la solución"
                        className="col-span-1"
                        disabled={!dataIncidente && tipo === 'editar'}
                        options={
                            dataEquiposEncargados?.data?.equipos_trabajo?.map(
                                (equipoEncargado) => ({
                                    key: equipoEncargado?.id,
                                    text: equipoEncargado?.nombre,
                                })
                            ) ?? []
                        }
                    />
                )}

                {tipo === 'editar' && (
                    <ControlledInput
                        control={control}
                        name="detalleSolucion"
                        label="Detalle solución"
                        placeholder="Describe la solución aplicada"
                        className="col-span-1"
                        disabled={!dataIncidente && tipo === 'editar'}
                        multiline
                        autoAdjustHeight
                    />
                )}
            </div>

            <PrimaryButton type="submit" className="mt-8 w-full" loading>
                {isLoading && <Spinner className="mr-2" />}Guardar incidente
            </PrimaryButton>
        </form>
    );
};

// Exportación
export default FormularioIncidentes;
