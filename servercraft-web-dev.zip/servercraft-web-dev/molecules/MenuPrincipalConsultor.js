// Dependencias
import BotonMenu from '../atoms/BotonMenu';
import Image from 'next/image';

const menus = [
    {
        shape: 'rectangle',
        icon: '/Iconos/Server_Icon.png',
        text: 'Sala, rack y servidores',
        secondaryText:
            'Listar, crear, editar o eliminar salas, rack y servidores.',
        detallado: true,
        href: '/servidores',
    },

    {
        shape: 'square',
        icon: '/Iconos/Users_Icon.png',
        text: 'Equipos y Unidades',
        href: '/equipo-trabajo',
    },
    {
        shape: 'square',
        icon: '/Iconos/Programming_Icon.png',
        text: 'Lenguajes de programación',
        href: '/lenguajes',
    },
    {
        shape: 'square',
        icon: '/Iconos/Services_Icon.png',
        text: 'Servicios Web auxiliares',
        href: '/servicios',
    },
    {
        shape: 'square',
        icon: '/Iconos/Customer_Icon.png',
        text: 'Clientes o Proveedores',
        href: '/proveedores',
    },
    {
        shape: 'square',
        icon: '/Iconos/Issues_Icon.png',
        text: 'Incidentes',
        href: '/incidentes',
    },
    {
        shape: 'rectangle',
        icon: '/Iconos/System_Icon.png',
        text: 'Sistemas o aplicaciones',
        secondaryText: 'Listar, crear, editar o eliminar sistemas.',
        detallado: true,
        href: '/sistemas',
    },
];

// Componente
const MenuPrincipalConsultor = () => {
    return (
        <div className="container py-8 mx-auto px-4">
            <h1 className="text-primary-500 font-semibold text-4xl mb-6">
                Menú Principal
            </h1>

            <div className="flex items-start">
                <div className="grid grid-cols-4 gap-4 mr-8 w-7/12">
                    {menus.map((menu) => (
                        <div
                            key={menu?.href}
                            className={
                                menu.shape === 'rectangle'
                                    ? 'col-span-3'
                                    : 'col-span-1'
                            }
                        >
                            <BotonMenu
                                icon={
                                    <Image
                                        src={menu?.icon}
                                        alt="icono"
                                        width={130}
                                        height={110}
                                        className="flex-grow object-contain"
                                    />
                                }
                                text={menu.text}
                                secondaryText={menu.secondaryText}
                                detallado={menu.detallado}
                                href={menu.href}
                            />
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

// Exportación
export default MenuPrincipalConsultor;
