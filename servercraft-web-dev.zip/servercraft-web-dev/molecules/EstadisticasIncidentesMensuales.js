// Dependencias
import React from 'react';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { useIncidentesActivos } from '../http/lib/estadistica';
import nookies from 'nookies';

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend
);

export const options = {
    responsive: true,
    plugins: {
        legend: {
            position: 'bottom',
        },
        title: {
            display: true,
            text: 'Incidentes activos mensuales',
            font: {
                size: 20,
            },
            color: '#007FD2',
            padding: {
                bottom: 30,
            },
            align: 'start',
        },
    },
    scales: {
        y: {
            suggestedMax: 15,
        },
    },
};

const labels = [
    'Enero',
    'Febrero',
    'Marzo',
    'Abril',
    'Mayo',
    'Junio',
    'Julio',
    'Agosto',
    'Septiembre',
    'Octubre',
    'Noviembre',
    'Diciembre',
];

const EstadisitcasIncidentesMensuales = () => {
    //Estados
    const token = nookies.get()['auth-token'];
    const { data } = useIncidentesActivos(token);

    const contador = {
        labels,
        datasets: [
            {
                label: 'Incidentes',
                data: data?.data?.data.map((con) => con.contador),
                backgroundColor: 'rgb(0,120,212,0.5)',
            },
        ],
    };

    return (
        <Bar className="bg-white px-6 pt-8" options={options} data={contador} />
    );
};

export default EstadisitcasIncidentesMensuales;
