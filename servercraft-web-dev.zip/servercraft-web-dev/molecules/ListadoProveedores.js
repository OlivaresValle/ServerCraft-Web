// Dependencias
import { useEffect, useState } from 'react';
import {
    Breadcrumb,
    PrimaryButton,
    DetailsList,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    DefaultButton,
    Spinner,
    SpinnerSize,
    SearchBox,
} from '@fluentui/react';
import { useBoolean } from '@fluentui/react-hooks';
import nookies from 'nookies';
import {
    createProveedorSistema,
    useProveedoresSistema,
    editProveedorSistema,
    deleteProveedorSistema,
} from '../http/lib/proveedorSistema';
import { CargandoTabla } from '../servicios/cargandoTabla';
import FormularioProveedorCliente from './FormularioProveedores';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import SuccessToast from '../atoms/successToast';
import ErrorToast from '../atoms/errorToast';
import DetalleProveedor from './DetalleProveedores';
import debounce from 'lodash/debounce';
import Pagination from 'rc-pagination';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoProveedores = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);

    const [isLoading, setIsLoading] = useState(false);
    const [proveedorSeleccionado, setProveedorSeleccionado] =
        useState(undefined);

    // Filtro
    const [query, setQuery] = useState('');
    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isDetailModalOpen,
        { setTrue: showDetailModal, setFalse: hideDetailModal },
    ] = useBoolean(false);

    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        { key: 'nombre', name: 'Nombre', fieldName: 'nombre' },
        {
            key: 'representante',
            name: 'Representante',
            fieldName: 'representante',
            minWidth: 180,
        },
        { key: 'email', name: 'Email', fieldName: 'email', minWidth: 180 },
        { key: 'telefono', name: 'Teléfono', fieldName: 'telefono' },
        {
            key: 'acciones',
            name: 'Acciones',
            fieldName: 'acciones',
        },
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    const { data: dataProveedores, mutate: mutateProveedor } =
        useProveedoresSistema(10, currentPage, query, token);

    // Efectos
    useEffect(() => {
        setCurrentPage(1);
    }, [query]);

    // Handlers
    const handleCreateProveedor = async (values) => {
        setIsLoading(true);
        try {
            const response = await createProveedorSistema({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateProveedor();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'Proveedor creado con éxito.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditProveedor = async ({ ...values }) => {
        setIsLoading(true);
        try {
            const response = await editProveedorSistema({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateProveedor();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Proveedor editado correctamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteCliente = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteProveedorSistema({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateProveedor();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Proveedor eliminado exitosamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-6 px-16">
            <Breadcrumb
                className="py-4"
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Clientes o proveedores',
                        key: 'proveedores',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-semibold text-4xl">
                    Listado de proveedores
                </h1>

                {user?.data?.usuario?.rol?.id === 1 && (
                    <PrimaryButton
                        iconProps={{ iconName: 'Add' }}
                        text="Nuevo proveedor"
                        className="px-12"
                        onClick={showCreateModal}
                        key={user?.data?.usuario?.rol?.id}
                    />
                )}
            </div>

            {/* Filtro */}

            <div className="flex justify-between flex-wrap gap-4 mb-4">
                {/* Cuadro de busqueda (q) */}
                <SearchBox
                    placeholder="Filtrar por nombre, telefono, email, representante..."
                    className="w-full"
                    onChange={(q) => {
                        debouncedSetQuery(q?.target?.value ?? '');
                    }}
                    onClear={() => setQuery('')}
                />
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataProveedores?.data?.proveedores?.map((proveedor) => ({
                        key: proveedor.id,
                        nombre: proveedor.nombre,
                        representante: proveedor.nombre_representante,
                        email: proveedor.email_contacto,

                        telefono: proveedor.telefono_contacto,
                        acciones: (
                            <BotonUD
                                showDetail={user?.data?.usuario?.rol?.id !== 4}
                                showEdit={user?.data?.usuario?.rol?.id === 1}
                                showDelete={user?.data?.usuario?.rol?.id === 1}
                                onViewDetail={() => showDetailModal()}
                                onEdit={() => showEditModal()}
                                onDelete={() => showDeleteModal()}
                                setSelected={setProveedorSeleccionado}
                                itemToSelect={proveedor}
                            />
                        ),
                    })) ?? arrayCargando
                }
            />

            {/* Paginación */}
            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataProveedores?.data?.meta?.total}
                    pageSize={dataProveedores?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            <Modal
                isOpen={isDetailModalOpen}
                onDismiss={hideDetailModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isDetailModalOpen && (
                    <DetalleProveedor
                        proveedor={proveedorSeleccionado}
                        onCloseModal={hideDetailModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioProveedorCliente
                        tipo="crear"
                        onSubmit={handleCreateProveedor}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioProveedorCliente
                        tipo="editar"
                        onSubmit={handleEditProveedor}
                        isLoading={isLoading}
                        valoresIniciales={proveedorSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar proveedor',
                    subText: `¿Estás de acuerdo con eliminar el proveedor: "${proveedorSeleccionado?.nombre}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteCliente({
                                id: proveedorSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoProveedores;
