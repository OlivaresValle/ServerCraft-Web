// Dependencias
import nookies from 'nookies';
import * as yup from 'yup';
import { PrimaryButton, Spinner, IconButton } from '@fluentui/react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import ControlledInput from '../atoms/controlledInput';

const lenguajeSchema = () =>
    yup
        .object({
            nombre: yup
                .string()
                .required('Campo obligatorio')
                .max(150, 'El campo debe tener menos de 150 caracteres'),
        })
        .required();

// Componente
const FormularioLenguaje = ({
    valoresIniciales,
    tipo,
    onSubmit,
    isLoading,
    onCloseModal,
}) => {
    // Estados
    const token = nookies.get()['auth-token'];

    const { handleSubmit, control, errors } = useForm({
        resolver: yupResolver(lenguajeSchema()),
        defaultValues: {
            ...valoresIniciales,
        },
    });

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            className="w-full shadow-2xl p-8 bg-gray-50"
        >
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                    {tipo === 'crear'
                        ? 'Crear lenguaje de programación'
                        : 'Editar lenguaje de programación'}
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                ></IconButton>
            </div>

            <div className="grid grid-cols-1  gap-4 md:gap-6 md:gap-x-12 mt-4">
                <ControlledInput
                    control={control}
                    name="nombre"
                    label="Nombre"
                    placeholder=""
                    className="col-span-1"
                />
            </div>

            <PrimaryButton type="submit" className="mt-8 w-full" loading>
                {isLoading && <Spinner className="mr-2" />}Guardar lenguaje de
                programación
            </PrimaryButton>
        </form>
    );
};

// Exportación
export default FormularioLenguaje;
