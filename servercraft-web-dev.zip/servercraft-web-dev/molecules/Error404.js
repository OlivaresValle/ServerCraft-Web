// Dependencias
import Link from 'next/link';
import { PrimaryButton } from '@fluentui/react';

// Componente
const Error404 = () => {
    // Estados
    return (
        <div className="w-full h-full p-6 bg-white">
            <h1 className="text-primary-500 font-semibold text-4xl mb-6">
                Error 404
            </h1>

            <p className="mb-8">
                La página a la cual intentaste entrar no fue encontrada.
            </p>

            <Link href="/" passHref>
                <PrimaryButton text="Volver al login" className="px-8" />
            </Link>
        </div>
    );
};

// Exportación
export default Error404;
