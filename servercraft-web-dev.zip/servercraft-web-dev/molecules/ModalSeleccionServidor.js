// Dependencias
import { useState } from 'react';
import nookies from 'nookies';
import { PrimaryButton, IconButton, Modal, ChoiceGroup } from '@fluentui/react';
import { useServidores } from '../http/lib/servidor';
import { differenceBy } from 'lodash';

const tiposDeServidores = [1, 3];

// Componente
const ModalSeleccionServidor = ({
    isOpen,
    onClose,
    defaultValue,
    onSelectionConfirm,
}) => {
    // Estados
    const token = nookies.get()['auth-token'];
    const [selectedServidor, setSelectedServidor] = useState();
    const [showError, setShowError] = useState(false);
    const { data: dataServidores } = useServidores(
        100000000,
        1,
        null,
        token,
        null,
        null,
        null,
        null,
        null,
        tiposDeServidores
    );

    const servidores = differenceBy(
        dataServidores?.data?.servidores,
        defaultValue?.map((i) => i.servidor),
        'id'
    );

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            isBlocking
            allowTouchBodyScroll
            styles={{
                scrollableContent: { overflow: 'visible' },
                root: { width: '100%' },
                main: { width: '100%', maxWidth: '1024px !important' },
            }}
            containerClassName="container"
            className="w-full h-full py-4 px-4 md:px-6"
        >
            <div className="w-full h-full shadow-2xl p-8 bg-gray-50">
                <div className="flex justify-between align-center w-full">
                    <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                        Seleccionar servidor
                    </h1>

                    <IconButton
                        iconProps={{ iconName: 'ChromeClose' }}
                        onClick={onClose}
                    />
                </div>

                <div className="w-full h-full overflow-y-auto">
                    <ChoiceGroup
                        selectedKey={selectedServidor?.id ?? defaultValue}
                        onChange={(_, o) => {
                            setSelectedServidor(
                                servidores.find((e) => e.id === o.key)
                            );
                            setShowError(false);
                        }}
                        options={servidores.map((s) => ({
                            key: s?.id,
                            text: `${s.nombre} - ${s.tipo_servidor.nombre}`,
                        }))}
                    />
                </div>

                {showError && (
                    <p className="font-medium text-danger-400 mt-12">
                        Debes seleccionar al menos 1 servidor.
                    </p>
                )}

                <PrimaryButton
                    className="mt-6"
                    onClick={() =>
                        !selectedServidor
                            ? setShowError(true)
                            : onSelectionConfirm({
                                  servidor: selectedServidor,
                                  tipo_instancia: { id: 1 },
                              })
                    }
                >
                    Confirmar selección
                </PrimaryButton>
            </div>
        </Modal>
    );
};

// Export
export default ModalSeleccionServidor;
