// Dependencias
import {
    Breadcrumb,
    SelectionMode,
    PrimaryButton,
    DetailsList,
    Modal,
    Dialog,
    DialogFooter,
    Spinner,
    SpinnerSize,
    DefaultButton,
    Icon,
    SearchBox,
    ComboBox,
} from '@fluentui/react';
import { useBoolean } from '@fluentui/react-hooks';
import nookies from 'nookies';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import ErrorToast from '../atoms/errorToast';
import SuccessToast from '../atoms/successToast';
import { CargandoTabla } from '../servicios/cargandoTabla';
import { useState } from 'react';
import { useRacks, createRack, editRack, deleteRack } from '../http/lib/rack';
import FormularioRack from './FormularioRack';
import { useRegiones } from '../http/lib/region';
import { usePaises } from '../http/lib/pais';
import { useSalas } from '../http/lib/sala';
import debounce from 'lodash/debounce';
import Pagination from 'rc-pagination';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoRacks = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);
    const [isLoading, setIsLoading] = useState(false);
    const [rackSeleccionado, setRackSeleccionado] = useState(undefined);

    // Filtros
    const [showFilters, setShowFilters] = useState(false);
    const [query, setQuery] = useState('');
    const [sala, setSala] = useState();
    const [region, setRegion] = useState();
    const [pais, setPais] = useState();
    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        {
            key: 'nombre',
            name: 'Nombre',
            fieldName: 'nombre',
            minWidth: 300,
            maxWidth: 400,
            onRender: (item) => <p className="font-medium">{item.nombre}</p>,
        },
        {
            key: 'descripcion',
            name: 'Descripción',
            fieldName: 'descripcion',
            minWidth: 200,
            maxWidth: 300,
        },
        {
            key: 'sala',
            name: 'Sala',
            fieldName: 'sala',
            minWidth: 120,
            maxWidth: 150,
        },
        {
            key: 'region',
            name: 'Región',
            fieldName: 'region',
        },
        {
            key: 'pais',
            name: 'País',
            fieldName: 'pais',
        },
        ...(user?.data?.usuario?.rol?.id === 1
            ? [
                  {
                      key: 'acciones',
                      name: 'Acciones',
                      fieldName: 'acciones',
                  },
              ]
            : []),
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    const { data: dataRacks, mutate: mutateRacks } = useRacks(
        10,
        currentPage,
        query,
        token,
        sala,
        region,
        pais
    );
    const { data: dataSalas } = useSalas(10000000, 1, null, token);
    const { data: dataRegiones } = useRegiones(null, 10000000, 1, null, token);
    const { data: dataPaises } = usePaises(10000000, 1, null, token);

    // Handlers
    const handleCreateRack = async (values) => {
        setIsLoading(true);
        try {
            const response = await createRack({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateRacks();
                toast.custom((t) => (
                    <SuccessToast t={t} text="Rack creado con éxito." />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text="Ha ocurrido un error inesperado." />
            ));
        }
    };

    const handleEditRack = async (values) => {
        setIsLoading(true);
        try {
            const response = await editRack({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateRacks();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'Rack editado correctamente.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteRack = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteRack({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateRacks();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'Rack eliminado exitosamente.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-12 px-16">
            <Breadcrumb
                className="py-4"
                styles={{}}
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Salas, racks y servidores',
                        href: '/racks',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-bold text-4xl">
                    Listado de racks
                </h1>

                {user?.data?.usuario?.rol?.id === 1 && (
                    <PrimaryButton
                        iconProps={{ iconName: 'Add' }}
                        text="Nuevo rack"
                        className="px-12"
                        onClick={showCreateModal}
                    />
                )}
            </div>

            <div>
                <DefaultButton
                    className="border-none bg-transparent px-4 py-2 text-primary-500 font-semibold text-base mb-4 hover:text-primary-500"
                    onClick={() => setShowFilters((s) => !s)}
                >
                    <div className="flex">
                        <span className="mr-2">
                            {showFilters ? 'Ocultar' : 'Mostrar'} Filtros
                        </span>

                        <Icon
                            iconName={
                                showFilters
                                    ? 'ChevronUpSmall'
                                    : 'ChevronDownSmall'
                            }
                        />
                    </div>
                </DefaultButton>

                {showFilters && (
                    <div className="flex justify-between flex-wrap gap-y-4 mb-4">
                        {/* Cuadro de busqueda (q) */}
                        <SearchBox
                            placeholder="Filtrar por nombre, sala, región, país..."
                            className="w-full"
                            onChange={(q) => {
                                debouncedSetQuery(q?.target?.value ?? '');
                            }}
                            onClear={() => setQuery('')}
                        />

                        <div className="grid grid-cols-3 w-full gap-x-4">
                            {/* Filtros por Sala */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="font-medium">Sala</label>

                                    {sala && (
                                        <button
                                            className="appearance-none text-primary-500 font-medium"
                                            onClick={() => setSala(null)}
                                        >
                                            Limpiar
                                        </button>
                                    )}
                                </div>

                                <ComboBox
                                    placeholder="Seleccionar"
                                    options={dataSalas?.data?.salas?.map(
                                        (sala) => ({
                                            key: sala.id,
                                            text: sala.nombre,
                                        })
                                    )}
                                    selectedKey={sala}
                                    onChange={(_, sala) => setSala(sala.key)}
                                />
                            </div>

                            {/* Filtros por Region */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="font-medium">
                                        Región
                                    </label>

                                    {region && (
                                        <button
                                            className="appearance-none text-primary-500 font-medium"
                                            onClick={() => setRegion(null)}
                                        >
                                            Limpiar
                                        </button>
                                    )}
                                </div>

                                <ComboBox
                                    placeholder="Seleccionar"
                                    options={dataRegiones?.data?.regiones?.map(
                                        (region) => ({
                                            key: region.id,
                                            text: region.nombre,
                                        })
                                    )}
                                    selectedKey={region}
                                    onChange={(_, region) =>
                                        setRegion(region.key)
                                    }
                                    className="w-full"
                                />
                            </div>

                            {/* Filtros por Pais */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="font-medium">País</label>

                                    {pais && (
                                        <button
                                            className="appearance-none text-primary-500 font-medium"
                                            onClick={() => setPais(null)}
                                        >
                                            Limpiar
                                        </button>
                                    )}
                                </div>

                                <ComboBox
                                    placeholder="Seleccionar"
                                    options={dataPaises?.data?.paises?.map(
                                        (pais) => ({
                                            key: pais.id,
                                            text: pais.nombre,
                                        })
                                    )}
                                    selectedKey={pais}
                                    onChange={(_, pais) => setPais(pais.key)}
                                />
                            </div>
                        </div>
                    </div>
                )}
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataRacks?.data?.racks?.map((rack) => ({
                        key: rack.id,
                        nombre: rack.nombre,
                        descripcion: rack.descripcion,
                        sala: rack.sala.nombre,
                        region: rack.sala.region.nombre,
                        pais: rack.sala.region.pais.nombre,
                        acciones: (
                            <BotonUD
                                showEdit
                                showDelete
                                onEdit={() => showEditModal()}
                                onDelete={() => showDeleteModal()}
                                setSelected={setRackSeleccionado}
                                itemToSelect={rack}
                            />
                        ),
                    })) ?? arrayCargando
                }
            />

            {/* Paginación */}
            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataRacks?.data?.meta?.total}
                    pageSize={dataRacks?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioRack
                        tipo="crear"
                        onSubmit={handleCreateRack}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioRack
                        tipo="editar"
                        onSubmit={handleEditRack}
                        isLoading={isLoading}
                        valoresIniciales={rackSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar rack',
                    subText: `¿Estás de acuerdo con eliminar el rack: "${rackSeleccionado?.nombre}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteRack({
                                id: rackSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoRacks;
