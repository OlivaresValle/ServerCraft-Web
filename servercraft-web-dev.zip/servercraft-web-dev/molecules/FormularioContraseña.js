// Dependencias
import { useState } from 'react';
import * as yup from 'yup';
import nookies from 'nookies';
import { PrimaryButton, Spinner } from '@fluentui/react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { updateContraseñaUsuario } from '../http/lib/usuario/usuario.calls';
import ControlledInput from '../atoms/controlledInput';
import toast from 'react-hot-toast';
import SuccessToast from '../atoms/successToast';
import ErrorToast from '../atoms/errorToast';

const loginSchema = yup
    .object({
        contrasenaActual: yup.string().required('Campo obligatorio'),
        contrasenaNueva: yup.string().required('Campo obligatorio'),
        confirmarContrasena: yup
            .string()
            .required('Campo obligatorio')
            .oneOf(
                [yup.ref('contrasenaNueva'), null],
                'La nueva contraseña y su confirmación no coinciden'
            ),
    })
    .required();

// Componente
const FormularioContraseña = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const [isLoading, setIsLoading] = useState(false);
    const { control, handleSubmit, reset } = useForm({
        defaultValues: {
            contrasenaActual: '',
            contrasenaNueva: '',
            confirmarContrasena: '',
        },
        resolver: yupResolver(loginSchema),
    });

    // Handlers
    const onSubmit = async ({ ...values }) => {
        setIsLoading(true);
        try {
            const response = await updateContraseñaUsuario({
                token,
                ...values,
            });

            if (response.status) {
                setIsLoading(false);
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text="Contraseña actualizado correctamente."
                    />
                ));
            }

            reset();
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text="Ha ocurrido un error inesperado." />
            ));
        }
    };

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            className="w-full shadow-2xl p-8 grid grid-cols-1 gap-6 bg-gray-50 relative"
        >
            <ControlledInput
                name="contrasenaActual"
                control={control}
                label="Contraseña actual"
                type="password"
                canRevealPassword
            />

            <ControlledInput
                name="contrasenaNueva"
                control={control}
                label="Nueva contraseña"
                type="password"
                canRevealPassword
            />

            <ControlledInput
                name="confirmarContrasena"
                control={control}
                label="Confirmar nueva contraseña"
                type="password"
                canRevealPassword
            />

            <div>
                <PrimaryButton
                    type="submit"
                    className="mt-4"
                    disabled={isLoading}
                >
                    {isLoading && <Spinner className="mr-2" />}Cambiar
                    contraseña
                </PrimaryButton>
            </div>
        </form>
    );
};

// Exportación
export default FormularioContraseña;
