// Dependencias
import { useEffect, useState } from 'react';
import {
    Breadcrumb,
    PrimaryButton,
    DetailsList,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    DefaultButton,
    Spinner,
    SpinnerSize,
    SearchBox,
} from '@fluentui/react';
import Pagination from 'rc-pagination';
import { useBoolean } from '@fluentui/react-hooks';
import nookies from 'nookies';
import {
    useLenguajes,
    createLenguaje,
    editLenguaje,
    deleteLenguaje,
} from '../http/lib/lenguajeProgramacion';
import { CargandoTabla } from '../servicios/cargandoTabla';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import SuccessToast from '../atoms/successToast';
import ErrorToast from '../atoms/errorToast';
import FormularioLenguaje from './FormularioLenguaje';
import debounce from 'lodash/debounce';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoLenguajes = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);
    const [isLoading, setIsLoading] = useState(false);
    const [lenguajeSeleccionado, setLenguajeSeleccionado] = useState(undefined);

    // Filtros
    const [query, setQuery] = useState('');

    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);
    const columnas = [
        {
            key: 'nombre',
            name: 'Nombre',
            fieldName: 'nombre',
            onRender: (item) => (
                <p className="font-bold d-inline-block">{item.nombre}</p>
            ),
        },
        {
            key: 'sistemas',
            name: 'Cantidad de sistemas',
            fieldName: 'sistemas',
            minWidth: 200,
        },
        ...([1, 2].includes(user?.data?.usuario?.rol?.id)
            ? [
                  {
                      key: 'acciones',
                      name: 'Acciones',
                      fieldName: 'acciones',
                  },
              ]
            : []),
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    // API
    const { data: dataLenguajes, mutate: mutateLenguajes } = useLenguajes(
        10,
        currentPage,
        query,
        token
    );

    // Efectos
    useEffect(() => {
        setCurrentPage(1);
    }, [query]);

    // Handlers
    const handleCreateLenguaje = async (values) => {
        setIsLoading(true);
        try {
            const response = await createLenguaje({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateLenguajes();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Lenguaje de programación creado con éxito.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditLenguaje = async ({ ...values }) => {
        setIsLoading(true);
        try {
            const response = await editLenguaje({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateLenguajes();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Lenguaje de programación editado correctamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteLenguaje = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteLenguaje({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateLenguajes();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Lenguaje eliminado exitosamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-12 px-16">
            <Breadcrumb
                className="py-4"
                styles={{}}
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Lenguajes de programación',
                        href: '/lenguajes',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-semibold text-4xl">
                    Listado de lenguajes de programación
                </h1>

                {[1, 2].includes(user?.data?.usuario?.rol?.id) && (
                    <PrimaryButton
                        iconProps={{ iconName: 'Add' }}
                        text="Nuevo lenguaje"
                        className="px-12"
                        onClick={showCreateModal}
                    />
                )}
            </div>

            {/* Filtros */}
            <div>
                <div className="flex justify-between flex-wrap gap-4 mb-4">
                    {/* Cuadro de busqueda (q) */}
                    <SearchBox
                        placeholder="Filtrar por nombre del lenguaje"
                        className="w-full"
                        onChange={(q) => {
                            debouncedSetQuery(q?.target?.value ?? '');
                        }}
                        onClear={() => setQuery('')}
                    />
                </div>
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataLenguajes?.data?.lenguajes_programacion?.map(
                        (lenguaje_programacion) => ({
                            key: lenguaje_programacion.id,
                            nombre: lenguaje_programacion.nombre,
                            sistemas:
                                lenguaje_programacion?.meta?.sistemas_count,
                            acciones: (
                                <BotonUD
                                    showEdit={[1, 2].includes(
                                        user?.data.usuario.rol.id
                                    )}
                                    showDelete={
                                        user?.data?.usuario?.rol?.id === 1
                                    }
                                    onEdit={() => showEditModal()}
                                    onDelete={() => showDeleteModal()}
                                    setSelected={setLenguajeSeleccionado}
                                    itemToSelect={lenguaje_programacion}
                                />
                            ),
                        })
                    ) ?? arrayCargando
                }
            />

            {/* Paginación */}

            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataLenguajes?.data?.meta?.total}
                    pageSize={dataLenguajes?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioLenguaje
                        tipo="crear"
                        onSubmit={handleCreateLenguaje}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioLenguaje
                        tipo="editar"
                        onSubmit={handleEditLenguaje}
                        isLoading={isLoading}
                        valoresIniciales={lenguajeSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar lenguaje',
                    subText: `¿Estás de acuerdo con eliminar el lenguaje: "${lenguajeSeleccionado?.nombre}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteLenguaje({
                                id: lenguajeSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoLenguajes;
