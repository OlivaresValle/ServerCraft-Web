// Dependencias
import {
    Breadcrumb,
    ComboBox,
    PrimaryButton,
    DetailsList,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    Spinner,
    SpinnerSize,
    DefaultButton,
    SearchBox,
    Icon,
} from '@fluentui/react';
import Pagination from 'rc-pagination';
import { useBoolean } from '@fluentui/react-hooks';
import nookies from 'nookies';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import ErrorToast from '../atoms/errorToast';
import SuccessToast from '../atoms/successToast';
import { useEffect, useState } from 'react';
import {
    useServidores,
    createServidor,
    editServidor,
    deleteServidor,
} from '../http/lib/servidor';
import { useTiposServidores } from '../http/lib/tipoServidor';
import { useMotoresDBList } from '../http/lib/motorDB';
import { useRegiones } from '../http/lib/region';
import { usePaises } from '../http/lib/pais';
import { CargandoTabla } from '../servicios/cargandoTabla';
import FormularioServidor from './FormularioServidor';
import DetalleServidor from './DetalleServidor';
import debounce from 'lodash/debounce';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoServidores = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);
    const [isLoading, setIsLoading] = useState(false);
    const [servidorSeleccionado, setServidorSeleccionado] = useState(undefined);

    // Filtros
    const [showFilters, setShowFilters] = useState(false);
    const [query, setQuery] = useState('');
    const [tipoServidor, setTipoServidor] = useState();
    const [baseDatos, setBaseDatos] = useState();
    const [region, setRegion] = useState();
    const [pais, setPais] = useState();

    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isDetailModalOpen,
        { setTrue: showDetailModal, setFalse: hideDetailModal },
    ] = useBoolean(false);
    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        {
            key: 'nombre',
            name: 'Nombre',
            fieldName: 'nombre',
            onRender: (item) => <p className="font-medium">{item.nombre}</p>,
        },
        {
            key: 'tipo',
            name: 'Tipo',
            fieldName: 'tipo',
            onRender: (item) => <p className="font-medium">{item.tipo}</p>,
        },
        {
            key: 'so',
            name: 'Sistema operativo',
            fieldName: 'so',
            minWidth: 140,
        },
        {
            key: 'rack',
            name: 'Rack',
            fieldName: 'rack',
        },
        {
            key: 'sala',
            name: 'Sala',
            fieldName: 'sala',
        },
        {
            key: 'acciones',
            name: 'Acciones',
            fieldName: 'acciones',
        },
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    // API
    const { data: dataServidores, mutate: mutateServidores } = useServidores(
        10,
        currentPage,
        query,
        token,
        pais,
        region,
        null,
        null,
        baseDatos,
        tipoServidor
    );

    const { data: dataTiposServidores } = useTiposServidores(
        10000,
        1,
        null,
        token
    );

    const { data: dataBD } = useMotoresDBList(10000000, 1, null, token);
    const { data: dataRegiones } = useRegiones(null, 10000000, 1, null, token);
    const { data: dataPaises } = usePaises(10000000, 1, null, token);

    // Efectos
    useEffect(() => {
        setCurrentPage(1);
    }, [query, tipoServidor, baseDatos, region, pais]);

    // Handlers
    const handleCreateServidor = async ({ ...values }) => {
        setIsLoading(true);
        try {
            const response = await createServidor({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateServidores();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'Servidor creado con éxito.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);

            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditServidor = async (values) => {
        setIsLoading(true);
        try {
            const response = await editServidor({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateServidores();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Servidor editado correctamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteServidor = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteServidor({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateServidores();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Servidor eliminado exitosamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-12 px-16">
            <Breadcrumb
                className="py-4"
                styles={{}}
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Salas, racks y servidores',
                        href: '/servidores',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-bold text-4xl">
                    Listado de servidores
                </h1>

                {user?.data?.usuario?.rol?.id === 1 && (
                    <PrimaryButton
                        iconProps={{ iconName: 'Add' }}
                        text="Nuevo servidor"
                        className="px-12"
                        onClick={showCreateModal}
                    />
                )}
            </div>

            {/* Filtros */}
            <div>
                <DefaultButton
                    className="border-none bg-transparent px-4 py-2 text-primary-500 font-semibold text-base mb-4 hover:text-primary-500"
                    onClick={() => setShowFilters((s) => !s)}
                >
                    <div className="flex">
                        <span className="mr-2">
                            {showFilters ? 'Ocultar' : 'Mostrar'} Filtros
                        </span>

                        <Icon
                            iconName={
                                showFilters
                                    ? 'ChevronUpSmall'
                                    : 'ChevronDownSmall'
                            }
                        />
                    </div>
                </DefaultButton>

                {showFilters && (
                    <div className="flex justify-between flex-wrap gap-4 mb-4">
                        {/* Cuadro de busqueda (q) */}
                        <SearchBox
                            placeholder="Filtrar por nombre, base de datos, región, país, rack, sala..."
                            className="w-full"
                            onChange={(q) =>
                                debouncedSetQuery(q?.target?.value ?? '')
                            }
                            onClear={() => setQuery('')}
                        />

                        <div className="w-full grid grid-cols-4 gap-x-4">
                            {/* Filtros por Tipo Servidor */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="font-medium">
                                        Tipo de servidor
                                    </label>

                                    {tipoServidor && (
                                        <button
                                            className="appearance-none text-primary-500 font-medium"
                                            onClick={() =>
                                                setTipoServidor(null)
                                            }
                                        >
                                            Limpiar
                                        </button>
                                    )}
                                </div>

                                <ComboBox
                                    placeholder="Seleccionar"
                                    options={dataTiposServidores?.data?.tipos_servidor?.map(
                                        (tipo) => ({
                                            key: tipo.id,
                                            text: tipo.nombre,
                                        })
                                    )}
                                    selectedKey={tipoServidor}
                                    onChange={(_, tipo) =>
                                        setTipoServidor(tipo.key)
                                    }
                                />
                            </div>

                            {/* Filtros por Base Datos */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="font-medium">
                                        Base de datos
                                    </label>

                                    {baseDatos && (
                                        <button
                                            className="appearance-none text-primary-500 font-medium"
                                            onClick={() => setBaseDatos(null)}
                                        >
                                            Limpiar
                                        </button>
                                    )}
                                </div>

                                <ComboBox
                                    placeholder="Seleccionar"
                                    options={dataBD?.data?.bases_de_datos?.map(
                                        (bd) => ({
                                            key: bd.id,
                                            text: bd.nombre,
                                        })
                                    )}
                                    selectedKey={baseDatos}
                                    onChange={(_, bd) => setBaseDatos(bd.key)}
                                />
                            </div>

                            {/* Filtros por Region */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="font-medium">
                                        Región
                                    </label>

                                    {region && (
                                        <button
                                            className="appearance-none text-primary-500 font-medium"
                                            onClick={() => setRegion(null)}
                                        >
                                            Limpiar
                                        </button>
                                    )}
                                </div>

                                <ComboBox
                                    placeholder="Seleccionar"
                                    options={dataRegiones?.data?.regiones?.map(
                                        (region) => ({
                                            key: region.id,
                                            text: region.nombre,
                                        })
                                    )}
                                    selectedKey={region}
                                    onChange={(_, region) =>
                                        setRegion(region.key)
                                    }
                                />
                            </div>

                            {/* Filtros por Pais */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="font-medium">País</label>

                                    {pais && (
                                        <button
                                            className="appearance-none text-primary-500 font-medium"
                                            onClick={() => setPais(null)}
                                        >
                                            Limpiar
                                        </button>
                                    )}
                                </div>

                                <ComboBox
                                    placeholder="Seleccionar"
                                    options={dataPaises?.data?.paises?.map(
                                        (pais) => ({
                                            key: pais.id,
                                            text: pais.nombre,
                                        })
                                    )}
                                    selectedKey={pais}
                                    onChange={(_, pais) => setPais(pais.key)}
                                />
                            </div>
                        </div>
                    </div>
                )}
            </div>

            {/* Tabla */}
            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataServidores?.data?.servidores?.map((servidor) => ({
                        key: servidor.id,
                        nombre: servidor.nombre,
                        tipo: servidor.tipo_servidor?.nombre,
                        so: servidor.sistema_operativo.nombre,
                        rack: servidor.rack?.nombre,
                        sala: servidor.rack.sala.nombre,
                        encargado: servidor.id,
                        acciones: (
                            <BotonUD
                                showDetail={user?.data?.usuario?.rol?.id !== 4}
                                showEdit={user?.data?.usuario?.rol?.id === 1}
                                showDelete={user?.data?.usuario?.rol?.id === 1}
                                onViewDetail={() => showDetailModal()}
                                onEdit={() => showEditModal()}
                                onDelete={() => showDeleteModal()}
                                setSelected={setServidorSeleccionado}
                                itemToSelect={servidor}
                            />
                        ),
                    })) ?? arrayCargando
                }
            />

            {/* Paginación */}
            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataServidores?.data?.meta?.total}
                    pageSize={dataServidores?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            {/* Modal Detalle  */}
            <Modal
                isOpen={isDetailModalOpen}
                onDismiss={hideDetailModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isDetailModalOpen && (
                    <DetalleServidor
                        servidor={servidorSeleccionado}
                        onCloseModal={hideDetailModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioServidor
                        tipo="crear"
                        onSubmit={handleCreateServidor}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioServidor
                        tipo="editar"
                        onSubmit={handleEditServidor}
                        isLoading={isLoading}
                        valoresIniciales={servidorSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar servidor',
                    subText: `¿Estás de acuerdo con eliminar el servidor: "${servidorSeleccionado?.nombre}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteServidor({
                                id: servidorSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoServidores;
