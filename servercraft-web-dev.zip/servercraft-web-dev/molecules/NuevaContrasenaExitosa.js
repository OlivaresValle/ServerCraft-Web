// Dependencias
import { Link as FluentLink, PrimaryButton, Icon } from '@fluentui/react';

// Componente
const FormularioLogin = () => {
    // Estados

    return (
        <div className="w-full shadow-2xl p-8 grid grid-cols-1 gap-6 bg-gray-50 relative">
            <h1 className="text-primary-500 font-semibold text-4xl mb-6">
                Crear Nueva Contraseña
            </h1>

            <div className="flex items-center">
                <Icon
                    iconName="SkypeCircleCheck"
                    className="text-6xl text-success-400"
                ></Icon>

                <p className="ml-4 font-medium text-md">
                    Los datos se han guardado correctamente en la base de datos.
                    Ya puedes iniciar sesión con tu nueva contraseña.
                </p>
            </div>

            <FluentLink href="/">
                <PrimaryButton className="mt-6 w-full">
                    Ir al inicio de sesión
                </PrimaryButton>
            </FluentLink>
        </div>
    );
};

// Exportación
export default FormularioLogin;
