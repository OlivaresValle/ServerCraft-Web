// Dependencies
import { IconButton } from '@fluentui/react';
import { useEquipoEncargado } from '../http/lib/equipoEncargado';
import nookies from 'nookies';
import { Shimmer } from '@fluentui/react';

// Componente
const DetalleEquipoProveedor = ({ equipo_encargado, onCloseModal }) => {
    // Estados
    const token = nookies.get()['auth-token'];

    const { data: dataEquipo } = useEquipoEncargado(equipo_encargado.id, token);

    return (
        <div className="w-full p-8 bg-gray-50">
            {/* Titulo de Modal */}
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                    Detalle equipo del proveedor
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                />
            </div>

            {/* Información General */}
            <div className="flex flex-col mt-4 mb-4">
                <div className="grid gap-y-6">
                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Nombre de equipo
                        </h3>

                        {dataEquipo ? (
                            <p>{dataEquipo.data.equipo_encargado.nombre}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Nombre proveedor
                        </h3>

                        {dataEquipo ? (
                            <p>
                                {
                                    dataEquipo.data.equipo_encargado
                                        .proveedor_sistema.nombre
                                }
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Email equipo
                        </h3>

                        {dataEquipo ? (
                            <p>
                                {
                                    dataEquipo.data.equipo_encargado
                                        .proveedor_sistema.email_contacto
                                }
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Teléfono contacto
                        </h3>

                        {dataEquipo ? (
                            <p>
                                {
                                    dataEquipo.data.equipo_encargado
                                        .proveedor_sistema.telefono_contacto
                                }
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Representante del equipo
                        </h3>

                        {dataEquipo ? (
                            <p>
                                {
                                    dataEquipo.data.equipo_encargado
                                        .proveedor_sistema.nombre_representante
                                }
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

// Export
export default DetalleEquipoProveedor;
