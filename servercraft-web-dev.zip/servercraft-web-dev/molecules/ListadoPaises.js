// Dependencias
import {
    Breadcrumb,
    PrimaryButton,
    DetailsList,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    Spinner,
    DefaultButton,
    SpinnerSize,
    Link as FLink,
    Icon,
    SearchBox,
} from '@fluentui/react';
import Link from 'next/link';
import { useBoolean } from '@fluentui/react-hooks';
import nookies from 'nookies';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import ErrorToast from '../atoms/errorToast';
import SuccessToast from '../atoms/successToast';
import { usePaises, createPais, editPais, deletePais } from '../http/lib/pais';
import { CargandoTabla } from '../servicios/cargandoTabla';
import FormularioPais from './FormularioPais';
import { useState } from 'react';
import debounce from 'lodash/debounce';
import Pagination from 'rc-pagination';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoPaises = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const [isLoading, setIsLoading] = useState(false);
    const [paisSeleccionado, setPaisSeleccionado] = useState(undefined);

    // Filtros
    const [query, setQuery] = useState('');
    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        {
            key: 'pais',
            name: 'País',
            fieldName: 'pais',
            onRender: (item) => <p className="font-medium">{item.nombre}</p>,
        },

        {
            key: 'regiones',
            name: 'Número de regiones',
            fieldName: 'regiones',
            minWidth: 200,
        },

        {
            key: 'acciones',
            name: 'Acciones',
            fieldName: 'acciones',
        },
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    const { data: dataPaises, mutate: mutatePaises } = usePaises(
        10,
        currentPage,
        query,
        token
    );

    // Handlers
    const handleCreatePais = async (values) => {
        setIsLoading(true);
        try {
            const response = await createPais({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutatePaises();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'País creado con éxito.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditPais = async (values) => {
        setIsLoading(true);
        try {
            const response = await editPais({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutatePaises();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'País editado correctamente.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeletePais = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deletePais({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutatePaises();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'País eliminado exitosamente.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-12 px-16">
            <Breadcrumb
                className="py-4"
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: `Ubicaciones`,
                        href: `/ubicaciones`,
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-medium text-4xl">
                    Listado de paises
                </h1>

                <PrimaryButton
                    iconProps={{ iconName: 'Add' }}
                    text="Nuevo país"
                    className="px-12"
                    onClick={showCreateModal}
                />
            </div>

            {/* Filtros */}

            <div className="flex justify-between flex-wrap gap-4 mb-4">
                {/* Cuadro de busqueda (q) */}
                <SearchBox
                    placeholder="Filtrar por nombre..."
                    className="w-full"
                    onChange={(q) => {
                        debouncedSetQuery(q?.target?.value ?? '');
                    }}
                    onClear={() => setQuery('')}
                />
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataPaises?.data?.paises?.map((pais) => ({
                        key: pais?.id,
                        nombre: pais?.nombre,
                        regiones: pais?.meta?.regiones_count,
                        acciones: (
                            <BotonUD
                                showEdit
                                showDelete
                                onEdit={() => showEditModal()}
                                onDelete={() => showDeleteModal()}
                                setSelected={setPaisSeleccionado}
                                itemToSelect={pais}
                            />
                        ),
                    })) ?? arrayCargando
                }
            />

            {/* Paginación */}
            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataPaises?.data?.meta?.total}
                    pageSize={dataPaises?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioPais
                        tipo="crear"
                        onSubmit={handleCreatePais}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioPais
                        tipo="editar"
                        onSubmit={handleEditPais}
                        isLoading={isLoading}
                        valoresIniciales={paisSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar país',
                    subText: `¿Estás de acuerdo con eliminar el país: "${paisSeleccionado?.nombre}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeletePais({
                                id: paisSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoPaises;
