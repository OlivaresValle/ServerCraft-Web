// Dependencies
import { IconButton, Separator } from '@fluentui/react';
import { useIncidente } from '../http/lib/incidente';
import nookies from 'nookies';
import dayjs from 'dayjs';
import { Shimmer } from '@fluentui/react';
import localizedFormat from 'dayjs/plugin/localizedFormat';

dayjs.extend(localizedFormat);
dayjs.locale('es');

// Componente
const DetalleIncidente = ({ incidente, onCloseModal }) => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data } = useIncidente(incidente.id, token);

    return (
        <div className="w-full p-8 bg-gray-50">
            {/* Titulo de Modal */}
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                    Detalle de Incidente
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                />
            </div>

            {/* Detalle General */}
            <div className="flex flex-col mt-4 mb-4">
                <h2 className="font-semibold text-lg text-primary-500 mb-3">
                    Información general
                </h2>

                <div className="grid grid-cols-2 gap-y-6">
                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Estado incidente
                        </h3>

                        {data ? (
                            <p
                                className={`font-medium ${
                                    data.data.incidente.estado_incidente.id ===
                                    1
                                        ? 'text-red-500'
                                        : data.data.incidente.estado_incidente
                                              .id === 2
                                        ? 'text-warning-500'
                                        : 'text-success-500'
                                }`}
                            >
                                {data.data.incidente.estado_incidente.nombre}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Sistema afectado
                        </h3>

                        {data ? (
                            <p>
                                {`${data.data.incidente.instancia_sistema.sistema.nombre} - Instancia ${data.data.incidente.instancia_sistema.tipo_instancia.nombre}`}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Servidor afectado
                        </h3>

                        {data ? (
                            <p>
                                {
                                    data.data.incidente.instancia_sistema
                                        .servidor.nombre
                                }
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Encargado
                        </h3>

                        {data ? (
                            <p>
                                {
                                    data.data.incidente.instancia_sistema
                                        .sistema.usuario.nombre
                                }
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>
                </div>
            </div>

            <Separator />

            {/* Detalle Problema */}
            <div className="flex flex-col mt-4 mb-8">
                <h2 className="font-semibold text-lg text-primary-500 mb-3">
                    Información del problema
                </h2>

                <div className="grid grid-cols-2 gap-y-6">
                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Fecha y hora de problema
                        </h3>

                        {data ? (
                            <p>
                                {dayjs(
                                    data.data.incidente.fecha_hora_problema
                                ).format('LLLL')}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Tipo de problema
                        </h3>

                        {data ? (
                            <p>{data.data.incidente.tipo_problema.nombre}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div className="col-span-2">
                        <h3 className="font-medium text-primary-500 mb-1">
                            Detalle problema
                        </h3>

                        {data ? (
                            <p>{data.data.incidente.detalle_problema}</p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>
                </div>
            </div>

            <Separator />

            {/* Detalle Solucion */}
            <div className="flex flex-col mt-4 mb-8">
                <h2 className="font-semibold text-lg text-primary-500 mb-3">
                    Información de la solución
                </h2>

                <div className="grid grid-cols-3 gap-x-8 gap-y-6">
                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Fecha y hora de solución
                        </h3>

                        {data ? (
                            <p>
                                {data.data.incidente.fecha_hora_solucion
                                    ? dayjs(
                                          data.data.incidente
                                              .fecha_hora_solucion
                                      ).format('LLLL')
                                    : 'Sin solución'}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Tipo de solución
                        </h3>

                        {data ? (
                            <p>
                                {data.data.incidente.tipo_solucion
                                    ? data.data.incidente.tipo_solucion.nombre
                                    : 'Sin solución'}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div>
                        <h3 className="font-medium text-primary-500 mb-1">
                            Equipo encargado de solución
                        </h3>

                        {data ? (
                            <p>
                                {data.data.incidente.equipo_trabajo
                                    ? data.data.incidente.equipo_trabajo.nombre
                                    : 'Sin solución'}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>

                    <div className="col-span-3">
                        <h3 className="font-medium text-primary-500 mb-1">
                            Detalle solución
                        </h3>

                        {data ? (
                            <p>
                                {data.data.incidente.detalle_solucion
                                    ? data.data.incidente.detalle_solucion
                                    : 'Sin solución'}
                            </p>
                        ) : (
                            <Shimmer width="100%" className="mr-12" />
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

// Export
export default DetalleIncidente;
