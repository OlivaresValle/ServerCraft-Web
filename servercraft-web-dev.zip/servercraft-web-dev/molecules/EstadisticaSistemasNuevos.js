// Dependencias
import React from 'react';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { useSistemasNuevos } from '../http/lib/estadistica';
import nookies from 'nookies';

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend
);

export const options = {
    responsive: true,
    plugins: {
        legend: {
            position: 'bottom',
        },
        title: {
            display: true,
            text: 'Cantidad de sistemas nuevos mensuales',
            font: {
                size: 20,
            },
            color: '#007FD2',
            padding: {
                bottom: 30,
            },
            align: 'start',
        },
    },
    scales: {
        y: {
            suggestedMax: 10,
        },
    },
};

const labels = [
    'Enero',
    'Febrero',
    'Marzo',
    'Abril',
    'Mayo',
    'Junio',
    'Julio',
    'Agosto',
    'Septiembre',
    'Octubre',
    'Noviembre',
    'Diciembre',
];

const EstadisticaSistemasNuevos = () => {
    //Estados
    const token = nookies.get()['auth-token'];
    const { data } = useSistemasNuevos(token);

    const sistemas = {
        labels,
        datasets: [
            {
                label: 'Sistemas nuevos mensuales',
                data: data?.data?.data.map((con) => con.sistemas),
                backgroundColor: 'rgb(0,120,212,0.5)',
                borderColor: '#007FD2',
            },
        ],
    };

    return (
        <Line
            className="bg-white px-6 pt-8"
            options={options}
            data={sistemas}
        />
    );
};

export default EstadisticaSistemasNuevos;
