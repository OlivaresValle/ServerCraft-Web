// Dependencias
import { useState } from 'react';
import { PrimaryButton, Spinner } from '@fluentui/react';
import ControlledInput from '../atoms/controlledInput';
import { useForm } from 'react-hook-form';
import * as Yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { recoverPassword } from '../http/lib/auth';
import RecuperacionSuccess from './RecuperacionExitosa';

const recuperarSchema = Yup.object({
    email: Yup.string().required('Campo obligatorio').email('Email inválido'),
});

// Componente
const FormularioRecuperar = () => {
    // Estados
    const [correoComprobado, setCorreoComprobado] = useState();
    const [isLoading, setIsLoading] = useState(false);
    const [step, setStep] = useState(1);
    const { control, handleSubmit } = useForm({
        resolver: yupResolver(recuperarSchema),
    });

    // Handlers
    const onRecuperarContrasena = async ({ email }) => {
        setIsLoading(true);

        try {
            await recoverPassword({ email });
            setCorreoComprobado(email);
            setStep(2);
        } catch (error) {}

        setIsLoading(false);
    };

    return (
        <div className="w-full shadow-2xl p-8 grid grid-cols-1 gap-6 bg-gray-50 relative">
            <h1 className="w-full text-primary-500 font-semibold text-xl md:text-4xl mb-0 md:mb-6">
                Recuperar contraseña
            </h1>

            {step === 1 ? (
                <form onSubmit={handleSubmit(onRecuperarContrasena)}>
                    <ControlledInput
                        control={control}
                        name="email"
                        label="Correo electrónico"
                        placeholder="correo@correo.cl"
                    />

                    <PrimaryButton
                        type="submit"
                        className="w-full md:w-auto mt-6 md:mt-4"
                        loading
                    >
                        {isLoading && <Spinner className="mr-2" />}Recuperar
                        contraseña
                    </PrimaryButton>
                </form>
            ) : (
                <RecuperacionSuccess correo={correoComprobado} />
            )}
        </div>
    );
};

// Export
export default FormularioRecuperar;
