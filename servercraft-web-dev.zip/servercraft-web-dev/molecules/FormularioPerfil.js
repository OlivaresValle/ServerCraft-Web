// Dependencias
import Image from 'next/image';
import { useEffect, useState } from 'react';
import * as yup from 'yup';
import { PrimaryButton, Spinner, Label, DefaultButton } from '@fluentui/react';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import nookies from 'nookies';
import {
    useUsuario,
    editImagenUsuario,
    editUsuario,
} from '../http/lib/usuario/usuario.calls';
import ControlledInput from '../atoms/controlledInput';
import toast from 'react-hot-toast';
import SuccessToast from '../atoms/successToast';
import ErrorToast from '../atoms/errorToast';

const perfilSchema = yup
    .object({
        email: yup
            .string()
            .email('Ingresa un email válido')
            .required('Campo obligatorio'),
        nombre: yup.string().required('Campo obligatorio'),
        apellidos: yup.string().required('Campo obligatorio'),
        telefonoContacto: yup.string().required('Campo obligatorio'),
    })
    .required();

// Componente
const FormularioPerfil = () => {
    // Estados
    const [isLoading, setIsLoading] = useState(false);
    const token = nookies.get()['auth-token'];
    const { data: dataUsuario, mutate: mutateUsuario } = useUsuario(0, token);
    const [imageValue, setImageValue] = useState('');
    const [valoresSeteados, setValoresSeteados] = useState(false);

    const { handleSubmit, control, watch, setValue } = useForm({
        resolver: yupResolver(perfilSchema),
        defaultValues: {
            nombre: dataUsuario?.data?.usuario?.nombre,
            email: dataUsuario?.data?.usuario?.email,
            apellidos: dataUsuario?.data?.usuario?.apellidos,
            telefonoContacto: dataUsuario?.data?.usuario?.telefono_contacto,
        },
    });

    const image = watch('image');

    // Handlers
    const onSubmit = async ({ image, ...values }) => {
        setIsLoading(true);
        try {
            const responsePerfil = await editUsuario({
                token,
                id: dataUsuario?.data?.usuario?.id,
                ...values,
                email: null,
            });

            if (image) {
                const formData = new FormData();
                formData.append('imagen', image);

                const responseImagen = await editImagenUsuario({
                    formData,
                    token,
                });

                if (responseImagen.status) {
                    toast.custom((t) => (
                        <SuccessToast
                            t={t}
                            text={'Imagen actualizada correctamente.'}
                        />
                    ));
                    setIsLoading(false);
                    setValue('image', undefined);
                }
            }

            if (responsePerfil.status) {
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Perfil actualizado correctamente.'}
                    />
                ));
                setIsLoading(false);
            }

            mutateUsuario();
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    // Efectos
    useEffect(() => {
        if (dataUsuario && !valoresSeteados) {
            setValue('nombre', dataUsuario?.data?.usuario?.nombre);
            setValue('email', dataUsuario?.data?.usuario?.email);
            setValue('apellidos', dataUsuario?.data?.usuario?.apellidos);
            setValue(
                'telefonoContacto',
                dataUsuario?.data?.usuario?.telefono_contacto
            );

            setValoresSeteados(true);
        }
    }, [dataUsuario, setValue, valoresSeteados]);

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            className="w-full shadow-2xl p-8 grid grid-cols-2 gap-6 bg-gray-50 relative"
        >
            <div className="col-span-2">
                <Label>Imagen</Label>

                <div className="flex items-center pt-4">
                    <div className="w-24 h-24 rounded-full mr-6 bg-gray-200">
                        <Image
                            src={
                                image
                                    ? URL?.createObjectURL(image)
                                    : undefined ??
                                      dataUsuario?.data?.usuario?.imagen?.url ??
                                      '/'
                            }
                            alt={dataUsuario?.data?.usuario?.nombre}
                            width={250}
                            height={250}
                            className="w-8 h-8 rounded-full mr-6 object-cover object-center"
                        />
                    </div>

                    <Controller
                        name="image"
                        control={control}
                        render={({
                            field: { onChange, onBlur, value, name: fieldName },
                        }) => (
                            <DefaultButton className="relative font-semibold">
                                Actualizar Imagen
                                <input
                                    type="file"
                                    className="absolute w-full h-full opacity-0"
                                    accept="image/*"
                                    onChange={(e) => {
                                        setImageValue(e.target.value);
                                        onChange(e.target.files[0]);
                                    }}
                                    value={imageValue}
                                    onBlur={onBlur}
                                    name={fieldName}
                                />
                            </DefaultButton>
                        )}
                    />
                </div>
            </div>

            <ControlledInput name="nombre" control={control} label="Nombre" />

            <ControlledInput
                name="apellidos"
                control={control}
                label="Apellidos"
            />

            <ControlledInput
                name="email"
                control={control}
                label="Email"
                placeholder="correo@correo.cl"
            />

            <ControlledInput
                name="telefonoContacto"
                control={control}
                label="Telefono de contacto"
                placeholder="912345678"
                prefix="+56"
                type="number"
            />

            <div>
                <PrimaryButton type="submit" className="mt-4" loading>
                    {isLoading && <Spinner className="mr-2" />}Guardar cambios
                </PrimaryButton>
            </div>
        </form>
    );
};

// Exportación
export default FormularioPerfil;
