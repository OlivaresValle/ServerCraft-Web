// Dependencias
import { useEffect, useState } from 'react';
import {
    Breadcrumb,
    PrimaryButton,
    ComboBox,
    DetailsList,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    DefaultButton,
    Spinner,
    SearchBox,
    SpinnerSize,
} from '@fluentui/react';
import Pagination from 'rc-pagination';
import { useBoolean } from '@fluentui/react-hooks';
import nookies from 'nookies';
import {
    createUsuario,
    useUsuarios,
    editUsuario,
    deleteUsuario,
} from '../http/lib/usuario';
import { CargandoTabla } from '../servicios/cargandoTabla';
import FormularioUsuario from './FormularioUsuario';
import DetalleUsuario from './DetalleUsuario';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import SuccessToast from '../atoms/successToast';
import ErrorToast from '../atoms/errorToast';
import { useRol } from '../http/lib/roles/roles.calls';
import debounce from 'lodash/debounce';
import { useEquiposTrabajos } from '../http/lib/equipoTrabajo/equipoTrabajo.calls';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoUsuarios = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);
    const [isLoading, setIsLoading] = useState(false);
    const [usuarioSeleccionado, setUsuarioSeleccionado] = useState(undefined);

    // Filtros
    const [query, setQuery] = useState('');
    const [roles, setRoles] = useState();
    const [equipos, setEquipos] = useState();

    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isDetailModalOpen,
        { setTrue: showDetailModal, setFalse: hideDetailModal },
    ] = useBoolean(false);
    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        { key: 'nombre', name: 'Nombre', fieldName: 'nombre' },
        { key: 'rol', name: 'Rol', fieldName: 'rol' },
        { key: 'equipo', name: 'Equipo', fieldName: 'equipo' },
        { key: 'email', name: 'Email', fieldName: 'email' },
        {
            key: 'sistemas',
            name: 'Sistemas',
            fieldName: 'sistemas',
        },
        ...(user?.data?.usuario?.rol?.id === 1
            ? [
                  {
                      key: 'acciones',
                      name: 'Acciones',
                      fieldName: 'acciones',
                  },
              ]
            : []),
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    //API
    const { data: dataUsuarios, mutate: mutateUsuarios } = useUsuarios(
        10,
        currentPage,
        query,
        roles,
        equipos,
        token
    );

    const { data: dataRoles } = useRol(10000, 1, null, token);
    const { data: dataEquipos } = useEquiposTrabajos(10000, 1, null, token);

    // Efectos
    useEffect(() => {
        setCurrentPage(1);
    }, [query, roles, equipos]);

    // Handlers
    // Crear Usuario
    const handleCreateUsuario = async (values) => {
        setIsLoading(true);
        try {
            const response = await createUsuario({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateUsuarios();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'Usuario creado con éxito.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };
    //Editar Usuario
    const handleEditUsuario = async ({ rut, email, password, ...values }) => {
        setIsLoading(true);
        try {
            const response = await editUsuario({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateUsuarios();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Usuario editado correctamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };
    //Eliminar Usuario
    const handleDeleteUsuario = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteUsuario({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateUsuarios();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Usuario eliminado exitosamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-6 px-16">
            <Breadcrumb
                className="py-4"
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Usuarios y equipos',
                        key: 'miembros',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-semibold text-4xl">
                    Listado de usuarios
                </h1>

                {user?.data?.usuario?.rol?.id === 1 && (
                    <PrimaryButton
                        iconProps={{ iconName: 'Add' }}
                        text="Nuevo usuario"
                        className="px-12"
                        onClick={showCreateModal}
                    />
                )}
            </div>

            {/* Filtros */}
            <div>
                <div className="grid grid-cols-5 gap-x-4 mb-4 items-end">
                    {/* Cuadro de busqueda (q) */}
                    <SearchBox
                        placeholder="Filtrar por nombre, roles o equipos de trabajo"
                        className="col-span-3"
                        onChange={(q) => {
                            debouncedSetQuery(q?.target?.value ?? '');
                        }}
                        onClear={() => setQuery('')}
                    />

                    {/* Filtros por Rol */}
                    <div className="col-span-1">
                        <div className="flex justify-between mb-2">
                            <label className="font-medium">Rol</label>

                            {roles && (
                                <button
                                    className="appearance-none text-primary-500 font-medium"
                                    onClick={() => setRoles(null)}
                                >
                                    Limpiar
                                </button>
                            )}
                        </div>

                        <ComboBox
                            placeholder="Seleccionar"
                            options={dataRoles?.data?.rol?.map((r) => ({
                                key: r.id,
                                text: r.nombre,
                            }))}
                            selectedKey={roles}
                            onChange={(_, r) => setRoles(r.key)}
                        />
                    </div>

                    {/* Filtros por Equipo de Trabajo */}
                    <div className="col-span-1">
                        <div className="flex justify-between mb-2">
                            <label className="font-medium">
                                Equipo de trabajo
                            </label>

                            {equipos && (
                                <button
                                    className="appearance-none text-primary-500 font-medium"
                                    onClick={() => setEquipos(null)}
                                >
                                    Limpiar
                                </button>
                            )}
                        </div>

                        <ComboBox
                            placeholder="Seleccionar"
                            options={dataEquipos?.data?.equipos_trabajo?.map(
                                (e) => ({
                                    key: e.id,
                                    text: e.nombre,
                                })
                            )}
                            selectedKey={equipos}
                            onChange={(_, e) => setEquipos(e.key)}
                        />
                    </div>
                </div>
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataUsuarios?.data?.usuarios?.map((usuario) => ({
                        key: usuario.id,
                        nombre: `${usuario.nombre} ${usuario.apellidos}`,
                        rol: usuario?.rol?.nombre,
                        equipo: usuario.equipo_trabajo?.nombre ?? 'Sin equipo',
                        email: usuario.email,
                        sistemas: usuario?.meta?.sistemas_count ?? 0,
                        acciones: (
                            <BotonUD
                                showDetail
                                showEdit
                                showDelete
                                onViewDetail={() => showDetailModal()}
                                onEdit={() => showEditModal()}
                                onDelete={() => showDeleteModal()}
                                setSelected={setUsuarioSeleccionado}
                                itemToSelect={usuario}
                            />
                        ),
                    })) ?? arrayCargando
                }
            />

            {/* Paginación */}

            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataUsuarios?.data?.meta?.total}
                    pageSize={dataUsuarios?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            <Modal
                isOpen={isDetailModalOpen}
                onDismiss={hideDetailModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isDetailModalOpen && (
                    <DetalleUsuario
                        usuario={usuarioSeleccionado}
                        onCloseModal={hideDetailModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioUsuario
                        tipo="crear"
                        onSubmit={handleCreateUsuario}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioUsuario
                        tipo="editar"
                        onSubmit={handleEditUsuario}
                        isLoading={isLoading}
                        valoresIniciales={usuarioSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar usuario',
                    subText: `¿Estás de acuerdo con eliminar el usuario: "${usuarioSeleccionado?.nombre} ${usuarioSeleccionado?.apellidos}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteUsuario({
                                id: usuarioSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoUsuarios;
