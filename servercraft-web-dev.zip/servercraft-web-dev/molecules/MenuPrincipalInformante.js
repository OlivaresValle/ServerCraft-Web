// Dependencias
import BotonMenu from '../atoms/BotonMenu';
import Image from 'next/image';

const menus = [
    {
        icon: '/Iconos/System_Icon.png',
        text: 'Sistemas o aplicaciones',
        secondaryText: 'Listado de los Sistemas.',
        detallado: true,
        href: '/sistemas',
    },
    {
        icon: '/Iconos/Issues_Icon.png',
        text: 'Incidentes',
        secondaryText: 'Listado de los Incidentes.',
        detallado: true,
        href: '/incidentes',
    },
];

// Componente
const MenuPrincipalInformante = () => {
    return (
        <div className="container py-8 mx-auto px-4">
            <h1 className="text-primary-500 font-semibold text-4xl mb-6">
                Menú Principal
            </h1>

            <div className="flex items-start">
                <div className="grid grid-cols-4 gap-4 mr-8 w-7/12">
                    {menus.map((menu) => (
                        <div key={menu?.href} className="col-span-4">
                            <BotonMenu
                                icon={
                                    <Image
                                        src={menu?.icon}
                                        alt="icono"
                                        width={130}
                                        height={110}
                                        className="flex-grow object-contain"
                                    />
                                }
                                text={menu.text}
                                secondaryText={menu.secondaryText}
                                detallado={menu.detallado}
                                href={menu.href}
                            />
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

// Exportación
export default MenuPrincipalInformante;
