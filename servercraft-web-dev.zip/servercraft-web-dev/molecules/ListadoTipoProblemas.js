// Dependencias
import {
    Breadcrumb,
    PrimaryButton,
    DetailsList,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    DefaultButton,
    Spinner,
    SpinnerSize,
    SearchBox,
} from '@fluentui/react';
import Pagination from 'rc-pagination';
import nookies from 'nookies';
import { useEffect, useState } from 'react';
import {
    useTiposProblema,
    createTipoProblema,
    editTipoProblema,
    deleteTipoProblema,
} from '../http/lib/tipoProblema';
import { CargandoTabla } from '../servicios/cargandoTabla';
import { useBoolean } from '@fluentui/react-hooks';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import SuccessToast from '../atoms/successToast';
import ErrorToast from '../atoms/errorToast';
import FormularioTipoProblemas from '../molecules/FormularioTipoProblemas';
import debounce from 'lodash/debounce';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoTipoProblemas = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);
    const [isLoading, setIsLoading] = useState(false);
    const [tipoProblemaSeleccionado, setTipoProblemaSeleccionado] = useState();

    // Filtros
    const [query, setQuery] = useState('');
    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        {
            key: 'nombre',
            name: 'Nombre',
            fieldName: 'nombre',

            onRender: (item) => (
                <p className="font-bold d-inline-block">{item.nombre}</p>
            ),
        },
        ...([1, 2].includes(user?.data?.usuario?.rol?.id)
            ? [
                  {
                      key: 'acciones',
                      name: 'Acciones',
                      fieldName: 'acciones',
                  },
              ]
            : []),
    ];

    const arrayCargando = CargandoTabla(columnas, 4);

    //API
    const { data: dataTiposProblema, mutate: mutateTipoProblema } =
        useTiposProblema(10, currentPage, query, token);

    // Efectos
    useEffect(() => {
        setCurrentPage(1);
    }, [query]);

    // Handlers
    const handleCreateTipoProblema = async (values) => {
        setIsLoading(true);
        try {
            const response = await createTipoProblema({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateTipoProblema();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Tipo de problema creado con éxito.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditTipoProblema = async ({ ...values }) => {
        setIsLoading(true);
        try {
            const response = await editTipoProblema({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateTipoProblema();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Tipo de problema editado correctamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteTipoProblema = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteTipoProblema({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateTipoProblema();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Tipo de problema eliminado exitosamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-12 px-16">
            <Breadcrumb
                className="py-4"
                styles={{}}
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Incidentes',
                        href: '/tipo-problemas',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-bold text-4xl">
                    Listado de tipos de problemas
                </h1>

                <PrimaryButton
                    onClick={showCreateModal}
                    iconProps={{ iconName: 'Add' }}
                    text="Nuevo problema"
                    className="px-12"
                />
            </div>

            {/* Filtros */}
            <div>
                <div className="grid grid-cols-5 gap-1 mb-4 items-end">
                    {/* Cuadro de busqueda (q) */}
                    <SearchBox
                        placeholder="Filtrar por nombre de tipo de problemas"
                        className="col-span-5"
                        onChange={(q) => {
                            debouncedSetQuery(q?.target?.value ?? '');
                        }}
                        onClear={() => setQuery('')}
                    />
                </div>
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataTiposProblema?.data?.tipos_problema?.map(
                        (tipoProblema) => ({
                            key: tipoProblema.id,
                            nombre: tipoProblema.nombre,
                            sistemas: tipoProblema.id,
                            acciones: (
                                <BotonUD
                                    showEdit={[1, 2].includes(
                                        user?.data?.usuario?.rol?.id
                                    )}
                                    showDelete={
                                        user?.data?.usuario?.rol?.id === 1
                                    }
                                    onEdit={() => showEditModal()}
                                    onDelete={() => showDeleteModal()}
                                    setSelected={setTipoProblemaSeleccionado}
                                    itemToSelect={tipoProblema}
                                />
                            ),
                        })
                    ) ?? arrayCargando
                }
            />

            {/* Paginación */}

            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataTiposProblema?.data?.meta?.total}
                    pageSize={dataTiposProblema?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '660px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioTipoProblemas
                        tipo="crear"
                        onSubmit={handleCreateTipoProblema}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '660px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioTipoProblemas
                        tipo="editar"
                        onSubmit={handleEditTipoProblema}
                        isLoading={isLoading}
                        valoresIniciales={tipoProblemaSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar tipo de problema',
                    subText: `¿Estás de acuerdo con eliminar el tipo de problema: "${tipoProblemaSeleccionado?.nombre}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteTipoProblema({
                                id: tipoProblemaSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoTipoProblemas;
