// Dependencias
import { useEffect, useState } from 'react';
import {
    Breadcrumb,
    ComboBox,
    PrimaryButton,
    DetailsList,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    DefaultButton,
    Spinner,
    SpinnerSize,
    SearchBox,
} from '@fluentui/react';
import Pagination from 'rc-pagination';
import { useBoolean } from '@fluentui/react-hooks';
import nookies from 'nookies';
import {
    createEquipoTrabajo,
    editEquipoTrabajo,
    useEquiposTrabajos,
    deleteEquipoTrabajo,
} from '../http/lib/equipoTrabajo';
import { CargandoTabla } from '../servicios/cargandoTabla';
import FormularioEquipoTrabajo from './FormularioEquipoTrabajo';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import SuccessToast from '../atoms/successToast';
import ErrorToast from '../atoms/errorToast';
import debounce from 'lodash/debounce';
import { useUnidadNegocios } from '../http/lib/unidadNegocio/unidadNegocio.calls';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

//componentes

const ListadoEquiposTrabajos = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);

    const [isLoading, setIsLoading] = useState(false);
    const [equipoTrabajoSeleccionado, setequipoTrabajoSeleccionado] =
        useState(undefined);

    // Filtros
    const [query, setQuery] = useState('');
    const [unidadNegocio, setUnidadNegocio] = useState();

    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        { key: 'nombre', name: 'Nombre', fieldName: 'nombre' },
        {
            key: 'unidad',
            name: 'Unidad de negocio',
            fieldName: 'unidad',
            minWidth: 200,
        },
        ...(user?.data?.usuario?.rol?.id === 1
            ? [
                  {
                      key: 'acciones',
                      name: 'Acciones',
                      fieldName: 'acciones',
                  },
              ]
            : []),
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    // API
    const { data: dataEquiposTrabajos, mutate: mutateEquipoTrabajo } =
        useEquiposTrabajos(10, currentPage, query, token, unidadNegocio);
    const { data: dataUnidadNegocio } = useUnidadNegocios(
        10000000,
        1,
        null,
        token
    );

    // Efectos
    useEffect(() => {
        setCurrentPage(1);
    }, [query, unidadNegocio]);

    // Handlers
    const handleCreateEquipoTrabajo = async (values) => {
        setIsLoading(true);
        try {
            const response = await createEquipoTrabajo({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateEquipoTrabajo();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'Equipo creado con éxito.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditEquipoTrabajo = async ({ ...values }) => {
        setIsLoading(true);
        try {
            const response = await editEquipoTrabajo({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateEquipoTrabajo();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Equipo de trabajo editado correctamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteEquipoTrabajo = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteEquipoTrabajo({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateEquipoTrabajo();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Equipo de trabajo eliminado exitosamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-6 px-16">
            <Breadcrumb
                className="py-4"
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Usuarios y equipos',
                        key: 'equipo_trabajo',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-semibold text-4xl">
                    Listado de equipos de trabajo
                </h1>

                {user?.data?.usuario?.rol?.id === 1 && (
                    <PrimaryButton
                        iconProps={{ iconName: 'Add' }}
                        text="Nuevo Equipo de trabajo"
                        className="px-12"
                        onClick={showCreateModal}
                    />
                )}
            </div>

            {/* Filtros */}
            <div>
                <div className="grid grid-cols-5 gap-x-4 mb-4 items-end">
                    {/* Cuadro de busqueda (q) */}
                    <SearchBox
                        placeholder="Filtrar por nombre, unidad de negocio......"
                        className="col-span-4"
                        onChange={(q) => {
                            debouncedSetQuery(q?.target?.value ?? '');
                        }}
                        onClear={() => setQuery('')}
                    />

                    {/* Filtros por Unidad de Negocio */}
                    <div className="col-span-1">
                        <div className="flex justify-between mb-2">
                            <label className="font-medium">
                                Unidad de negocio
                            </label>

                            {unidadNegocio && (
                                <button
                                    className="appearance-none text-primary-500 font-medium"
                                    onClick={() => setUnidadNegocio(null)}
                                >
                                    Limpiar
                                </button>
                            )}
                        </div>

                        <ComboBox
                            placeholder="Seleccionar"
                            options={dataUnidadNegocio?.data?.unidades_negocio?.map(
                                (unidad) => ({
                                    key: unidad.id,
                                    text: unidad.nombre,
                                })
                            )}
                            selectedKey={unidadNegocio}
                            onChange={(_, unidad) =>
                                setUnidadNegocio(unidad.key)
                            }
                        />
                    </div>
                </div>
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataEquiposTrabajos?.data?.equipos_trabajo?.map(
                        (equiposTrabajos) => ({
                            key: equiposTrabajos.id,
                            unidad: equiposTrabajos?.unidad_negocio?.nombre,
                            nombre: equiposTrabajos.nombre,
                            acciones: (
                                <BotonUD
                                    showEdit
                                    showDelete
                                    onEdit={() => showEditModal()}
                                    onDelete={() => showDeleteModal()}
                                    setSelected={setequipoTrabajoSeleccionado}
                                    itemToSelect={equiposTrabajos}
                                />
                            ),
                        })
                    ) ?? arrayCargando
                }
            />

            {/* Paginación */}

            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataEquiposTrabajos?.data?.meta?.total}
                    pageSize={dataEquiposTrabajos?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioEquipoTrabajo
                        tipo="crear"
                        onSubmit={handleCreateEquipoTrabajo}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioEquipoTrabajo
                        tipo="editar"
                        onSubmit={handleEditEquipoTrabajo}
                        isLoading={isLoading}
                        valoresIniciales={equipoTrabajoSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar equipo',
                    subText: `¿Estás de acuerdo con eliminar el equipo: "${equipoTrabajoSeleccionado?.nombre}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteEquipoTrabajo({
                                id: equipoTrabajoSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoEquiposTrabajos;
