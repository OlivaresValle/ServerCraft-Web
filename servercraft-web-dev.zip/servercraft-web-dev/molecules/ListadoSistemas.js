// Dependencias
import {
    DetailsList,
    Breadcrumb,
    PrimaryButton,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    DefaultButton,
    Spinner,
    SpinnerSize,
    ComboBox,
    SearchBox,
    Icon,
} from '@fluentui/react';
import nookies from 'nookies';
import {
    useSistemas,
    createSistema,
    editSistema,
    deleteSistema,
} from '../http/lib/sistema/sistema.calls';
import { CargandoTabla } from '../servicios/cargandoTabla';
import BotonUD from '../atoms/BotonUD';
import { useBoolean } from '@fluentui/react-hooks';
import toast from 'react-hot-toast';
import SuccessToast from '../atoms/successToast';
import ErrorToast from '../atoms/errorToast';
import FormularioSistema from './FormularioSistema';
import DetalleSistema from './DetalleSistema';
import { useEffect, useState } from 'react';
import { useServidores } from '../http/lib/servidor';
import { useNivelesSeguridad } from '../http/lib/nivelSeguridad';
import { useNivelesSensibilidad } from '../http/lib/nivelSensiblidad';
import { useProveedoresSistema } from '../http/lib/proveedorSistema';
import { useUsuarios } from '../http/lib/usuario';
import debounce from 'lodash/debounce';
import Pagination from 'rc-pagination';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoSistemas = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);

    // Filtros
    const [showFilters, setShowFilters] = useState(false);
    const [query, setQuery] = useState('');
    const [servidor, setServidor] = useState('');
    const [nivelSeguridad, setNivelSeguridad] = useState('');
    const [nivelSensibilidad, setNivelSensibilidad] = useState('');
    const [proveedor, setProveedor] = useState('');
    const [usuario, setUsuario] = useState('');

    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [isLoading, setIsLoading] = useState(false);
    const [sistemaSeleccionado, setSistemaSeleccionado] = useState(undefined);

    // API
    const { data: dataSistemas, mutate: mutateSistemas } = useSistemas(
        10,
        currentPage,
        query,
        token,
        servidor,
        nivelSeguridad,
        nivelSensibilidad,
        proveedor,
        usuario
    );

    const { data: dataServidor } = useServidores(10, 1, null, token);

    const { data: dataNivelSeguridad } = useNivelesSeguridad(
        10,
        1,
        null,
        token
    );

    const { data: dataNivelSensibilidad } = useNivelesSensibilidad(
        10,
        1,
        null,
        token
    );

    const { data: dataProveedor } = useProveedoresSistema(10, 1, null, token);

    const { data: dataUsuario } = useUsuarios(10, 1, null, null, null, token);

    // Efectos
    useEffect(() => {
        setCurrentPage(1);
    }, [
        query,
        servidor,
        nivelSeguridad,
        nivelSensibilidad,
        proveedor,
        usuario,
    ]);

    const [
        isDetailModalOpen,
        { setTrue: showDetailModal, setFalse: hideDetailModal },
    ] = useBoolean(false);

    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        {
            key: 'nombre',
            name: 'Nombre',
            fieldName: 'nombre',
            onRender: (item) => <p className="font-bold">{item.nombre}</p>,
        },

        {
            key: 'estado',
            name: 'Estado',
            fieldName: 'estado',
            minWidth: 120,
            onRender: (item) => (
                <p
                    className={`font-bold ${
                        item.estado === 'Con errores'
                            ? 'text-danger-500'
                            : item.estado === 'En mantencion'
                            ? 'text-warning-500'
                            : item.estado === 'Operativo'
                            ? 'text-success-500'
                            : 'text-gray-500'
                    }`}
                >
                    {item.estado ?? 'Sin instancias'}
                </p>
            ),
        },

        {
            key: 'instancias',
            name: 'Cant. instancias',
            fieldName: 'instancias',
            minWidth: 120,
        },

        {
            key: 'encargado',
            name: 'Encargado',
            fieldName: 'encargado',
            minWidth: 250,
        },

        {
            key: 'proveedor',
            name: 'Proveedor',
            fieldName: 'proveedor',
            minWidth: 150,
        },

        ...(user?.data?.usuario?.rol?.id !== 4
            ? [
                  {
                      key: 'acciones',
                      name: 'Acciones',
                      fieldName: 'acciones',
                  },
              ]
            : []),
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    // Handlers
    const handleCreateSistema = async (values) => {
        setIsLoading(true);
        try {
            const response = await createSistema({
                token,
                nombre: values?.nombre,
                idServidorBd: values?.servidorBD?.id,
                idEquipoProveedor: values?.equipoProveedor?.id,
                idNivelSeguridad: values?.idNivelSeguridad,
                idNivelSensibilidad: values?.idNivelSensibilidad,
                idUsuario: values?.idUsuario,

                lenguajes: values?.lenguajes?.map((l) => l.id),
                serviciosWeb: values?.serviciosWeb?.map((s) => s.id),

                documentos: values?.documentos,
                instancias: values?.instancias?.map((i) => ({
                    idServidor: i?.servidor?.id,
                    idTipoInstancia: i?.tipo_instancia?.id,
                })),
            });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateSistemas();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'Sistema creado con éxito.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditSistema = async (values, mutate) => {
        setIsLoading(true);
        try {
            const response = await editSistema({
                token,
                id: sistemaSeleccionado?.id,
                nombre: values?.nombre,
                idServidorBd: values?.servidorBD?.id,
                idEquipoProveedor: values?.equipoProveedor?.id,
                idNivelSeguridad: values?.idNivelSeguridad,
                idNivelSensibilidad: values?.idNivelSensibilidad,
                idUsuario: values?.idUsuario,

                lenguajes: values?.lenguajes?.map((l) => l.id),
                serviciosWeb: values?.serviciosWeb?.map((s) => s.id),

                documentos: values?.documentos,
                instancias: values?.instancias?.map((i) => ({
                    id: i?.id,
                    idServidor: i?.servidor?.id,
                    idTipoInstancia: i?.tipo_instancia?.id,
                })),
            });

            if (response.status) {
                await mutate();
                setIsLoading(false);
                hideEditModal();
                mutateSistemas();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Sistema editado correctamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteSistema = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteSistema({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateSistemas();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Sistema eliminado exitosamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-12 px-16">
            <Breadcrumb
                className="py-4"
                items={[
                    { text: 'Menú principal', href: '/menu' },

                    {
                        text: 'Sistemas o aplicaciones',
                        href: '/sistemas',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-semibold text-4xl">
                    Listado de sistemas
                </h1>

                {[1, 2].includes(user?.data?.usuario?.rol?.id)
                    ? [
                          <PrimaryButton
                              iconProps={{ iconName: 'Add' }}
                              text="Nuevo sistema"
                              className="px-12"
                              onClick={showCreateModal}
                              key={user?.data?.usuario?.rol?.id}
                          />,
                      ]
                    : []}
            </div>

            {/* Filtros */}
            <div>
                <DefaultButton
                    className="border-none bg-transparent px-4 py-2 text-primary-500 font-semibold text-base mb-4 hover:text-primary-500"
                    onClick={() => setShowFilters((s) => !s)}
                >
                    <div className="flex">
                        <span className="mr-2">
                            {showFilters ? 'Ocultar' : 'Mostrar'} Filtros
                        </span>

                        <Icon
                            iconName={
                                showFilters
                                    ? 'ChevronUpSmall'
                                    : 'ChevronDownSmall'
                            }
                        />
                    </div>
                </DefaultButton>

                {showFilters && (
                    <div className="flex justify-between flex-wrap gap-4 mb-4">
                        {/* Cuadro de busqueda (q) */}
                        <SearchBox
                            placeholder="Filtrar por base de datos, servidor, nivel de sensibilidad, nivel de seguridad, proveedor, usuario..."
                            className="w-full"
                            onChange={(q) => {
                                debouncedSetQuery(q?.target?.value ?? '');
                            }}
                            onClear={() => setQuery('')}
                        />

                        <div className="w-full grid grid-cols-5 gap-x-4">
                            {/* Filtros por Servidor */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="font-medium">
                                        Servidor base de datos
                                    </label>

                                    {servidor && (
                                        <button
                                            className="appearance-none text-primary-500 font-medium"
                                            onClick={() => setServidor(null)}
                                        >
                                            Limpiar
                                        </button>
                                    )}
                                </div>

                                <ComboBox
                                    placeholder="Seleccionar"
                                    options={dataServidor?.data?.servidores?.map(
                                        (servidor) => ({
                                            key: servidor.id,
                                            text: servidor.nombre,
                                        })
                                    )}
                                    selectedKey={servidor}
                                    onChange={(_, servidor) =>
                                        setServidor(servidor.key)
                                    }
                                />
                            </div>

                            {/* Filtros por Nivel de Seguridad */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="font-medium">
                                        Nivel de seguridad
                                    </label>

                                    {nivelSeguridad && (
                                        <button
                                            className="appearance-none text-primary-500 font-medium"
                                            onClick={() =>
                                                setNivelSeguridad(null)
                                            }
                                        >
                                            Limpiar
                                        </button>
                                    )}
                                </div>

                                <ComboBox
                                    placeholder="Seleccionar"
                                    options={dataNivelSeguridad?.data?.niveles_seguridad?.map(
                                        (nivelSeguridad) => ({
                                            key: nivelSeguridad.id,
                                            text: nivelSeguridad.nombre,
                                        })
                                    )}
                                    selectedKey={nivelSeguridad}
                                    onChange={(_, nivelSeguridad) =>
                                        setNivelSeguridad(nivelSeguridad.key)
                                    }
                                />
                            </div>

                            {/* Filtros por Nivel de Sensibilidad */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="font-medium">
                                        Nivel sensibilidad
                                    </label>

                                    {nivelSensibilidad && (
                                        <button
                                            className="appearance-none text-primary-500 font-medium"
                                            onClick={() =>
                                                setNivelSensibilidad(null)
                                            }
                                        >
                                            Limpiar
                                        </button>
                                    )}
                                </div>

                                <ComboBox
                                    placeholder="Seleccionar"
                                    options={dataNivelSensibilidad?.data?.niveles_sensibilidad?.map(
                                        (nivelSensibilidad) => ({
                                            key: nivelSensibilidad.id,
                                            text: nivelSensibilidad.nombre,
                                        })
                                    )}
                                    selectedKey={nivelSensibilidad}
                                    onChange={(_, nivelSensibilidad) =>
                                        setNivelSensibilidad(
                                            nivelSensibilidad.key
                                        )
                                    }
                                />
                            </div>

                            {/* Filtros por Proveedor */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="font-medium">
                                        Proveedor
                                    </label>

                                    {proveedor && (
                                        <button
                                            className="appearance-none text-primary-500 font-medium"
                                            onClick={() => setProveedor(null)}
                                        >
                                            Limpiar
                                        </button>
                                    )}
                                </div>

                                <ComboBox
                                    placeholder="Seleccionar"
                                    options={dataProveedor?.data?.proveedores?.map(
                                        (proveedor) => ({
                                            key: proveedor.id,
                                            text: proveedor.nombre,
                                        })
                                    )}
                                    selectedKey={proveedor}
                                    onChange={(_, proveedor) =>
                                        setProveedor(proveedor.key)
                                    }
                                />
                            </div>

                            {/* Filtros por Usuario */}
                            <div>
                                <div className="flex justify-between mb-2">
                                    <label className="font-medium">
                                        Responsable
                                    </label>

                                    {usuario && (
                                        <button
                                            className="appearance-none text-primary-500 font-medium"
                                            onClick={() => setUsuario(null)}
                                        >
                                            Limpiar
                                        </button>
                                    )}
                                </div>

                                <ComboBox
                                    placeholder="Seleccionar"
                                    options={dataUsuario?.data?.usuarios?.map(
                                        (usuario) => ({
                                            key: usuario.id,
                                            text: `${usuario.nombre} ${usuario.apellidos}`,
                                        })
                                    )}
                                    selectedKey={usuario}
                                    onChange={(_, usuario) =>
                                        setUsuario(usuario.key)
                                    }
                                />
                            </div>
                        </div>
                    </div>
                )}
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataSistemas?.data?.sistema?.map((sistema) => ({
                        key: sistema?.id,
                        nombre: sistema?.nombre,
                        estado: sistema?.instancias?.find(
                            (i) =>
                                i?.estado_instancia?.id ===
                                Math.min(
                                    ...sistema?.instancias?.map(
                                        (i) => i?.estado_instancia?.id
                                    )
                                )
                        )?.estado_instancia?.nombre,
                        proveedor:
                            sistema?.equipo_proveedor.proveedor_sistema.nombre,
                        encargado:
                            sistema?.usuario?.nombre +
                            ' ' +
                            sistema?.usuario?.apellidos,
                        instancias: sistema?.instancias.length,
                        acciones: (
                            <BotonUD
                                showDetail={user?.data?.usuario?.rol?.id !== 4}
                                showEdit={[1, 2].includes(
                                    user?.data?.usuario?.rol?.id
                                )}
                                showDelete={user?.data?.usuario?.rol?.id === 1}
                                onViewDetail={() => showDetailModal()}
                                onEdit={() => showEditModal()}
                                onDelete={() => showDeleteModal()}
                                setSelected={setSistemaSeleccionado}
                                itemToSelect={sistema}
                            />
                        ),
                    })) ?? arrayCargando
                }
            />

            {/* Paginación */}
            <div className="flex justify-center mt-4 mb-12">
                <Pagination
                    total={dataSistemas?.data?.meta?.total}
                    pageSize={dataSistemas?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            {/* Modal Detalle  */}
            <Modal
                isOpen={isDetailModalOpen}
                onDismiss={hideDetailModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px6"
            >
                {isDetailModalOpen && (
                    <DetalleSistema
                        sistema={sistemaSeleccionado}
                        onCloseModal={hideDetailModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioSistema
                        tipo="crear"
                        onSubmit={handleCreateSistema}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioSistema
                        tipo="editar"
                        onSubmit={handleEditSistema}
                        isLoading={isLoading}
                        valoresIniciales={sistemaSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar sistema',
                    subText: `¿Estás de acuerdo con eliminar el sistema: "${sistemaSeleccionado?.nombre}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteSistema({
                                id: sistemaSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoSistemas;
