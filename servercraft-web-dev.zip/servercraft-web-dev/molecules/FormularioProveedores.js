// Dependencias
import nookies from 'nookies';
import * as yup from 'yup';
import { PrimaryButton, Spinner, IconButton } from '@fluentui/react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import ControlledInput from '../atoms/controlledInput';
import ControlledSelect from '../atoms/controlledSelect';

const proveedoresSchema = () =>
    yup
        .object({
            emailContacto: yup
                .string()
                .email('Ingresa un email válido')
                .required('Campo obligatorio')
                .max(150, 'El campo debe tener menos de 150 caracteres')
                .matches(
                    /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                    'Ingresa un email válido'
                ),
            nombre: yup
                .string()
                .required('Campo obligatorio')
                .max(150, 'El campo debe tener menos de 150 caracteres'),
            nombreRepresentante: yup
                .string()
                .required('Campo obligatorio')
                .max(200, 'El campo debe tener menos de 200 caracteres'),

            telefonoContacto: yup
                .number()
                .typeError('El teléfono debe ser un número válido')
                .required('Campo obligatorio')
                .min(
                    900000000,
                    'El teléfono debe ser un número positivo de 9 caracteres'
                )
                .max(
                    999999999,
                    'El número de teléfono debe ser de 9 caracteres'
                ),
        })
        .required();

// Componente
const FormularioProveedores = ({
    valoresIniciales,
    tipo,
    onSubmit,
    isLoading,
    onCloseModal,
}) => {
    // Estados

    const { handleSubmit, control } = useForm({
        resolver: yupResolver(proveedoresSchema()),
        defaultValues: {
            ...valoresIniciales,
            nombreRepresentante: valoresIniciales?.nombre_representante,
            emailContacto: valoresIniciales?.email_contacto,
            telefonoContacto: valoresIniciales?.telefono_contacto,
        },
    });

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            className="w-full shadow-2xl p-8 bg-gray-50"
        >
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                    {tipo === 'crear' ? 'Crear proveedor' : 'Editar proveedor'}
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                ></IconButton>
            </div>

            <div className="grid grid-cols-1 gap-4 md:gap-6 md:gap-x-12">
                <ControlledInput
                    control={control}
                    name="nombre"
                    label="Nombre"
                    placeholder=""
                    className="col-span-1"
                />

                <ControlledInput
                    control={control}
                    name="nombreRepresentante"
                    label="Nombre representante"
                    placeholder=""
                    className="col-span-1"
                />

                <ControlledInput
                    control={control}
                    name="emailContacto"
                    label="Correo electrónico"
                    placeholder="correo@correo.cl"
                    className="col-span-1"
                />

                <ControlledInput
                    control={control}
                    name="telefonoContacto"
                    label="Teléfono"
                    placeholder="912345678"
                    prefix="+56"
                    type="number"
                    className="col-span-1"
                />
            </div>

            <PrimaryButton type="submit" className="mt-8 w-full" loading>
                {isLoading && <Spinner className="mr-2" />}Guardar proveedor
            </PrimaryButton>
        </form>
    );
};

// Exportación
export default FormularioProveedores;
