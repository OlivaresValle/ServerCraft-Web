//Dependencies
import { IconButton, Separator } from '@fluentui/react';
import { useProveedorSistema } from '../http/lib/proveedorSistema';
import nookies from 'nookies';
import { Shimmer } from '@fluentui/react';

//Componente
const DetalleProveedor = ({ proveedor, onCloseModal }) => {
    //Estados
    const token = nookies.get()['auth-token'];
    const { data } = useProveedorSistema(proveedor.id, token);

    return (
        <div className="w-full p-8 bg-gray-50">
            {/* Titulo del Modal */}
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                    Detalle del proveedor
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                />
            </div>

            {/* Detalle General del Proveedor */}
            <div className="flex flex-col mt-4 mb-4">
                <div>
                    <div className="grid gap-y-6">
                        <div>
                            <h3 className="font-medium text-primary-500 mb-1">
                                Nombre del proveedor
                            </h3>

                            {data ? (
                                <p>{data.data.proveedor.nombre}</p>
                            ) : (
                                <Shimmer width="100%" className="mr-12" />
                            )}
                        </div>

                        <div>
                            <h3 className="font-medium text-primary-500 mb-1">
                                Teléfono del proveedor
                            </h3>

                            {data ? (
                                <p>{data.data.proveedor.telefono_contacto}</p>
                            ) : (
                                <Shimmer width="100%" className="mr-12" />
                            )}
                        </div>

                        <div>
                            <h3 className="font-medium text-primary-500 mb-1">
                                Email del proveedor
                            </h3>

                            {data ? (
                                <p>{data.data.proveedor.email_contacto}</p>
                            ) : (
                                <Shimmer width="100%" className="mr-12" />
                            )}
                        </div>

                        <div>
                            <h3 className="font-medium text-primary-500 mb-1">
                                Representante del proveedor
                            </h3>

                            {data ? (
                                <p>
                                    {data.data.proveedor.nombre_representante}
                                </p>
                            ) : (
                                <Shimmer width="100%" className="mr-12" />
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
//Export
export default DetalleProveedor;
