// Dependencias
import { PrimaryButton, IconButton, Modal, ChoiceGroup } from '@fluentui/react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import ControlledInput from '../atoms/controlledInput';

const createDocumentSchema = yup
    .object({
        nombre: yup.string().required('Campo obligatorio'),
        url: yup
            .string()
            .required('Campo obligatorio')
            .url('Debes ingresar una url valida'),
    })
    .required();

// Componente
const ModalCrearDocumento = ({ isOpen, onClose, onSelectionConfirm }) => {
    // Estados
    const { control, handleSubmit } = useForm({
        resolver: yupResolver(createDocumentSchema),
    });

    // Handlers
    const handleAddDocumento = (data) => {
        onSelectionConfirm(data);
    };

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            isBlocking
            allowTouchBodyScroll
            styles={{
                scrollableContent: { overflow: 'visible' },
                root: { width: '100%' },
                main: { width: '100%', maxWidth: '1024px !important' },
            }}
            containerClassName="container"
            className="w-full h-full py-4 px-4 md:px-6"
        >
            <form
                onSubmit={handleSubmit(handleAddDocumento)}
                className="w-full h-full shadow-2xl p-8 bg-gray-50"
            >
                <div className="flex justify-between align-center w-full">
                    <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                        Añadir documento
                    </h1>

                    <IconButton
                        iconProps={{ iconName: 'ChromeClose' }}
                        onClick={onClose}
                    />
                </div>

                <div className="w-full h-full overflow-y-auto grid grid-cols-1 gap-y-3">
                    <ControlledInput
                        label="Nombre del documento"
                        control={control}
                        name="nombre"
                    />

                    <ControlledInput
                        label="URL del documento"
                        control={control}
                        name="url"
                    />
                </div>

                <PrimaryButton type="submit" className="mt-6">
                    Añadir documento
                </PrimaryButton>
            </form>
        </Modal>
    );
};

// Export
export default ModalCrearDocumento;
