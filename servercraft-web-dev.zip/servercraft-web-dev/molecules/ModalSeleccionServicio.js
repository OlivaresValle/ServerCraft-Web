// Dependencias
import { useState } from 'react';
import nookies from 'nookies';
import { PrimaryButton, IconButton, Modal, ChoiceGroup } from '@fluentui/react';
import { useServiciosWeb } from '../http/lib/servicioWeb';
import { differenceBy } from 'lodash';

// Componente
const ModalSeleccionServicio = ({
    isOpen,
    onClose,
    defaultValue,
    onSelectionConfirm,
}) => {
    // Estados
    const token = nookies.get()['auth-token'];
    const [selectedServicio, setSelectedServicio] = useState();
    const [showError, setShowError] = useState(false);
    const { data } = useServiciosWeb(100000000, 1, null, token);

    const servicios = differenceBy(data?.data?.servicios, defaultValue, 'id');

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            isBlocking
            allowTouchBodyScroll
            styles={{
                scrollableContent: { overflow: 'visible' },
                root: { width: '100%' },
                main: { width: '100%', maxWidth: '1024px !important' },
            }}
            containerClassName="container"
            className="w-full h-full py-4 px-4 md:px-6"
        >
            <div className="w-full h-full shadow-2xl p-8 bg-gray-50">
                <div className="flex justify-between align-center w-full">
                    <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                        Seleccionar servicio externo
                    </h1>

                    <IconButton
                        iconProps={{ iconName: 'ChromeClose' }}
                        onClick={onClose}
                    />
                </div>

                <div className="w-full h-full overflow-y-auto">
                    <ChoiceGroup
                        selectedKey={selectedServicio?.id ?? defaultValue}
                        onChange={(_, o) => {
                            setSelectedServicio(
                                servicios.find((e) => e.id === o.key)
                            );
                            setShowError(false);
                        }}
                        options={servicios.map((s) => ({
                            key: s?.id,
                            text: `${s.nombre}`,
                        }))}
                    />
                </div>

                {showError && (
                    <p className="font-medium text-danger-400 mt-12">
                        Debes seleccionar al menos 1 servicio para confirmar.
                    </p>
                )}

                <PrimaryButton
                    className="mt-6"
                    onClick={() =>
                        !selectedServicio
                            ? setShowError(true)
                            : onSelectionConfirm(selectedServicio)
                    }
                >
                    Confirmar selección
                </PrimaryButton>
            </div>
        </Modal>
    );
};

// Export
export default ModalSeleccionServicio;
