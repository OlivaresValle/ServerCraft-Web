// Dependencias
import nookies from 'nookies';
import * as yup from 'yup';
import { PrimaryButton, Spinner, IconButton } from '@fluentui/react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import ControlledInput from '../atoms/controlledInput';
import ControlledSelect from '../atoms/controlledSelect';
import { useSalas } from '../http/lib/sala';

const rackSchema = yup
    .object({
        nombre: yup
            .string()
            .required('Campo obligatorio')
            .max(150, 'El campo debe tener menos de 150 caracteres'),
        descripcion: yup
            .string()
            .required('Campo obligatorio')
            .max(255, 'El campo debe tener menos de 255 caracteres'),
        idSala: yup.number().required('Campo obligatorio'),
    })
    .required();

// Componente
const FormularioRack = ({
    valoresIniciales,
    tipo,
    onSubmit,
    isLoading,
    onCloseModal,
}) => {
    // Estados
    const token = nookies.get()['auth-token'];

    const { handleSubmit, control } = useForm({
        resolver: yupResolver(rackSchema),
        defaultValues: {
            ...valoresIniciales,
            idSala: valoresIniciales?.sala?.id,
        },
    });

    const { data: dataSalas } = useSalas(10000000, 1, null, token);

    return (
        <form
            onSubmit={handleSubmit(onSubmit)}
            className="w-full shadow-2xl p-8 bg-gray-50"
        >
            <div className="flex justify-between align-center w-full">
                <h1 className="text-primary-500 font-semibold text-3xl mb-4">
                    {tipo === 'crear' ? 'Crear rack' : 'Editar rack'}
                </h1>

                <IconButton
                    iconProps={{ iconName: 'ChromeClose' }}
                    onClick={onCloseModal}
                ></IconButton>
            </div>

            <div className="grid gap-y-4">
                <ControlledInput
                    control={control}
                    name="nombre"
                    label="Nombre"
                />

                <ControlledInput
                    control={control}
                    name="descripcion"
                    label="Descripción"
                    multiline
                    autoAdjustHeight
                />

                <ControlledSelect
                    control={control}
                    name="idSala"
                    label="Sala del rack"
                    options={
                        dataSalas?.data?.salas?.map((sala) => ({
                            key: sala.id,
                            text: sala.nombre,
                        })) ?? []
                    }
                />
            </div>

            <PrimaryButton type="submit" className="mt-8 w-full" loading>
                {isLoading && <Spinner className="mr-2" />}Guardar rack
            </PrimaryButton>
        </form>
    );
};

// Exportación
export default FormularioRack;
