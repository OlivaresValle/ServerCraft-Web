// Dependencias
import {
    Breadcrumb,
    PrimaryButton,
    DetailsList,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    DefaultButton,
    Spinner,
    SpinnerSize,
    SearchBox,
} from '@fluentui/react';
import nookies from 'nookies';
import { useEffect, useState } from 'react';
import {
    useTipoSoluciones,
    createTipoSolucion,
    editTipoSolucion,
    deleteTipoSolucion,
} from '../http/lib/tipoSolucion';
import { CargandoTabla } from '../servicios/cargandoTabla';
import { useBoolean } from '@fluentui/react-hooks';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import SuccessToast from '../atoms/successToast';
import ErrorToast from '../atoms/errorToast';
import FormularioTipoSoluciones from './FormularioTipoSoluciones';
import debounce from 'lodash/debounce';
import Pagination from 'rc-pagination';
import { useUsuario } from '../http/lib/usuario';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoTipoSoluciones = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);
    const [isLoading, setIsLoading] = useState(false);
    const [tipoSolucionSeleccionado, setTipoSolucionSeleccionado] = useState();

    // Filtros
    const [query, setQuery] = useState('');

    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        {
            key: 'nombre',
            name: 'Nombre',
            fieldName: 'nombre',

            onRender: (item) => (
                <p className="font-bold d-inline-block">{item.nombre}</p>
            ),
        },
        ...([1, 2].includes(user?.data?.usuario?.rol?.id)
            ? [
                  {
                      key: 'acciones',
                      name: 'Acciones',
                      fieldName: 'acciones',
                  },
              ]
            : []),
    ];

    const arrayCargando = CargandoTabla(columnas, 4);

    const { data: dataTipoSolucion, mutate: mutateTipoSolucion } =
        useTipoSoluciones(10, currentPage, query, token);

    // Efectos
    useEffect(() => {
        setCurrentPage(1);
    }, [query]);

    // Handlers
    const handleCreateTipoSolucion = async (values) => {
        setIsLoading(true);
        try {
            const response = await createTipoSolucion({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateTipoSolucion();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Tipo de solución creado con éxito.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditTipoSolucion = async ({ ...values }) => {
        setIsLoading(true);
        try {
            const response = await editTipoSolucion({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateTipoSolucion();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Tipo de solución editado correctamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteTipoSolucion = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteTipoSolucion({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateTipoSolucion();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Tipo de solución eliminado exitosamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col pt-12 px-16">
            <Breadcrumb
                className="py-4"
                styles={{}}
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Incidentes',
                        href: '/tipos-solucion',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-bold text-4xl">
                    Listado de tipos de soluciones
                </h1>

                {[1, 2].includes(user?.data?.usuario?.rol?.id)
                    ? [
                          <PrimaryButton
                              onClick={showCreateModal}
                              iconProps={{ iconName: 'Add' }}
                              text="Nueva solución"
                              className="px-12"
                              key={user?.data?.usuario?.rol?.id}
                          />,
                      ]
                    : []}
            </div>

            {/* Filtros */}
            <div className="flex justify-between flex-wrap gap-4 mb-4">
                {/* Cuadro de busqueda (q) */}
                <SearchBox
                    placeholder="Filtrar por nombre ..."
                    className="w-full"
                    onChange={(q) => {
                        debouncedSetQuery(q?.target?.value ?? '');
                    }}
                    onClear={() => setQuery('')}
                />
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataTipoSolucion?.data?.tipos_solucion?.map(
                        (tipoSolucion) => ({
                            key: tipoSolucion.id,
                            nombre: tipoSolucion.nombre,
                            sistemas: tipoSolucion.id,
                            acciones: (
                                <BotonUD
                                    showEdit={[1, 2].includes(
                                        user?.data?.usuario?.rol?.id
                                    )}
                                    showDelete={
                                        user?.data?.usuario?.rol?.id === 1
                                    }
                                    onEdit={() => showEditModal()}
                                    onDelete={() => showDeleteModal()}
                                    setSelected={setTipoSolucionSeleccionado}
                                    itemToSelect={tipoSolucion}
                                />
                            ),
                        })
                    ) ?? arrayCargando
                }
            />

            {/* Paginación */}
            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataTipoSolucion?.data?.meta?.total}
                    pageSize={dataTipoSolucion?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '660px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioTipoSoluciones
                        tipo="crear"
                        onSubmit={handleCreateTipoSolucion}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '660px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioTipoSoluciones
                        tipo="editar"
                        onSubmit={handleEditTipoSolucion}
                        isLoading={isLoading}
                        valoresIniciales={tipoSolucionSeleccionado}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar tipo de solución',
                    subText: `¿Estás de acuerdo con eliminar el tipo de solución: "${tipoSolucionSeleccionado?.nombre}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteTipoSolucion({
                                id: tipoSolucionSeleccionado?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoTipoSoluciones;
