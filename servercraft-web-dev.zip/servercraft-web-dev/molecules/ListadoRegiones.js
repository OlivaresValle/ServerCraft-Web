// Dependencias
import {
    Breadcrumb,
    PrimaryButton,
    DetailsList,
    SelectionMode,
    Modal,
    Dialog,
    DialogFooter,
    Spinner,
    DefaultButton,
    SpinnerSize,
    SearchBox,
    ComboBox,
} from '@fluentui/react';
import { useBoolean } from '@fluentui/react-hooks';
import nookies from 'nookies';
import BotonUD from '../atoms/BotonUD';
import toast from 'react-hot-toast';
import ErrorToast from '../atoms/errorToast';
import SuccessToast from '../atoms/successToast';
import {
    useRegiones,
    createRegion,
    editRegion,
    deleteRegion,
} from '../http/lib/region';
import { CargandoTabla } from '../servicios/cargandoTabla';
import FormularioRegion from './FormularioRegion';
import { useState } from 'react';
import debounce from 'lodash/debounce';
import { usePaises } from '../http/lib/pais';
import Pagination from 'rc-pagination';

// Estilos
import 'rc-pagination/assets/index.css';

// Componente
const ListadoRegiones = () => {
    // Estados
    const token = nookies.get()['auth-token'];
    const [isLoading, setIsLoading] = useState(false);
    const [regionSeleccionada, setRegionSeleccionada] = useState(undefined);

    // Filros
    const [query, setQuery] = useState('');
    const [pais, setPais] = useState();
    const debouncedSetQuery = debounce((value) => setQuery(value), 500);

    // Paginación
    const [currentPage, setCurrentPage] = useState(1);

    const [
        isCreateModalOpen,
        { setTrue: showCreateModal, setFalse: hideCreateModal },
    ] = useBoolean(false);
    const [
        isEditModalOpen,
        { setTrue: showEditModal, setFalse: hideEditModal },
    ] = useBoolean(false);
    const [
        isDeleteModalOpen,
        { setTrue: showDeleteModal, setFalse: hideDeleteModal },
    ] = useBoolean(false);

    const columnas = [
        {
            key: 'region',
            name: 'Región',
            fieldName: 'region',
            onRender: (item) => <p className="font-medium">{item.nombre}</p>,
        },

        {
            key: 'acciones',
            name: 'Acciones',
            fieldName: 'acciones',
        },
    ];

    const arrayCargando = CargandoTabla(columnas, 10);

    const { data: dataRegiones, mutate: mutateRegiones } = useRegiones(
        pais,
        10,
        currentPage,
        query,
        token
    );
    const { data: dataPaises } = usePaises(10000000, 1, null, token);

    // Handlers
    const handleCreateRegion = async (values) => {
        setIsLoading(true);
        try {
            const response = await createRegion({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideCreateModal();
                mutateRegiones();
                toast.custom((t) => (
                    <SuccessToast t={t} text={'Región creada con éxito.'} />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleEditRegion = async (values) => {
        setIsLoading(true);
        try {
            const response = await editRegion({ token, ...values });

            if (response.status) {
                setIsLoading(false);
                hideEditModal();
                mutateRegiones();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Región editada correctamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    const handleDeleteRegion = async ({ id, token }) => {
        setIsLoading(true);
        try {
            const response = await deleteRegion({ id, token });

            if (response.status) {
                setIsLoading(false);
                hideDeleteModal();
                mutateRegiones();
                toast.custom((t) => (
                    <SuccessToast
                        t={t}
                        text={'Región eliminada exitosamente.'}
                    />
                ));
            }
        } catch (e) {
            setIsLoading(false);
            toast.custom((t) => (
                <ErrorToast t={t} text={'Ha ocurrido un error inesperado.'} />
            ));
        }
    };

    return (
        <div className="flex flex-col py-12 px-16">
            <Breadcrumb
                className="py-4"
                items={[
                    { text: 'Menú principal', href: '/menu' },
                    {
                        text: 'Ubicaciones',
                        href: '/ubicaciones',
                        isCurrentItem: true,
                    },
                ]}
            />
            <div className="flex justify-between mb-8">
                <h1 className="text-primary-500 font-bold text-4xl">
                    {`Listado de regiones`}
                </h1>

                <PrimaryButton
                    iconProps={{ iconName: 'Add' }}
                    text="Nueva región"
                    className="px-12"
                    onClick={showCreateModal}
                />
            </div>

            {/* Filtros */}
            <div className="grid grid-cols-5 items-end gap-4 mb-4">
                {/* Cuadro de busqueda (q) */}
                <SearchBox
                    placeholder="Filtrar por nombre o país..."
                    className="col-span-4"
                    onChange={(q) => {
                        debouncedSetQuery(q?.target?.value ?? '');
                    }}
                    onClear={() => setQuery('')}
                />

                {/* Filtros por Pais */}
                <div className="col-span-1">
                    <div className="flex justify-between mb-2">
                        <label className="font-medium">País</label>

                        {pais && (
                            <button
                                className="appearance-none text-primary-500 font-medium"
                                onClick={() => setPais(null)}
                            >
                                Limpiar
                            </button>
                        )}
                    </div>

                    <ComboBox
                        placeholder="Seleccionar"
                        options={dataPaises?.data?.paises?.map((pais) => ({
                            key: pais.id,
                            text: pais.nombre,
                        }))}
                        selectedKey={pais}
                        onChange={(_, pais) => setPais(pais.key)}
                    />
                </div>
            </div>

            <DetailsList
                columns={columnas}
                selectionMode={SelectionMode.none}
                items={
                    dataRegiones?.data?.regiones?.map((region) => ({
                        key: region?.id,
                        nombre: region?.nombre,
                        acciones: (
                            <BotonUD
                                showEdit
                                showDelete
                                onEdit={() => showEditModal()}
                                onDelete={() => showDeleteModal()}
                                setSelected={setRegionSeleccionada}
                                itemToSelect={region}
                            />
                        ),
                    })) ?? arrayCargando
                }
            />

            {/* Paginación */}
            <div className="flex justify-center mt-4">
                <Pagination
                    total={dataRegiones?.data?.meta?.total}
                    pageSize={dataRegiones?.data?.meta?.per_page ?? 1}
                    current={currentPage}
                    onChange={(page) => setCurrentPage(page)}
                />
            </div>

            <Modal
                isOpen={isCreateModalOpen}
                onDismiss={hideCreateModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isCreateModalOpen && (
                    <FormularioRegion
                        tipo="crear"
                        onSubmit={handleCreateRegion}
                        isLoading={isLoading}
                        onCloseModal={hideCreateModal}
                    />
                )}
            </Modal>

            <Modal
                isOpen={isEditModalOpen}
                onDismiss={hideEditModal}
                isBlocking
                allowTouchBodyScroll
                styles={{
                    scrollableContent: { overflow: 'visible' },
                    root: { width: '100%' },
                    main: { width: '100%', maxWidth: '1024px !important' },
                }}
                containerClassName="container"
                className="w-full py-4 px-4 md:px-6"
            >
                {isEditModalOpen && (
                    <FormularioRegion
                        tipo="editar"
                        onSubmit={handleEditRegion}
                        isLoading={isLoading}
                        valoresIniciales={regionSeleccionada}
                        onCloseModal={hideEditModal}
                    />
                )}
            </Modal>

            <Dialog
                hidden={!isDeleteModalOpen}
                onDismiss={hideDeleteModal}
                dialogContentProps={{
                    title: 'Eliminar región',
                    subText: `¿Estás de acuerdo con eliminar la región: "${regionSeleccionada?.nombre}"?`,
                }}
                modalProps={{ isBlocking: true }}
            >
                <DialogFooter>
                    <PrimaryButton
                        className="bg-danger-500 border-danger-500 hover:bg-danger-400 hover:border-danger-400"
                        onClick={() =>
                            handleDeleteRegion({
                                id: regionSeleccionada?.id,
                                token,
                            })
                        }
                        text={
                            <div className="flex">
                                {isLoading && (
                                    <Spinner
                                        size={SpinnerSize.xSmall}
                                        className="mr-2"
                                    />
                                )}
                                Eliminar
                            </div>
                        }
                    />
                    <DefaultButton onClick={hideDeleteModal} text="Cancelar" />
                </DialogFooter>
            </Dialog>
        </div>
    );
};

// Exportación
export default ListadoRegiones;
