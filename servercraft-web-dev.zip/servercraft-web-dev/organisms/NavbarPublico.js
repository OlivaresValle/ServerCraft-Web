// Dependencias
import { Stack } from '@fluentui/react';
import Logo from '../atoms/Logo';
import { useRouter } from 'next/router';

// Componente
const NavbarPublico = () => {
    const router = useRouter();

    return (
        <div
            className={`w-full shadow-lg bg-white fixed z-10 top-0 ${
                router.query.ua === 'mobile' ? 'hidden' : ''
            }`}
        >
            <Stack horizontal className="container mx-auto p-4">
                <Logo href="/" />
            </Stack>
        </div>
    );
};

// Exportación
export default NavbarPublico;
