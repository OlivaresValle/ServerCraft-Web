// Dependencias
import { Breadcrumb, Pivot, PivotItem } from '@fluentui/react';
import FormularioPerfil from '../molecules/FormularioPerfil';
import FormularioContraseña from '../molecules/FormularioContraseña';

// Componente
const PerfilUsuario = () => {
    return (
        <div className="flex flex-col py-12 px-16">
            <Breadcrumb
                className="py-4"
                styles={{}}
                items={[
                    { text: 'Menú principal', href: '/menu', key: 'menu' },
                    {
                        text: 'Usuario',
                        href: '/Perfil',
                        isCurrentItem: true,
                        key: 'perfil',
                    },
                ]}
            />

            <div className="flex justify-start mb-8">
                <h1 className="text-primary-500 font-semibold text-4xl">
                    Perfil de usuario
                </h1>
            </div>

            <Pivot className="bg-white bg-opacity-75">
                <PivotItem headerText="Información Personal">
                    <FormularioPerfil />
                </PivotItem>

                <PivotItem headerText="Contraseña">
                    <FormularioContraseña />
                </PivotItem>
            </Pivot>
        </div>
    );
};

// Exportación
export default PerfilUsuario;
