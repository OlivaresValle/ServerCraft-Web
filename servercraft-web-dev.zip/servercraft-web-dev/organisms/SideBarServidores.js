// Dependencias
import { Nav } from '@fluentui/react';
import nookies from 'nookies';
import { useUsuario } from '../http/lib/usuario';

// Componente
const SideBarServidores = ({ selectedKey }) => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);

    return (
        <div className="w-full h-full pt-1 bg-white pl-px">
            <Nav
                selectedKey={selectedKey}
                styles={{ root: { height: '100%' } }}
                groups={[
                    {
                        links: [
                            ...([1, 2].includes(user?.data?.usuario?.rol?.id)
                                ? [
                                      {
                                          name: 'Salas',
                                          key: 'salas',
                                          url: '/salas',
                                          title: 'Ir a sala',
                                      },
                                  ]
                                : []),
                            ...([1, 2].includes(user?.data?.usuario?.rol?.id)
                                ? [
                                      {
                                          name: 'Racks',
                                          key: 'racks',
                                          url: '/racks',
                                          title: 'Ir a Racks',
                                      },
                                  ]
                                : []),
                            {
                                name: 'Servidores',
                                key: 'servidores',
                                url: '/servidores',
                                title: 'Ir a Servidores',
                            },
                        ],
                    },
                ]}
            />
        </div>
    );
};

// Exportación
export default SideBarServidores;
