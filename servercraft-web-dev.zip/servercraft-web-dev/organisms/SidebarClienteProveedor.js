// Dependencias
import { Nav } from '@fluentui/react';

// Componente
const SidebarCliente = ({ selectedKey }) => {
    // Estados

    return (
        <div className="w-full h-full pt-1 bg-white pl-px">
            <Nav
                selectedKey={selectedKey}
                styles={{
                    root: { height: '100%' },
                }}
                groups={[
                    {
                        links: [
                            {
                                name: 'Proveedores',
                                key: 'proveedores',
                                url: '/proveedores',
                                title: '',
                            },
                            {
                                name: 'Equipos del proveedor',
                                key: 'equipos_proveedor',
                                url: '/proveedores/equipos',
                                title: '',
                            },
                        ],
                    },
                ]}
            />
        </div>
    );
};

// Exportación
export default SidebarCliente;
