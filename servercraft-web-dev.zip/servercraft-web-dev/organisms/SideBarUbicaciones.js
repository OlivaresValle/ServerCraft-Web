// Dependencias
import { Nav } from '@fluentui/react';

// Componente
const SideBarUbicaciones = ({ selectedKey }) => {
    // Estados
    return (
        <div className="w-full h-full pt-1 bg-white pl-px">
            <Nav
                selectedKey={selectedKey}
                styles={{ root: { height: '100%' } }}
                groups={[
                    {
                        links: [
                            {
                                name: 'Paises',
                                key: 'paises',
                                url: '/ubicaciones/paises',
                                title: 'Ir a paises',
                            },
                            {
                                name: 'Regiones',
                                key: 'regiones',
                                url: '/ubicaciones/regiones',
                                title: 'Ir a regiones',
                            },
                        ],
                    },
                ]}
            />
        </div>
    );
};

// Exportación
export default SideBarUbicaciones;
