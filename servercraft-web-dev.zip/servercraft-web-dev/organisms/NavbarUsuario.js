// Dependencias
import { Stack } from '@fluentui/react';
import Logo from '../atoms/Logo';
import MenuUsuario from '../molecules/MenuUsuario';

// Componente
const NavbarUsuario = () => {
    return (
        <div className="w-full shadow-lg bg-white fixed z-10 top-0">
            <Stack
                horizontal
                horizontalAlign="space-between"
                verticalAlign="center"
                className="container mx-auto p-4"
            >
                <Logo href="/menu" />

                <MenuUsuario />
            </Stack>
        </div>
    );
};

// Exportación
export default NavbarUsuario;
