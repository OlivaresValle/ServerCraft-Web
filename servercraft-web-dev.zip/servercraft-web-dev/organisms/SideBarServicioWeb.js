// Dependencias
import { Nav } from '@fluentui/react';

// Componente
const SideBarServicioWeb = ({ selectedKey }) => {
    // Estados
    return (
        <div className="w-full h-full pt-1 bg-white pl-px">
            <Nav
                selectedKey={selectedKey}
                styles={{ root: { height: '100%' } }}
                groups={[
                    {
                        links: [
                            {
                                name: 'Servicios web',
                                key: 'servicios',
                                url: '/servicios',
                                title: 'Ir a servico_web',
                            },
                            {
                                name: 'Documentos servicios web',
                                key: 'documento-servicio',
                                url: '/documento-servicio',
                                title: 'Ir a documento_servicio',
                            },
                        ],
                    },
                ]}
            />
        </div>
    );
};

// Exportación
export default SideBarServicioWeb;
