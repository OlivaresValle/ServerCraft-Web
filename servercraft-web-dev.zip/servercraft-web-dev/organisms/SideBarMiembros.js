// Dependencias
import { Nav } from '@fluentui/react';
import nookies from 'nookies';
import { useUsuario } from '../http/lib/usuario';

// Componente
const SideBarMiembros = ({ selectedKey }) => {
    // Estados
    const token = nookies.get()['auth-token'];
    const { data: user } = useUsuario(0, token);

    return (
        <div className="w-full h-full pt-1 bg-white pl-px">
            <Nav
                selectedKey={selectedKey}
                styles={{ root: { height: '100%' } }}
                groups={[
                    {
                        links: [
                            ...([1].includes(user?.data?.usuario?.rol?.id)
                                ? [
                                      {
                                          name: 'Usuarios',
                                          key: 'Usuarios',
                                          url: '/usuarios',
                                          title: 'ir a usuarios',
                                      },
                                  ]
                                : []),
                            ...([1, 2, 3].includes(user?.data?.usuario?.rol?.id)
                                ? [
                                      {
                                          name: 'Equipos de trabajo',
                                          key: 'equipo-trabajo',
                                          url: '/equipo-trabajo',
                                          title: 'ir a Equipos',
                                      },
                                  ]
                                : []),
                            ...([1, 2, 3].includes(user?.data?.usuario?.rol?.id)
                                ? [
                                      {
                                          name: 'Unidades de negocio',
                                          key: 'unidad-negocio',
                                          url: '/unidad-negocio',
                                          title: 'ir a Unidades',
                                      },
                                  ]
                                : []),
                        ],
                    },
                ]}
            />
        </div>
    );
};

// Exportación
export default SideBarMiembros;
