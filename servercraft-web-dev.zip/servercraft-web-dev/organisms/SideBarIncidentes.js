// Dependencias
import { Nav } from '@fluentui/react';

// Componente
const SideBarIncidentes = ({ selectedKey }) => {
    // Estados
    return (
        <div className="w-full h-full pt-1 bg-white pl-px">
            <Nav
                selectedKey={selectedKey}
                styles={{ root: { height: '100%' } }}
                groups={[
                    {
                        links: [
                            {
                                name: 'Incidentes',
                                key: 'incidentes',
                                url: '/incidentes',
                                title: 'Ir a incidentes',
                            },
                            {
                                name: 'Tipos de Problemas',
                                key: 'tipo-problemas',
                                url: '/tipo-problemas',
                                title: 'Ir a Tipos de Problemas',
                            },
                            {
                                name: 'Tipos de Solución',
                                key: 'tipo-solucion',
                                url: '/tipo-solucion',
                                title: 'Ir a Tipo de Solución',
                            },
                        ],
                    },
                ]}
            />
        </div>
    );
};

// Exportación
export default SideBarIncidentes;
