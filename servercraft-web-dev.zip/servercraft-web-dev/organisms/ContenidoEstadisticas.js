// Dependencias
import { Breadcrumb } from '@fluentui/react';
import EstadisticaSistemasNuevos from '../molecules/EstadisticaSistemasNuevos';
import EstadisticasNuevosClientes from '../molecules/EstadisticasNuevosClientes';
import TiposProblemas from '../molecules/EstadisticaTiposProblemas';
import EstadisitcasIncidentesMensuales from '../molecules/EstadisticasIncidentesMensuales';

// Componente
const ContenidoEstadisticas = () => {
    return (
        <div className="flex flex-col w-full container mx-auto pt-2">
            <Breadcrumb
                className="py-4"
                items={[
                    { text: 'Menú principal', href: '/menu' },

                    {
                        text: 'Estadísticas',
                        isCurrentItem: true,
                    },
                ]}
            />

            <div className="flex justify-between mb-12">
                <h1 className="text-primary-500 font-semibold text-4xl">
                    Estadísticas
                </h1>
            </div>

            <div className="flex justify-between mb-2">
                <h2 className="text-primary-500 font-semibold text-3xl">
                    {'KPI '}
                    <span className="font-normal text-xl text-gray-500">
                        (Key performance indicators)
                    </span>
                </h2>
            </div>

            <section className="grid grid-cols-2 gap-x-8">
                <div className="col-span-1 mt-4">
                    <EstadisticasNuevosClientes />
                </div>

                <div className="col-span-1 mt-4">
                    <EstadisticaSistemasNuevos />
                </div>
            </section>

            <div className="flex justify-between mb-2 mt-12">
                <h2 className="text-primary-500 font-semibold text-3xl">
                    {'KRI '}
                    <span className="font-normal text-xl text-gray-500">
                        (Key risk indicators)
                    </span>
                </h2>
            </div>

            <section className="grid grid-cols-2 gap-x-8 pb-16">
                <div className="col-span-1 mt-4">
                    <EstadisitcasIncidentesMensuales />
                </div>

                <div className="col-span-1 mt-4">
                    <TiposProblemas />
                </div>
            </section>
        </div>
    );
};

// Export
export default ContenidoEstadisticas;
